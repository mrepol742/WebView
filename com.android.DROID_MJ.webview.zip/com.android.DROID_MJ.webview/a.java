    h.setOnTouchListener(new C7() {
        public boolean a(View v, MotionEvent event) {
            if ((event.getFlags() & MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    new AlertDialog.Builder(A21.this).setTitle(getString(R.string.c13)).setMessage(getString(R.string.b16)).setNeutralButton(getString(R.string.k37), null).show();
                }
                return true;
            }
            return false;
        }
    });