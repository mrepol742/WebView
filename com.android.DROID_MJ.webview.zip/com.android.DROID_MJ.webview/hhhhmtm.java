    public void l(String url, final int type) {
        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b8, null);
        a.setCancelable(true); 
        switch (type) {
            case 0:
                a.setTitle(getString(R.string.x9)); // LINKS
            break;
            case 1:
                a.setTitle(getString(R.string.x16)); // TRANCEROUT
            break;
            case 2:
                a.setTitle(getString(R.string.y11)); //NPing
            break;
            case 3:
                a.setTitle(getString(R.string.z4)); //Whois
            break;
            case 4:
                a.setTitle(getString(R.string.z15)); //Meta Tags
            break;
            case 5:
                a.setTitle(getString(R.string.y15)); // Headers
            break;
            case 6:
                a.setTitle(getString(R.string.f32)); // Robots
            break;
            case 7:
                a.setTitle(getString(R.string.j)); // Source Code
            break;
            case 8:
                a.setTitle(getString(R.string.z12)); // IP Geolocation
            break;
        }
        a.setView(c);
        final EditText ed = (EditText) c.findViewById(R.id.g8);
        final TextView ti = (TextView) c.findViewById(R.id.e2);
        final Button bn = (Button) c.findViewById(R.id.k20);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        int e3 = C5.b(this,R.color.j);
        int f3 = C5.b(this,R.color.k);
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
bn.setTextColor(e);
            ti.setTextColor(e3);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f3);
bn.setTextColor(f);
        }
        if (type == 0 || type == 4 || type == 5 || type == 7) {
            ed.setText(url);
        } else {
            ed.setText(Uri.parse(url).getHost().replaceAll("www.", ""));
        }
        bn.setText(getString(R.string.i6));
        bn.setBackgroundResource(R.drawable.e20);
        if (type != 7 || type != 8) {
        
        ti.setText(getString(R.string.f31).replaceAll("%a", "\nhttps://example.com").replaceAll("%b", "http://example.com").replaceAll("%c", "example.com"));
        }
        if (type == 8) {
            ed.setInputType(InputType.TYPE_CLASS_NUMBER); 
        }
        bn.setOnClickListener(new C9() {
            public void a(View v) {
                 String a = ed.getText().toString();
                 switch (type) {
                     case 0:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.z()) + a));
}
                     break;
                     case 1:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(1)+ a));
}
                     break;
                     case 2:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a( 2) + a));
}
                     break;
                     case 3:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(  3) + a));
}
                     break;
                     case 4:
                         if (W13.a(a) == true) {
                         b(Uri.parse(U4.a(W5.a1()) + a));
}
                     break;
                     case 5:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.y()) + a));
}
                     break;
                     case 6:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a.replaceAll("/", "")+"/robots.txt"));
                             } else {
                                 b(Uri.parse("http://"+a.replaceAll("/", "")+"/robots.txt"));
                             }
                         }
                     break;
                     case 7:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a));
                             } else {
                                 b(Uri.parse("http://"+a));
                             }
                         }
                     break;
                     case 8:
                         b(Uri.parse(a));
                     break;
                 }
            }

            public void b(Uri a) {
                Intent it = new Intent("com.android.DROID_MJ.webview.intent.action.TOOLS");
                it.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
                it.setPackage(U4.a(W5.a10()));
                it.setData(a);
                if (it.resolveActivity(A1.this.getPackageManager()) != null) {
                    A1.this.startActivity(it);
                }
            }
        });
        ed.addTextChangedListener(new T6 () {
            private void a() {
                String url = ed.getText().toString().replaceAll(" ","");
                if (type == 6 || type == 7) {
                    if (W13.a(url) == false) {
                        ed.setError(getString(R.string.c32));
                    }
                }
            }
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        final AlertDialog g = a.create();
        g.show();
    }