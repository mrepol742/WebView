package moncash.api;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.digicelgroup.moncash.*;
import com.digicelgroup.moncash.http.*;
import com.digicelgroup.moncash.payments.*;
import java.util.logging.*;
import org.apache.http.*;

import static org.junit.Assert.*;


public class MainActivity extends Activity 
{
	private static final Logger logger = Logger
	.getLogger(MainActivity.class.getName());
	private Intent i = new Intent();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
	public void Pay(View view) throws Exception{
		
		PaymentCreator paymentCreator = new PaymentCreator();
        APIContext apiContext = new APIContext(CredentialTest.CLIENT_ID, CredentialTest.CLIENT_SECRET, Constants.LIVE);
        Payment payment = new Payment();
        payment.setOrderId(System.currentTimeMillis()+"");
        payment.setAmount(50);
        PaymentCreator creator = paymentCreator.execute(apiContext,PaymentCreator.class, payment);
        if(creator.getStatus() !=null && creator.getStatus().compareTo(HttpStatus.SC_ACCEPTED+"")==0){
            logger.info("redirect to the link below");
			Toast.makeText(getApplicationContext(),"redirect to the link below",Toast.LENGTH_LONG).show();
            logger.info(creator.redirectUri());
			i.setAction(Intent.ACTION_VIEW); 
			i.setData(Uri.parse(creator.redirectUri())); 
			startActivity(i);
        }else if(creator.getStatus()==null){
            logger.warning("Error");
			Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
            logger.warning(creator.getError());
            logger.warning(creator.getError_description());
        }else{
            logger.warning("Error");
            logger.warning(creator.getStatus());
            logger.warning(creator.getError());
            logger.warning(creator.getMessage());
            logger.warning(creator.getPath());
        }
	}
}