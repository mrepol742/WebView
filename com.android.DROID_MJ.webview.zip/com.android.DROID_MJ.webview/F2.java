    public void c133() {
        int b = W5.e();
        int newUpdate = U6.c(U4.a(W5.m()));
        String gh = U6.b(U4.a(W5.r()));
        if (newUpdate > b) {
            c134("g", getString(R.string.x11), getString(R.string.x12), notif_id.c, gh, R.drawable.j, R.drawable.j);
            U1.a("Update is available");
        } else if (newUpdate == b && com.android.DROID_MJ.webview.WebView.Application.a) {
            c134("g", getString(R.string.x11), getString(R.string.x12), notif_id.c, gh, R.drawable.l, R.drawable.l);
            U1.a("Beta Update is available");
        }
    }

   private void c134(String channel, String title, String text, int id, String url, int id2) {
        Notification.Builder m = A37.a(this, channel);
        m.setSmallIcon(id2);
Notification.BigTextStyle bigText = new Notification.BigTextStyle();
        bigText.bigText(text);
        bigText.setBigContentTitle(title);
        bigText.setSummaryText(getString(R.string.p20));
        m.setContentTitle(title);
        m.setContentText(text);
        m.setStyle(bigText);
        m.setColor(C5.b(this,R.color.a));
        if (sp.getBoolean("eac", true) == true) {
            m.setAutoCancel(true);
        } else {
            m.setAutoCancel(false);
        }
        m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT < 26) {
            if (sp.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sp.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sp.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sp.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
        if (sp.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
        }
            if (sp.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sp.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sp.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }    m.setLargeIcon(BitmapFactory.decodeResource(getResources(),id2));
        Intent j = new Intent(this, A21.class);
        j.putExtra("value", url);
        PendingIntent k = PendingIntent.getActivity(this, 1, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.setContentIntent(k);
if (id == notif_id.c) {
        PendingIntent pi23 = PendingIntent.getActivity(this, 0, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.c2,getString(R.string.b32),pi23);
} else{
Intent j55 = new Intent(this, A21.class);
j55.putExtra("webview", url);
PendingIntent pi235 = PendingIntent.getActivity(this, 2, j55,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.q,getString(R.string.g28).replaceAll("%a", Uri.parse(url).getHost()),pi235);
}

      NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(id, m.build());
    }

    public void c135() {
        int notif = U6.c(U4.a(W5.q()));
        /*String title = U6.b(U4.a(W5.n()));
        String text = U6.b(U4.a(W5.o()));
        String ufl = U6.b(U4.a(W5.p()));*/
        if (notif > 0) {
            String neTf = U6.b(U4.a(W5.g()));
            String[] sp = neTf.split(";");
            SharedPreferences j988 = getSharedPreferences("notif1", 0);
            SharedPreferences j98855 = getSharedPreferences("notif2", 0);
            if (!j988.getString("notif1", "").equals(sp[0]) && !j98855.getString("notif2", "").equals(sp[1])) {
                c134("h", sp[0],sp[1] , U7.a(U7.NOTIFICATION), sp[2],R.drawable.c );
                U1.a("Push Notification was been received");
                SharedPreferences.Editor gujh = j988.edit(); 
                gujh.putString("notif1", sp[0]);
                gujh.commit();
                SharedPreferences.Editor gujh55 = j98855.edit(); 
                gujh55.putString("notif2", sp[1]);
                gujh55.commit();
            }  
        }
    }

    private void c136() {
        P15 p = new P15() {
            public void a() {
                c133();
            } 
        };
        er.execute(p);
        P15 p5 = new P15() {
            public void a() {
                c135();
            } 
        };
        er.execute(p5);
    }

