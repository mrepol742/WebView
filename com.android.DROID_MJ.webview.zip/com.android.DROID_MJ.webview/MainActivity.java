package com.example.intent;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Toast;
import android.provider.MediaStore;
import android.app.SearchManager;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
a(getIntent());
    }

    protected void a(Intent a) {
        try {
            if (a.getStringExtra("webview") != null) {
                c49(a.getStringExtra("webview"));
                a.removeExtra("webview");
            } else if (a.getStringExtra("value") != null) {
                c49(a.getStringExtra("value"));
                a.removeExtra("value");
            } else if (a.getAction().equals(Intent.ACTION_SEND)) {
                c49(a.getStringExtra(Intent.EXTRA_TEXT));
            } else if (a.getAction().equals(Intent.ACTION_VIEW)) {
                c49(a.getDataString());
            } 
            String sub = a.getStringExtra(MediaStore.EXTRA_MEDIA_FOCUS);
            if (sub.equals(MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE)) {
                c49(a.getStringExtra("android.intent.extra.genre"));
            } else if (sub.equals(MediaStore.Audio.Playlists.ENTRY_CONTENT_TYPE)) {
                c49(a.getStringExtra("android.intent.extra.playlist"));
            } else if (sub.equals(MediaStore.EXTRA_MEDIA_RADIO_CHANNEL)) {
                c49(a.getStringExtra(MediaS
tore.EXTRA_MEDIA_RADIO_CHANNEL));
            } else if (sub.equals(MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)) {
                c49(a.getStringExtra(Media
Store.EXTRA_MEDIA_ARTIST));
            } else if (sub.equals(MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE)) {
                c49(a.getStringExtra(Medi
aStore.EXTRA_MEDIA_ALBUM));
            } else if (sub.equals(MediaStore.EXTRA_MEDIA_TITLE)) {
                c49(a.getStringExtra(MediaStore.EXTRA_MEDIA_TITLE));
            } else if (sub.equals("vnd.android.cursor.item/*") || a.getAction().equals(Intent.ACTION_SEARCH) || sub.equals("vnd.android.cursor.item/audio") || sub.equals("audio/*")) {
                c49(a.getStringExtra(SearchManager.QUERY));
            } else if (a.getAction().equals(Intent.ACTION_MAIN)) {
                return;
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);     
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}