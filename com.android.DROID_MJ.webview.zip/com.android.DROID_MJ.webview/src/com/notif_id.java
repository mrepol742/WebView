package com;

public class notif_id {
    public static final int a = 1;
  
public static final int c = 3;
 
}