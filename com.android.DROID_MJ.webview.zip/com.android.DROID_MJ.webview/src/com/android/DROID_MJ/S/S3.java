package com.android.DROID_MJ.S;

import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import android.content.pm.Signature;
import java.io.ByteArrayInputStream;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
import android.net.http.SslCertificate;
import com.android.DROID_MJ.C.C3;
import com.android.DROID_MJ.U.U1;
import android.content.Context;
import android.content.pm.PackageInfo;
import com.id;
import com.android.DROID_MJ.webview.WebView;

public class S3 {

    public static String a(Context a, byte[] cert, String cfi, String hsh5Web) {
        try {
                InputStream input = new ByteArrayInputStream(cert);
                CertificateFactory cf = CertificateFactory.getInstance(cfi);
                X509Certificate xc = (X509Certificate) cf.generateCertificate(input);
                MessageDigest md = MessageDigest.getInstance(hsh5Web);
                byte[] publicKey = md.digest(xc.getPublicKey().getEncoded());
                StringBuilder hexString = new StringBuilder();
                for (int i = 0; i < publicKey.length; i++) {
                     String appendString = Integer.toHexString(0xFF & publicKey[i]);
                     if (appendString.length() == 1) {
                        hexString.append("0");
                     }
                                             hexString.append(appendString);
                }
                if (WebView.Application.a) {
                    U1.a(hexString.toString());
                }
                return hexString.toString();
        } catch (CertificateException e) {
            U1.a(e);
        } catch (NoSuchAlgorithmException e1) {
            U1.a(e1);
        } 
        return null;
    }
}