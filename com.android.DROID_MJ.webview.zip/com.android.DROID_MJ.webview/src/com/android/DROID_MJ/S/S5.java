package com.android.DROID_MJ.S;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class S5 extends Service {
    public IBinder onBind(Intent a) {
        return a(a);
    }

    public void onCreate() {
        super.onCreate();
        b();
    }

    public int onStartCommand(Intent a, int b, int c) {
        return c(a, b, c);
    }

    public void onDestroy() {
        super.onDestroy();
        d();
    }

    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
    }

    public int c(Intent a, int b, int c) {
        return START_REDELIVER_INTENT;
    }

    public void d() {

    }
}