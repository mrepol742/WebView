package com.android.DROID_MJ.S;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import com.android.DROID_MJ.A.A37;
import com.android.DROID_MJ.P.P15;
import android.os.Build;
import android.graphics.BitmapFactory;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.U.U1;
import com.java.DROID_MJ.U.U7;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.webview.R;
import android.os.IBinder;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.U.U4;
import com.notif_id;
import com.android.DROID_MJ.C.C5;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.preference.PreferenceManager;
import android.net.Uri;

public class S6 extends S7 {

    private static Executor er = Executors.newCachedThreadPool();
SharedPreferences sp;

    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
        U1.a("S6 Created");
    }

    public int c(Intent a, int b, int c) {
        sp =PreferenceManager.getDefaultSharedPreferences(this);
        
        P15 p = new P15() {
            public void a() {
synchronized (this) {
                e();
}
            } 
        };
        er.execute(new Thread(p));
        
        
        P15 p5 = new P15() {
            public void a() {
synchronized (this) {
                g();
}
            } 
        };
        er.execute(new Thread(p5));
        stopSelf();
        return START_REDELIVER_INTENT;
    }

    public void d() {
        U1.a("S6 Destroyed");
    }

    public void e() {
        int b = W5.e();
        int newUpdate = U6.c(U4.a(W5.m()));
        String gh = U6.b(U4.a(W5.r()));
        if (newUpdate > b) {
            f("g", getString(R.string.x11), getString(R.string.x12), notif_id.c, gh, R.drawable.j);
            U1.a("Update is available");
        } else if (newUpdate == b && com.android.DROID_MJ.webview.WebView.Application.a) {
            f("g", getString(R.string.x11), getString(R.string.x12), notif_id.c, gh, R.drawable.l);
            U1.a("Beta Update is available");
        }
    }

   private void f(String channel, String title, String text, int id, String url, int id2) {
        Notification.Builder m = A37.a(this, channel);
        m.setSmallIcon(id2);
Notification.BigTextStyle bigText = new Notification.BigTextStyle();
        bigText.bigText(text);
        bigText.setBigContentTitle(title);
        bigText.setSummaryText(getString(R.string.p20));
        m.setContentTitle(title);
        m.setContentText(text);
        m.setStyle(bigText);
        m.setColor(C5.b(this,R.color.a));
        if (sp.getBoolean("eac", true) == true) {
            m.setAutoCancel(true);
        } else {
            m.setAutoCancel(false);
        }
        m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT < 26) {
            if (sp.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sp.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sp.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sp.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
        if (sp.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
        }
            if (sp.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sp.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sp.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }    m.setLargeIcon(BitmapFactory.decodeResource(getResources(),id2));
        Intent j = new Intent(this, A21.class);
        j.putExtra("value", url);
        PendingIntent k = PendingIntent.getActivity(this, 1, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.setContentIntent(k);
if (id == notif_id.c) {
        PendingIntent pi23 = PendingIntent.getActivity(this, 0, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.c2,getString(R.string.b32),pi23);
} else{
Intent j55 = new Intent(this, A21.class);
j55.putExtra("webview", url);
PendingIntent pi235 = PendingIntent.getActivity(this, 2, j55,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.q,getString(R.string.g28).replaceAll("%a", Uri.parse(url).getHost()),pi235);
}

      NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(id, m.build());
    }

    public void g() {
        int notif = U6.c(U4.a(W5.q()));
        /*String title = U6.b(U4.a(W5.n()));
        String text = U6.b(U4.a(W5.o()));
        String ufl = U6.b(U4.a(W5.p()));*/
        if (notif > 0) {
            String neTf = U6.b(U4.a(W5.g()));
            String[] sp = neTf.split(";");
            SharedPreferences j988 = getSharedPreferences("notif1", 0);
            SharedPreferences j98855 = getSharedPreferences("notif2", 0);
            if (!j988.getString("notif1", "").equals(sp[0]) && !j98855.getString("notif2", "").equals(sp[1])) {
                f("h", sp[0],sp[1] , U7.a(U7.NOTIFICATION), sp[2],R.drawable.c );
                U1.a("Push Notification was been received");
                SharedPreferences.Editor gujh = j988.edit(); 
                gujh.putString("notif1", sp[0]);
                gujh.commit();
                SharedPreferences.Editor gujh55 = j98855.edit(); 
                gujh55.putString("notif2", sp[1]);
                gujh55.commit();
            }  
        }
    }

}