package com.android.DROID_MJ.S;

import android.content.Intent;
import java.io.File;
import android.os.IBinder;
import android.content.SharedPreferences;
import android.net.Uri;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import android.os.Environment;
import android.app.PendingIntent;
import android.app.Notification;
import android.app.NotificationManager;
import com.android.DROID_MJ.W.W13;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.preference.PreferenceManager;
import com.java.DROID_MJ.U.U5;
import android.app.Notification;
import com.android.DROID_MJ.O.O8;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.io.InputStreamReader;
import com.android.DROID_MJ.C.C1;
import java.net.MalformedURLException;
import com.java.DROID_MJ.U.U7;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.I.I3;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.A.A37;


public class S1 extends S5 {
   private static Executor er = Executors.newCachedThreadPool();

    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
O8.a();
        /*SharedPreferences b566 = getSharedPreferences("svL", 0);
        a = b566.getString("svL", new String());
        SharedPreferences b1 = getSharedPreferences("svL2", 0);
        b = b1.getString("svL2", new String());*/
        
        U1.a("S1 Created");
    }

    public int c(final Intent b34, int b5555, int c5) {
P15 p = new P15() {
public void a() {
        try {
       String a = b34.getStringExtra("a");
       String b = b34.getStringExtra("b");
a1(a, b);
           URL b5 = new URL(b);
           File a2 = new File(I3.a() + "/WebView/Downloads/" + a);
           if (!a2.exists()) {
                a2.createNewFile();
                BufferedReader c =  new BufferedReader(new InputStreamReader(b5.openStream()));   
                FileWriter fr = new FileWriter(a2, true);
                BufferedWriter br = new BufferedWriter(fr);
                String f = new String();
                while ((f = c.readLine()) != null) {
                    br.write(f);
                }            
                br.close();
                fr.close();
                
                a2(I3.a() + "/WebView/Downloads/" + a, a);
stopForeground(true);
                       C1.i(S1.this, S1.class);
 
            }  
} catch (MalformedURLException mu) {
U1.a(mu);
   C1.i(S1.this, S1.class);
        } catch (IOException io) {
            U1.a(io);
   C1.i(S1.this, S1.class);
        }
}
};
er.execute(new Thread(p));
        return START_REDELIVER_INTENT;
    }

    public void d() {
        U1.a("S1 Destroyed");
    }

    private void a1(String a, String b) {
        Notification.Builder m = A37.a(this, "a");
        m.setSmallIcon(R.drawable.c2);
        m.setContentTitle(getResources().getString(R.string.d37).replaceAll("%a", a));
        if (W13.b(b) != true) {
            m.setContentTitle(b);
        }
        m.setOngoing(true);
            m.setColor(C5.b(this,R.color.a));
        SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        m.setAutoCancel(false);
        if (Build.VERSION.SDK_INT <= 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }
        
        m.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.c2));
        /*NotificationManager nmc = NotificationManager.from(this);
        nmc.notify(2, m.build());*/
        startForeground(U7.a(U7.FOREGROUND), m.build());
    }

    private void a2(String str, String jk) {
        Notification.Builder m = A37.a(this, getResources().getString(R.string.l15));
        m.setSmallIcon(R.drawable.c2);
    Notification.BigTextStyle bigText = new Notification.BigTextStyle();

bigText.setSummaryText(getResources().getString(R.string.p20));


        if (W13.b(jk) == true) {
bigText.setBigContentTitle(getResources().getString(R.string.u20));
            m.setContentTitle(getResources().getString(R.string.u20));
            m.setContentText(jk);
bigText.bigText(jk);
        } else {
        bigText.setBigContentTitle(getResources().getString(R.string.u20)); m.setContentTitle(getResources().getString(R.string.u20));
        }
m.setStyle(bigText);
            m.setColor(C5.b(this,R.color.a));
        
        SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sq.getBoolean("eac", true) == true) {
            m.setAutoCancel(true);
        } else {
            m.setAutoCancel(false);
        }
        m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT < 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }
        
 
        m.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.c2));
Intent j55 = new Intent(this, A21.class);
j55.putExtra("webview","file:///"+ str);
        PendingIntent pi = PendingIntent.getActivity(this, 2, j55,PendingIntent.FLAG_UPDATE_CURRENT);
       m.setContentIntent(pi);
Intent j5555 = new Intent(Intent.ACTION_SEND);
      j5555.putExtra(Intent.EXTRA_STREAM, Uri.parse(str));
        PendingIntent pi23555 = PendingIntent.getActivity(this, 0, j5555,  PendingIntent.FLAG_UPDATE_CURRENT);

m.addAction(R.drawable.e,getString(R.string.a8),pi23555);
 
        PendingIntent pi235 = PendingIntent.getActivity(this, 1, j55,  PendingIntent.FLAG_UPDATE_CURRENT);

m.addAction(R.drawable.q,getString(R.string.h37),pi235);
        NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(U7.a(U7.NOTIFICATION), m.build());

    }
}