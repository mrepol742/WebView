package com.android.DROID_MJ.S;

import android.content.Intent;
import android.os.IBinder;
import com.android.DROID_MJ.webview.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.os.Build;
import com.android.DROID_MJ.C.C5;
import android.graphics.BitmapFactory;
import android.app.Notification;
import android.content.ClipboardManager;
import com.android.DROID_MJ.W.W13;
import android.webkit.URLUtil;
import android.content.Context;
import android.app.PendingIntent;
import com.android.DROID_MJ.A.A21;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import android.content.ClipData;
import com.java.DROID_MJ.U.U7;
import android.os.Handler;
import android.content.ClipboardManager.OnPrimaryClipChangedListener;
import com.android.DROID_MJ.A.A37;

public class S4 extends S5 {
 ClipboardManager a;
 OnPrimaryClipChangedListener b   =    new OnPrimaryClipChangedListener() {
                public void onPrimaryClipChanged() {
ClipData c56 = a.getPrimaryClip();
            ClipData.Item d34 = c56.getItemAt(0);
if (d34.getText().toString() == null && d34.getText().toString().length() == 0) {
return;
}
                    String sg = d34.getText().toString();
  if (W13.b(sg.toLowerCase()) == true) {
                    if (URLUtil.isValidUrl(sg)) {
   if (W13.a(sg) == true) {
                        a(sg);
} 
} 

                    } 
g();
                }
            };
static boolean c = false;
 
    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
        U1.a("S4 Created");
    }

    public int c(Intent a1, int b, int c) {

           a = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        e();
        return START_REDELIVER_INTENT;

    }

    public void d() {
        U1.a("S4 Destroyed");
f();
    }

   private void a(String jk) {
        Notification.Builder m = A37.a(this, "f");
        m.setSmallIcon(R.drawable.b16);
        m.setContentTitle(getResources().getString(R.string.x7));
        m.setContentText(jk);
Notification.BigTextStyle bigText = new Notification.BigTextStyle();
                            bigText.bigText(jk);
                            bigText.setBigContentTitle(getResources().getString(R.string.x7));
                            bigText.setSummaryText(getResources().getString(R.string.p20));
         
         
m.setStyle(bigText);

            m.setColor(C5.b(this,R.color.a));
                SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

   if (sq.getBoolean("eac", true) == true) {
        m.setAutoCancel(true);
    } else {
       m.setAutoCancel(false);
    }
m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT <= 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
           
 } m.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.b16));
        Intent j = new Intent(this, A21.class);
        j.putExtra("value", jk);
        PendingIntent k = PendingIntent.getActivity(this, 1, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.setContentIntent(k);
Intent j55 = new Intent(Intent.ACTION_SEND);
j55.setType("text/plain");
        j55.putExtra("android.intent.extra.TEXT",jk);
PendingIntent pi235 = PendingIntent.getActivity(this, 0, j55,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.e,getString(R.string.a8),pi235);
        NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(U7.a(U7.NOTIFICATION), m.build());
    }

private void e(){
    if(!c){
       a.addPrimaryClipChangedListener(b);
        c = true;
    }
}
private void f(){
    if(c){
        a.removePrimaryClipChangedListener(b);
        c = false;
    }
}
private void g(){
a.removePrimaryClipChangedListener(b);
final Handler handler = new Handler();
    handler.postDelayed(new Runnable() {
        @Override
        public void run() {
         a.addPrimaryClipChangedListener(b);
        }
    }, 500);
}
}