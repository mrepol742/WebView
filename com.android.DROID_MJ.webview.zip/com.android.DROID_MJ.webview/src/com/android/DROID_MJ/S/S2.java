package com.android.DROID_MJ.S;

import android.content.Intent;
import java.io.File;
import android.os.IBinder;
import android.content.SharedPreferences;
import android.net.Uri;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import android.os.Environment;
import android.app.PendingIntent;
import android.app.Notification;
import android.app.NotificationManager;
import com.android.DROID_MJ.W.W13;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.preference.PreferenceManager;
import com.java.DROID_MJ.U.U5;
import android.app.Notification;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.I.I3;
import com.java.DROID_MJ.U.U7;
import com.android.DROID_MJ.A.A37;


public class S2 extends S5 {
    private static String a;
  
    public IBinder a(Intent a6) {
        return null;
    }

    public void b() {
        U1.a("S2 Created");
    }

    public int c(Intent a1, int b55, int c555) {
        try {
            SharedPreferences b = getSharedPreferences("downLOADS", 0);
            a = b.getString("downLOADS", new String());
      
 
Uri contentUri = Uri.fromFile(new File(I3.a() + "/WebView/Downloads/" + a));
Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE); 
mediaScanIntent.setData(contentUri);
sendBroadcast(mediaScanIntent);
a("file://"+I3.a()+"/WebView/Downloads/" + a, a);

   C1.i(S2.this, S2.class);


       C1.i(S2.this, S8.class); 
    
           } catch (Exception ex) {
               U1.a(ex);
           }
        return START_REDELIVER_INTENT;
    }

    public void d() {
        U1.a("S2 Destroyed");
    }

    private void a(String str, String jk) {
        Notification.Builder m = A37.a(this, "c");
        m.setSmallIcon(R.drawable.c2);



Notification.BigTextStyle bigText = new Notification.BigTextStyle();

bigText.setSummaryText(getResources().getString(R.string.p20));


        if (W13.b(jk) == true) {
bigText.setBigContentTitle(getResources().getString(R.string.u20));
            m.setContentTitle(getResources().getString(R.string.u20));
            m.setContentText(jk);
bigText.bigText(jk);
        } else {
        bigText.setBigContentTitle(getResources().getString(R.string.u20)); m.setContentTitle(getResources().getString(R.string.u20));
        }
m.setStyle(bigText);
            m.setColor(C5.b(this,R.color.a));
        
        SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sq.getBoolean("eac", true) == true) {
            m.setAutoCancel(true);
        } else {
            m.setAutoCancel(false);
        }
        m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT <= 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }
 
        m.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.c2));
        b(m, " file://"+Environment.getExternalStorageDirectory().getAbsolutePath() +"/WebView/Downloads/" + a);
        c(m, str);
        NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(U7.a(U7.NOTIFICATION), m.build());
    }

    private void b(Notification.Builder nc, String str) {
        Intent it = new Intent(Intent.ACTION_VIEW);
        if (W13.c(str) == false) {
            it.setType("audio/*");
            it.setData(Uri.fromFile(new File(str)));
            // aDo
        } else if (W13.d(str) == false) {
            it.setType("video/*");
            it.setData(Uri.fromFile(new File(str)));
            // vOg
        } else if (W13.e(str) == false) {
            it.setType("image/*");
            it.setData(Uri.fromFile(new File(str)));
            //mGa
        } else if (W13.f(str) == false) {
            it.setType("text/*");
            it.setData(Uri.fromFile(new File(str)));
           // tTfL
        } else if (W13.g(str) == false) {
            it.setType("application/*");
            it.setData(Uri.fromFile(new File(str)));
        } else if (str.endsWith(".apk")) {
            it.setDataAndType(Uri.fromFile(new File(str)),"application/vnd.android.package-archive");
        } else {
            it.setType("*/*");
            it.setData(Uri.fromFile(new File(str)));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 1, it,PendingIntent.FLAG_UPDATE_CURRENT);
        nc.setContentIntent(pi);
    }

    private void c(Notification.Builder nc, String str) {
        Intent it = new Intent();
        it.setAction(Intent.ACTION_SEND);
        if (W13.c(str) == false) {
            it.setType("audio/*");
            // aDo
        } else if (W13.d(str) == false) {
            it.setType("video/*");
            // vOg
        } else if (W13.e(str) == false) {
            it.setType("image/*");
            //mGa
        } else if (W13.f(str) == false) {
            it.setType("text/*");
           // tTfL
        } else if (str.endsWith(".zip")) {
            it.setType("zip/*");
        } else if (str.endsWith(".apk")) {
            it.setType("apk/*");
        } else {
            it.setType("*/*");
        }
        it.putExtra(Intent.EXTRA_STREAM, Uri.parse(str));
        PendingIntent g = PendingIntent.getActivity(this, 0, it,  PendingIntent.FLAG_UPDATE_CURRENT);
        nc.addAction(R.drawable.e, getResources().getString(R.string.a8),g);
    }
}