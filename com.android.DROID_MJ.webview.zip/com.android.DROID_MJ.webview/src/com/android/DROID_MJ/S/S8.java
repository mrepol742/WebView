package com.android.DROID_MJ.S;
import android.content.Intent;
import android.os.IBinder;
import android.content.SharedPreferences;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import android.app.Notification;
import android.os.Build;
import android.preference.PreferenceManager;
import android.app.Notification;
import android.graphics.BitmapFactory;
import com.android.DROID_MJ.R.R37;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import com.android.DROID_MJ.R.R7;
import com.java.DROID_MJ.U.U7;
import com.android.DROID_MJ.A.A37;
public class S8 extends S5 {
 private BroadcastReceiver br = new R37();
private BroadcastReceiver br1 = new R7();
    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
        a1();
        U1.a("S8 Created");

registerReceiver(br, new IntentFilter("android.intent.action.DOWNLOAD_NOTIFICATION_CLICKED"));
registerReceiver(br1, new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));

    }

    public int c(Intent a, int b, int c) {
        return START_REDELIVER_INTENT;

    }

    public void d() {
unregisterReceiver(br);
unregisterReceiver(br1);
        U1.a("S8 Destroyed");
    }

    private void a1() {
        Notification.Builder m = A37.a(this, "d");
        m.setSmallIcon(R.drawable.c2);
        m.setContentTitle(getResources().getString(R.string.d38));
        m.setOngoing(true);
            m.setColor(C5.b(this,R.color.a));
        
        SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        m.setAutoCancel(false);

        if (Build.VERSION.SDK_INT <= 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            
        }
        m.setLargeIcon(BitmapFactory .decodeResource(getResources(),R.drawable.c2));
       /* NotificationManager nmc = NotificationManager.from(this);
        nmc.notify(5, m.build());*/
        startForeground(U7.a(U7.FOREGROUND), m.build());
    }
  
}