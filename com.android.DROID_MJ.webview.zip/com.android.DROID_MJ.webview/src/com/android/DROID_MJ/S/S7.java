package com.android.DROID_MJ.S;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import android.os.IBinder;
import com.android.DROID_MJ.A.A36;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.W.W13;
import com.android.DROID_MJ.W.W5;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class S7 extends S5 {
    private static Executor er = Executors.newCachedThreadPool();
    public IBinder a(Intent a) {
        return null;
    }

    public void b() {
        U1.a("S7 Created");
    }

    public int c(Intent a, int b, int c) {
            P15 p = new P15() {
                public void a() {
synchronized (this) {
                    String text5555 = U6.b(U4.a(W5.w()));
                    if (W13.l(text5555.replaceAll(" ", ""))) {
                        C1.a(S7.this, A36.class);
                    }     
}
               }
            };
       
       er.execute(new Thread(p)); 
       stopSelf();
       return START_REDELIVER_INTENT;
    }

    public void d() {
        U1.a("S7 Destroyed");
    }
}