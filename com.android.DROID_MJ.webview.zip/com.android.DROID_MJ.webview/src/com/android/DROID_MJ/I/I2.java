package com.android.DROID_MJ.I;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import com.java.DROID_MJ.U.U6;
import com.android.DROID_MJ.U.U1;

public class I2 {


    public static boolean a(String str, String str2) { 
        File fe = new File(str);
        File fe2 = new File(str2);
        if (fe.exists()) {
            try {
                InputStream c = new FileInputStream(fe);
                OutputStream d = new FileOutputStream(fe2);
                byte[] e = new byte[1024];
                int f;
                while ((f = c.read(e)) > 0) {
                       d.write(e, 0, f);
                }
               
                c.close();
                c = null;
                d.flush();
                d.close(); 
                return true;
            } catch (FileNotFoundException fnfe) {
                U1.a(fnfe);
            } catch (IOException ioe) {
                U1.a(ioe);
            }
        }
        return false;
    }

    public static boolean a(String a, String b, int i) {
       if (i ==  5) {
          return U6.a(a, b);
       } else if (i == 20) {
          return U6.c(a, b);
       }
       return true;
    }

}