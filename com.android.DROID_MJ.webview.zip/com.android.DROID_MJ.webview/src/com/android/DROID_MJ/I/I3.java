package com.android.DROID_MJ.I;
import android.os.Environment;

public class I3 {
    public static String a() {
        return Environment.getExternalStorageDirectory().getAbsolutePath();
// return /storage/emulated/0/
    }

    public static String b() {
        return "/data/data/com.android.DROID_MJ.webview/";
// return /data/data/com.android.DROID_MJ.webview/
    }

    public static String c() {
        return "/data/data/com.android.DROID_MJ.webview/cache/";
// return /data/data/com.android.DROID_MJ.webview/
    }

    public static String d() {
        return a() + "/WebView/";
// return /data/data/com.android.DROID_MJ.webview/
    }

}