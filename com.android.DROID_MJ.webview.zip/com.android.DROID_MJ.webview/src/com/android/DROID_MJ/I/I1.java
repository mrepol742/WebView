package com.android.DROID_MJ.I;

import com.android.DROID_MJ.U.U1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import android.os.Environment;

public class I1 {
    public static void a(String a, int b) {
        try {
            File c = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+a);
            if (!c.exists()) {
                if (b == 0) {
                    c.createNewFile();
                } else if (b == 1) {
                    c.mkdir();
                }
            } else if (b == 2) {
                c.delete();
            }

        } catch (FileNotFoundException ab) {
            U1.a(ab);
        } catch (IOException bh) {
            U1.a(bh);
        }
    }

    public static void b(String a, String b, int e) {
        try {
            File c = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+a);
            File d = new File(b);
            if (c.exists()) {
                if (c.renameTo(d)) {
                    if (e == 0) {
                        c.delete();
                    }
                }
            }
        } catch (Exception ab) {
            U1.a(ab);
        }
    }
}