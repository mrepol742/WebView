package com.android.DROID_MJ.P;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.webview.R;
public class P3 extends P14 {

private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.c);
            A10.h18.setText(getActivity().getResources().getString(R.string.a));

            final ListPreference hj9 = (ListPreference) findPreference("general");
            final EditTextPreference hj89 = (EditTextPreference) findPreference("cGeneral");
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
            SharedPreferences a19 = getActivity().getSharedPreferences("MyURL", 0);
            final String a20 = a19.getString("MyURL", new String());
            if (sp.getString("general", "").equals("1o")) {
                hj9.setSummary(getActivity().getResources().getString(R.string.x17));
                hj89.setEnabled(false);
            } else if (sp.getString("general", "").equals("7o")) {
                hj9.setSummary(a20);
                hj89.setEnabled(false);
            } else if (sp.getString("general", "").equals("30o")) {
                hj9.setSummary(getActivity().getResources().getString(R.string.c26));
                hj89.setEnabled(false);
            } else if (sp.getString("general", "").equals("60o")) {               hj9.setSummary(getActivity().getResources().getString(R.string.q20));
                hj89.setEnabled(true);
            }
            hj89.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                   
  hj89.setSummary(newValue.toString());
                    return true;
                }
            });
            hj9.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("1o")) {                       hj9.setSummary(getActivity().getResources().getString(R.string.x17));
                        hj89.setEnabled(false);
                    } else if (newValue.toString().equals("7o")) {
                        hj9.setSummary(a20);
                        hj89.setEnabled(false);
                    } else if (newValue.toString().equals("30o")) {
                        hj9.setSummary(getActivity().getResources().getString(R.string.c26));
                        hj89.setEnabled(false);
                    } else if (newValue.toString().equals("60o")) {
                        hj89.setEnabled(true);
                        hj9.setSummary(getActivity().getResources().getString(R.string.q20));
                    }
                    return true;
                }
            });
Preference a1 = (Preference) findPreference("cfu");
                a1.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                     a10.b12();
                        return true;
                    }
               });
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}