package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import android.preference.Preference;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;
import android.content.pm.ApplicationInfo;
import android.os.CountDownTimer;
import android.preference.SwitchPreference;
import com.android.DROID_MJ.U.U4;

public class P5 extends P14 {


  private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
           addPreferencesFromResource(R.xml.d);
           A10.h18.setText(getActivity().getResources().getString(R.string.e));
           final SwitchPreference d = (SwitchPreference) findPreference("voice");
           final ApplicationInfo ai = getActivity().getPackageManager().getApplicationInfo(U4.a("Y29tLmdvb2dsZS5hbmRyb2lkLmdvb2dsZXF1aWNrc2VhcmNoYm94"),0);
           final boolean d66 = ai.enabled;
           if (d66 != true) {
                d.setChecked(false);
           } 
           d.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
               public boolean onPreferenceChange(Preference preference, Object newValue) {
                   if (d66 != true) {
                       d.setChecked(false);
                       a10.n();
                   } else {
                       d.setChecked(true);
                   }
                   return true;
               }
           });
            Preference b = (Preference) findPreference("asst");
            b.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.b14();
                     return true;
                }
            });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}