package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import android.preference.Preference;
import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import android.os.Build;
import com.android.DROID_MJ.C.C1;
import android.preference.SwitchPreference;
import com.android.DROID_MJ.S.S4;
import android.webkit.CookieManager;
import android.webkit.WebViewDatabase;


public class P8 extends P14 {
    private static CookieManager cm;
    private static A10 a10;
    private static WebViewDatabase wd;
    public void a(Bundle b1) {
            try {
             cm = CookieManager.getInstance();
             wd = WebViewDatabase.getInstance(getActivity());
             a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.g);
SharedPreferences sp688 = PreferenceManager.getDefaultSharedPreferences(getActivity());

            A10.h18.setText(getActivity().getResources().getString(R.string.b));
            final EditTextPreference etp = (EditTextPreference) findPreference("CustomuserA");
            
            if (sp688.getString("userA", "").equals("7680e")) {
                etp.setEnabled(true);
            } else {
                etp.setEnabled(false);
            }
            etp.setSummary(sp688.getString("CustomuserA", new String()));
            etp.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    etp.setSummary(newValue.toString());
                    return true;
                }
            });
            final ListPreference lp67 = (ListPreference) findPreference("userA");
            lp67.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("7680e")) {
                        etp.setEnabled(true);
                    } else {
                        etp.setEnabled(false);
                    }
                    return true;
                }
            });
            Preference f = (Preference) findPreference("clearCache");
            f.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.u();
                    return true;
                }
            });
            Preference f6 = (Preference) findPreference("clearBook");
            f6.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.a1();
                    return true;
                }
            });
            Preference f67 = (Preference) findPreference("clearSSL");
            f67.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.a2();
                    return true;
                }
            });
            Preference f6767 = (Preference) findPreference("clearHTTP");
            f6767.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
if (wd.hasHttpAuthUsernamePassword()) {
                    a10.a4();
}
                    return true;
                }
            });

            Preference f2 = (Preference) findPreference("clearSearch");
            f2.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.a3();
                    return true;
                }
            });
            Preference g = (Preference) findPreference("clearHistory");
            g.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.v();
                    return true;
                }
            });
        final    Preference h = (Preference) findPreference("clearCookies");
            h.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     
            if (cm.hasCookies()) {
 a10.w(0);
            }
                    return true;
                }
            });
         final   Preference hS = (Preference) findPreference("clearSCookies");
            hS.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    
            if (cm.hasCookies()) {
                a10.w(1);
            }
                    return true;
                }
            });
            if (!cm.hasCookies()) {
                h.setEnabled(false);
                hS.setEnabled(false);
            }
            Preference i = (Preference) findPreference("clearForm");
            i.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
if (wd.hasFormData()) {
                    a10.x();
}
                    return true;
                }
            });
            Preference j = (Preference) findPreference("clearLocation");
            j.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.y();
                    return true;
                }
            });
 
            Preference j5 = (Preference) findPreference("clearClipboard");
            j5.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.b8();
                    return true;
                }
            });
       SwitchPreference  cbf = (SwitchPreference) findPreference("nCV");
            cbf.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("true")) {

                    C1.b(getActivity(), S4.class);

                    } else {

                     C1.i(getActivity(), S4.class);

                    }
                    return true;
                }
            });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}