package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import android.preference.Preference;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;

public class P7 extends P14 {

  private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.o);
            A10.h18.setText(getActivity().getResources().getString(R.string.o10));
            Preference b = (Preference) findPreference("autoUpdate");
            b.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.t(1);
                     return true;
                }
            });
            Preference b742 = (Preference) findPreference("autoUpdate742");
            b742.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.t(0);
                     return true;
                }
            });
            Preference a4 = (Preference) findPreference("cus");
            a4.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.s();
                     return true;
                }
            });

            Preference a7 = (Preference) findPreference("webviewB");
            a7.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.t(0);
                     return true;
                }
            });
            Preference a76 = (Preference) findPreference("alWV");
            a76.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.b9();
                     return true;
                }
            });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}