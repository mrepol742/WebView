package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.webview.R;
import android.preference.SwitchPreference;
import android.preference.Preference;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.T.T2;
import android.content.SharedPreferences;
import android.widget.EditText;
import android.preference.PreferenceManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.android.DROID_MJ.C.C6;
import android.text.Editable;
import android.view.LayoutInflater;
import android.widget.Button;
import com.android.DROID_MJ.T.T6;
import android.text.InputType;
import android.view.View;   
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W1;
import android.content.DialogInterface.OnDismissListener;
import java.security.SecureRandom;
import com.java.DROID_MJ.S.S1;
import android.view.WindowManager;

public class P13 extends P14 {
    private SwitchPreference spe;
    public void a(Bundle b1) {
        try {
        addPreferencesFromResource(R.xml.q);
            spe = (SwitchPreference) findPreference("lockWn99");
            spe.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("true")) {
                        a();
                    } else {
                        e();
                    }
                    return true;
                }
            });
Preference a1 = (Preference) findPreference("cHPIN");
                a1.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                       i();
                        return true;
                    }
               });
Preference a12 = (Preference) findPreference("cLPIN");
                a12.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                       k();
                        return true;
                    }
               });
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    private void a() {
        SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
        String sg = a.getString("bhJmWwkvsbQJD", "");
        String sjs = sg.replaceAll(" ", "");
        if (sjs.length() == 0) {
            b();        
        } else {
            d();      
        }
    }

    private void b() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.u, null);
        a5.setCancelable(false); 
        a5.setTitle(getActivity().getResources().getString(R.string.c4));
       a5.setView(a7);

       final EditText e15= (EditText) a7.findViewById(R.id.e15);
       final EditText a67= (EditText) a7.findViewById(R.id.a6);
   int c = C5.b(getActivity(), R.color.c);
      int d1 = C5.b(getActivity(), R.color.b);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
       if (sp.getBoolean("autoUpdate", false) == false) {
           a67.setTextColor(c);
           e15.setTextColor(c);
       } else {
           a67.setTextColor(d1);
           e15.setTextColor(d1);
       }
       e15.setHint(getActivity().getResources().getString(R.string.g6));
       a67.setHint(getActivity().getResources().getString(R.string.l1));
       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       a67.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       e15.setTransformationMethod(new T2());
       a67.setTransformationMethod(new T2());       a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
                c(a67.getText().toString());
                W1.a(getActivity(), getActivity().getResources().getString(R.string.l3), 0);
                spe.setChecked(true);
                a.dismiss();
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
                spe.setChecked(false);
                a.dismiss();
  	         } 
  	     });
        final AlertDialog d = a5.create();
d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        a67.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4) {
                        if (a67.getText().toString().equals(e15.getText().toString())) {
                            okButton.setEnabled(true); 
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        e15.addTextChangedListener(new T6() {
             private void a() {
                  final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                  if (e15.getText().toString().length() >= 4) {
                      if (a67.getText().toString().length() >= 4) {
                          if (a67.getText().toString().equals(e15.getText().toString())) {
                              okButton.setEnabled(true); 
                          } else {
                              okButton.setEnabled(false);
                          }
                      } else {
                          okButton.setEnabled(false);
                      }
                  } else {
                      okButton.setEnabled(false);
                  }
              }
              public void c(Editable arg0) {
              }
              public void a(CharSequence s, int start, int count, int after) {
              }
              public void b(CharSequence s, int start, int before, int count) {
                  a();
              }
          });
          d.show();
          d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
          } 


private void c(String a1) {
SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
   
SharedPreferences.Editor b5 = a.edit(); 
 b5.putString("bhJmWwkvsbQJD", S1.a("SHA-512",a1));
 b5.apply();
 
}

private void d() {

AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
       LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.r, null);
        a5.setCancelable(false); 
        a5.setTitle(getActivity().getResources().getString(R.string.c5));
       a5.setView(a7);
final  EditText e15= (EditText) a7.findViewById(R.id.e14);
 

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e15.setTextColor(a15);

        } else {

e15.setTextColor(a16);
        }
e15.setHint(getActivity().getResources().getString(R.string.g6));

       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e15.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
h(e15.getText().toString());
        a.dismiss();
           
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
spe.setChecked(false);
                a.dismiss();
  	         } 
  	       	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e15.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
    if (e15.getText().toString().length() >= 4) {
      

         okButton.setEnabled(true); 
}else {
okButton.setEnabled(false); 
}
     
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});
d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void e() {
AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
   LayoutInflater a6 = LayoutInflater.from(getActivity());
    View a7 = a6.inflate(R.layout.t, null);
     a5.setCancelable(false); 
     a5.setTitle(getActivity().getResources().getString(R.string.h15));
  a5.setView(a7);

    final EditText e16 = (EditText)a7.findViewById(R.id.e16);
  

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e16.setTextColor(a15);

        } else {

e16.setTextColor(a16);
        }
e16.setHint(getActivity().getResources().getString(R.string.g6));
       e16.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e16.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
g(e16.getText().toString());
        a.dismiss();
     
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
spe.setChecked(true);
                a.dismiss();
  	         } 
  	     	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e16.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
   if (e16.getText().toString().length() >= 4) {
         
okButton.setEnabled(true);

       } else {
okButton.setEnabled(false);
}
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});

d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void h(String a1) {
             SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
String c727 = a.getString("bhJmWwkvsbQJD", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) { 

spe.setChecked(true);

} else {
spe.setChecked(false);
W1.a(getActivity(), getActivity().getResources().getString(R.string.l2), 0);
}
      
}
}

private void g(String a1) {
            SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
String c727 = a.getString("bhJmWwkvsbQJD", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) {

spe.setChecked(false);

} else {
spe.setChecked(true);
W1.a(getActivity(), getActivity().getResources().getString(R.string.l2), 0);
}
      
}
}


    private void i() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.c1, null);
        a5.setCancelable(true); 
        a5.setTitle(getActivity().getResources().getString(R.string.j38));
       a5.setView(a7);
       final EditText e15= (EditText) a7.findViewById(R.id.l13);
       final EditText a67= (EditText) a7.findViewById(R.id.l14);
       final EditText l15= (EditText) a7.findViewById(R.id.l15);

       int c = C5.b(getActivity(), R.color.c);
       int d1 = C5.b(getActivity(), R.color.b);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
       if (sp.getBoolean("autoUpdate", false) == false) {
           a67.setTextColor(c);
           e15.setTextColor(c);
           l15.setTextColor(c);
       } else {
           a67.setTextColor(d1);
           e15.setTextColor(d1);
           l15.setTextColor(d1);
       }
       e15.setHint(getActivity().getResources().getString(R.string.j39));
       a67.setHint(getActivity().getResources().getString(R.string.j40));
l15.setHint(getActivity().getResources().getString(R.string.k21));
       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       a67.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       l15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       e15.setTransformationMethod(new T2());
       a67.setTransformationMethod(new T2()); 
       l15.setTransformationMethod(new T2());       a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
                j(e15.getText().toString(), l15.getText().toString());
               
                a.dismiss();
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
                
                a.dismiss();
  	         } 
  	     });
        final AlertDialog d = a5.create();
d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        a67.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        e15.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  l15.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
          d.show();
          d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
          } 

     private void j(String a1, String a2) {
         SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
         String c727 = a.getString("bhJmWwkvsbQJD", "");
         if (c727 != null ) {
             if (S1.a("SHA-512",a1).equals(c727)) {
                 SharedPreferences.Editor b5 = a.edit();
                 b5.putString("bhJmWwkvsbQJD", S1.a("SHA-512",a2));
                 b5.apply();
W1.a(getActivity(), getActivity().getResources().getString(R.string.k22), 0);
             } else {
                 W1.a(getActivity(), getActivity().getResources().getString(R.string.l2), 0);
             } 
        }
    }

    private void k() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.t, null);
        a5.setCancelable(true); 
     a5.setTitle(getActivity().getResources().getString(R.string.k23));
       a5.setView(a7);

    final EditText e16 = (EditText)a7.findViewById(R.id.e16);
  

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e16.setTextColor(a15);

        } else {

e16.setTextColor(a16);
        }
e16.setHint(getActivity().getResources().getString(R.string.g6));
       e16.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e16.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
l(e16.getText().toString());
        a.dismiss();
     
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {

                a.dismiss();
  	         } 
  	     	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e16.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
   if (e16.getText().toString().length() >= 4) {
         
okButton.setEnabled(true);

       } else {
okButton.setEnabled(false);
}
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});

d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void l(String a1) {
             SharedPreferences a= getActivity().getSharedPreferences("bhJmWwkvsbQJD", 0);
String c727 = a.getString("bhJmWwkvsbQJD", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) { 

 SharedPreferences.Editor b5 = a.edit();
                 b5.clear();
                 b5.apply();
W1.a(getActivity(), getActivity().getResources().getString(R.string.k24), 0);
spe.setChecked(false);
} else {
 
W1.a(getActivity(), getActivity().getResources().getString(R.string.l2), 0);
}
      
}
}



}