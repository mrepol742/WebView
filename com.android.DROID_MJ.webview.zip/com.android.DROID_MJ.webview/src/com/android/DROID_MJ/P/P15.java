package com.android.DROID_MJ.P;

public class P15 implements Runnable {
    public void run() { 
        a();
    }

    public void a() { 
 
    }
}

 