package com.android.DROID_MJ.P;
import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
import android.preference.Preference;
public class P11 extends P14 {
    private static A10 a10;
    public void a(Bundle b1) {
        try {
            addPreferencesFromResource(R.xml.u);
            A10.h18.setText(getActivity().getResources().getString(R.string.t7));
            a10 = A10.getInstance();
Preference a7 = (Preference) findPreference("cFNT");
            a7.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.t(0);
                     return true;
                }
            });
            Preference a455 = (Preference) findPreference("cfnt5");
            a455.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.b20();
                     return true;
                }
            });
            Preference a433 = (Preference) findPreference("cfnt2");
            a433.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.b22();
                     return true;
                }
            });

        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}
