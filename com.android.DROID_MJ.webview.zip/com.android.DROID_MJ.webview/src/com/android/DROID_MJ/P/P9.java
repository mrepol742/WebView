package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import android.preference.Preference;
import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import android.os.Build;
import com.android.DROID_MJ.A.A5;
import com.android.DROID_MJ.A.A32;
import com.android.DROID_MJ.C.C1;
import com.java.DROID_MJ.S.S1;
import android.preference.SwitchPreference;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.android.DROID_MJ.W.W1;
import android.text.InputType;
import com.android.DROID_MJ.T.T2;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.T.T6;
import com.android.DROID_MJ.C.C10;
import android.view.WindowManager;

public class P9 extends P14 {
    private static SwitchPreference spe;

    public void a(Bundle b1) {
            try {

            addPreferencesFromResource(R.xml.f);
            A10.h18.setText(getActivity().getResources().getString(R.string.c));
            final ListPreference lp90 = (ListPreference) findPreference("textE");
            final EditTextPreference etp12 = (EditTextPreference) findPreference("CtextE");
          final  SharedPreferences sp6887 = PreferenceManager.getDefaultSharedPreferences(getActivity());
            if (sp6887.getString("textE", "").equals("3840a")) {
                etp12.setEnabled(true);
            } else {
                etp12.setEnabled(false);
            }
            etp12.setSummary(sp6887.getString("CtextE", new String()));
            etp12.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    etp12.setSummary(newValue.toString());
                    return true;
                }
            });
            lp90.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("3840a")) {
                        etp12.setEnabled(true);
                    } else {
                        etp12.setEnabled(false);
                    }
                    return true;
                }
            });
            Preference a9 = (Preference) findPreference("wLock");
            a9.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
       
   if (sp6887.getBoolean("lockWn99", false) ==true){
          
              C1.a(getActivity(), A32 .class);
 
            } else {
  C1.a(getActivity(), A5.class);
}
                    return true;
                }
            });
final SwitchPreference java9 = (SwitchPreference)findPreference("Java9");
final SwitchPreference java10 = (SwitchPreference)findPreference("Java10");
final SwitchPreference java11 = (SwitchPreference)findPreference("Java11");
final SwitchPreference java12 = (SwitchPreference)findPreference("Java12");
 ListPreference java = (ListPreference) findPreference("java");
java.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("7f")) {
                       java9.setEnabled(false);
       java10.setEnabled(false);
       java11.setEnabled(false);
       java12.setEnabled(false);
                    } else {
                          java9.setEnabled(true);
       java10.setEnabled(true);
       java11.setEnabled(true);
       java12.setEnabled(true);
                    }
                    return true;
                }
            });

             spe = (SwitchPreference) findPreference("ptm");
            spe.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    if (newValue.toString().equals("true")) {
                        a();
                    } else {
                        e();
                    }
                    return true;
                }
            });
Preference a1 = (Preference) findPreference("cHANS");
                a1.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                       i();
                        return true;
                    }
               });
Preference a12 = (Preference) findPreference("cLANS");
                a12.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                       k();
                        return true;
                    }
               });
            Preference a967 = (Preference) findPreference("enableSWDD");
            a967.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
            A10.getInstance().t(0);
                    return true;
                }
            });
           Preference pc = (Preference) findPreference("cjsa");
           pc.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
            A10.getInstance().b26();
                    return true;
                }
            });
Preference a96755 = (Preference) findPreference("admn");
            a96755.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
            A10.getInstance().b16();
                    return true;
                }
            });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }

    private void a() {
        SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
        String sg = a.getString("gsJsGsKSIgPes", "");
        String sjs = sg.replaceAll(" ", "");
        if (sjs.length() == 0) {
            b();        
        } else {
            d();      
        }
    }

    private void b() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.u, null);
        a5.setCancelable(false); 
        a5.setTitle(getActivity().getResources().getString(R.string.j28));
       a5.setView(a7);
       final EditText e15= (EditText) a7.findViewById(R.id.e15);
       final EditText a67= (EditText) a7.findViewById(R.id.a6);

   int c = C5.b(getActivity(), R.color.c);
      int d1 = C5.b(getActivity(), R.color.b);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
       if (sp.getBoolean("autoUpdate", false) == false) {
           a67.setTextColor(c);
           e15.setTextColor(c);
       } else {
           a67.setTextColor(d1);
           e15.setTextColor(d1);
       }
       e15.setHint(getActivity().getResources().getString(R.string.j29));
       a67.setHint(getActivity().getResources().getString(R.string.j30));
       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       a67.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       e15.setTransformationMethod(new T2());
       a67.setTransformationMethod(new T2());       a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
                c(a67.getText().toString());
                W1.a(getActivity(), getActivity().getResources().getString(R.string.j31), 0);
                spe.setChecked(true);
                a.dismiss();
C10.a(getActivity(),"com.android.DROID_MJ.a14", 1);
C10.a(getActivity(),"com.android.DROID_MJ.d", 2);
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
                spe.setChecked(false);
                a.dismiss();

  	         } 
  	     });
        final AlertDialog d = a5.create();
d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        a67.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4) {
                        if (a67.getText().toString().equals(e15.getText().toString())) {
                            okButton.setEnabled(true); 
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        e15.addTextChangedListener(new T6() {
             private void a() {
                  final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                  if (e15.getText().toString().length() >= 4) {
                      if (a67.getText().toString().length() >= 4) {
                          if (a67.getText().toString().equals(e15.getText().toString())) {
                              okButton.setEnabled(true); 
                          } else {
                              okButton.setEnabled(false);
                          }
                      } else {
                          okButton.setEnabled(false);
                      }
                  } else {
                      okButton.setEnabled(false);
                  }
              }
              public void c(Editable arg0) {
              }
              public void a(CharSequence s, int start, int count, int after) {
              }
              public void b(CharSequence s, int start, int before, int count) {
                  a();
              }
          });
          d.show();
          d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
          } 


private void c(String a1) {
SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
   
SharedPreferences.Editor b5 = a.edit(); 
 b5.putString("gsJsGsKSIgPes", S1.a("SHA-512",a1));
 b5.apply();
 
}

private void d() {

AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
       LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.r, null);
        a5.setCancelable(false); 
        a5.setTitle(getActivity().getResources().getString(R.string.j32));
       a5.setView(a7);
final  EditText e15= (EditText) a7.findViewById(R.id.e14);
 

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e15.setTextColor(a15);

        } else {

e15.setTextColor(a16);
        }
e15.setHint(getActivity().getResources().getString(R.string.j29));

       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e15.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
h(e15.getText().toString());
        a.dismiss();
           
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
spe.setChecked(false);
                a.dismiss();
  	         } 
  	       	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e15.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
    if (e15.getText().toString().length() >= 4) {
      

         okButton.setEnabled(true); 
}else {
okButton.setEnabled(false); 
}
     
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});
d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void e() {
AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
   LayoutInflater a6 = LayoutInflater.from(getActivity());
    View a7 = a6.inflate(R.layout.t, null);
     a5.setCancelable(false); 
     a5.setTitle(getActivity().getResources().getString(R.string.j33));
  a5.setView(a7);

    final EditText e16 = (EditText)a7.findViewById(R.id.e16);
  

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e16.setTextColor(a15);

        } else {

e16.setTextColor(a16);
        }
e16.setHint(getActivity().getResources().getString(R.string.j29));
       e16.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e16.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
g(e16.getText().toString());
        a.dismiss();
     
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
spe.setChecked(true);
                a.dismiss();
  	         } 
  	     	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e16.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
   if (e16.getText().toString().length() >= 4) {
         
okButton.setEnabled(true);

       } else {
okButton.setEnabled(false);
}
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});

d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void h(String a1) {
             SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
String c727 = a.getString("gsJsGsKSIgPes", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) { 

spe.setChecked(true);
C10.a(getActivity(),"com.android.DROID_MJ.a14", 1);
C10.a(getActivity(),"com.android.DROID_MJ.d", 2);
} else {
spe.setChecked(false);

W1.a(getActivity(), getActivity().getResources().getString(R.string.j34), 0);
}
      
}
}

private void g(String a1) {
            SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
String c727 = a.getString("gsJsGsKSIgPes", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) {
C10.a(getActivity(),"com.android.DROID_MJ.a14", 2);
C10.a(getActivity(),"com.android.DROID_MJ.d", 1);
spe.setChecked(false);

} else {

spe.setChecked(true);
W1.a(getActivity(), getActivity().getResources().getString(R.string.j34), 0);
}
      
}
}

    private void i() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.c1, null);
        a5.setCancelable(true); 
        a5.setTitle(getActivity().getResources().getString(R.string.k27));
       a5.setView(a7);
       final EditText e15= (EditText) a7.findViewById(R.id.l13);
       final EditText a67= (EditText) a7.findViewById(R.id.l14);
       final EditText l15= (EditText) a7.findViewById(R.id.l15);

       int c = C5.b(getActivity(), R.color.c);
       int d1 = C5.b(getActivity(), R.color.b);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
       if (sp.getBoolean("autoUpdate", false) == false) {
           a67.setTextColor(c);
           e15.setTextColor(c);
           l15.setTextColor(c);
       } else {
           a67.setTextColor(d1);
           e15.setTextColor(d1);
           l15.setTextColor(d1);
       }
       e15.setHint(getActivity().getResources().getString(R.string.k28));
       a67.setHint(getActivity().getResources().getString(R.string.k29));
l15.setHint(getActivity().getResources().getString(R.string.k30));
       e15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       a67.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       l15.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       e15.setTransformationMethod(new T2());
       a67.setTransformationMethod(new T2()); 
       l15.setTransformationMethod(new T2());       a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
                j(e15.getText().toString(), l15.getText().toString());
               
                a.dismiss();
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {
                
                a.dismiss();
  	         } 
  	     });
        final AlertDialog d = a5.create();
d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        a67.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        e15.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  l15.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
                if (e15.getText().toString().length() >= 4) {
                    if (a67.getText().toString().length() >= 4 && !a67.getText().toString().equals(e15.getText().toString())) {
                        if (l15.getText().toString().length() >= 4 && !l15.getText().toString().equals(e15.getText().toString())) {
                        if (a67.getText().toString().equals(l15.getText().toString())) {
                                okButton.setEnabled(true); 
                            } else {
                                okButton.setEnabled(false);
                            }
                        } else {
                            okButton.setEnabled(false);
                        }
                    } else {
                        okButton.setEnabled(false);
                    }
                } else {
                    okButton.setEnabled(false);
                } 
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
          d.show();
          d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
          } 

     private void j(String a1, String a2) {
         SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
         String c727 = a.getString("gsJsGsKSIgPes", "");
         if (c727 != null ) {
             if (S1.a("SHA-512",a1).equals(c727)) {
                 SharedPreferences.Editor b5 = a.edit();
                 b5.putString("gsJsGsKSIgPes", S1.a("SHA-512",a2));
                 b5.apply();
W1.a(getActivity(), getActivity().getResources().getString(R.string.k31), 0);
             } else {
                 W1.a(getActivity(), getActivity().getResources().getString(R.string.k36), 0);
             } 
        }
    }

    private void k() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(getActivity());
        LayoutInflater a6 = LayoutInflater.from(getActivity());
        View a7 = a6.inflate(R.layout.t, null);
        a5.setCancelable(true); 
     a5.setTitle(getActivity().getResources().getString(R.string.k32));
       a5.setView(a7);

    final EditText e16 = (EditText)a7.findViewById(R.id.e16);
  

       int a15 = C5.b(getActivity(),R.color.c);
       int a16 = C5.b(getActivity(),R.color.b);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (sp.getBoolean("autoUpdate", false) == false) {

e16.setTextColor(a15);

        } else {

e16.setTextColor(a16);
        }
e16.setHint(getActivity().getResources().getString(R.string.g6));
       e16.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 

e16.setTransformationMethod(new T2()); a5.setPositiveButton(getResources().getString(R.string.i6), new C6() { 
            public void a(DialogInterface a, int b) { 
l(e16.getText().toString());
        a.dismiss();
     
  	         } 
  	     }); 
        a5.setNegativeButton(getResources().getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) {

                a.dismiss();
  	         } 
  	     	     });
   
final AlertDialog d = a5.create();

d.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
e16.addTextChangedListener(new T6() {
    private void handleText() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
   if (e16.getText().toString().length() >= 4) {
         
okButton.setEnabled(true);

       } else {
okButton.setEnabled(false);
}
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
handleText();
    }
});

d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

} 

private void l(String a1) {
             SharedPreferences a= getActivity().getSharedPreferences("gsJsGsKSIgPes", 0);
String c727 = a.getString("gsJsGsKSIgPes", "");
 if (c727 != null ) {
  if (S1.a("SHA-512",a1).equals(c727)) { 

 SharedPreferences.Editor b5 = a.edit();
                 b5.clear();
                 b5.apply();
W1.a(getActivity(), getActivity().getResources().getString(R.string.k33), 0);
spe.setChecked(false);
C10.a(getActivity(),"com.android.DROID_MJ.a14", 2);
C10.a(getActivity(),"com.android.DROID_MJ.d", 1);
} else {
 
W1.a(getActivity(), getActivity().getResources().getString(R.string.k36), 0);
}
      
}
}

}