package com.android.DROID_MJ.P;

import android.os.Bundle;
import com.android.DROID_MJ.A.A10;
import android.preference.Preference;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;
import android.os.Build;

public class P6 extends P14 {


  private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.e);
            A10.h18.setText(getActivity().getResources().getString(R.string.f));
                Preference d = (Preference) findPreference("batt");
                d.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                     a10.p();
                        return true;
                    }
                });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}