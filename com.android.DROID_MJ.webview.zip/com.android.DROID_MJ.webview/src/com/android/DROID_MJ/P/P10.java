package com.android.DROID_MJ.P;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.A.A12;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
public class P10 extends P14 {
    private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.k);
            A10.h18.setText(getActivity().getResources().getString(R.string.g));
      
            Preference l = (Preference) findPreference("zoom");
            l.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                    a10.t(0);
                    return true;
                }
            });
                Preference a1 = (Preference) findPreference("textS");
                a1.setOnPreferenceClickListener(new P16() {
                    public boolean a(Preference a) {
                        C1.a(getActivity(), A12.class);
                        return true;
                    }
               });
            
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}