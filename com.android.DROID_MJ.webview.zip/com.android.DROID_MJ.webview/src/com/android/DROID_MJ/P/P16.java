package com.android.DROID_MJ.P;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;

public class P16 implements OnPreferenceClickListener {
    public boolean onPreferenceClick(Preference a) { 
        return a(a);
    }

    public boolean a(Preference a) { 
        return true;
    }
}

 