package com.android.DROID_MJ.P;
import android.os.Bundle;
import android.preference.Preference;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
public class P1 extends P14 {
    private static A10 a10;
    public void a(Bundle b1) {
        try {
            addPreferencesFromResource(R.xml.j);
            a10 = A10.getInstance();
            a10.h18.setText(getActivity().getResources().getString(R.string.h10));
            Preference u1 = (Preference) findPreference("clearScreen");
            u1.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.j();
                    return true;
                }
            });
            Preference u2 = (Preference) findPreference("clearSource");
            u2.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.i();
                    return true;
                }
            });
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}