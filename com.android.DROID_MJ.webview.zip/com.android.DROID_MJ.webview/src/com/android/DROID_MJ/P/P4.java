package com.android.DROID_MJ.P;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;
import android.os.Bundle;
import android.preference.Preference;
import com.android.DROID_MJ.A.A10;

public class P4 extends P14 {

  private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.h);
            A10.h18.setText(getActivity().getResources().getString(R.string.i));
            Preference o = (Preference) findPreference("captions");
            o.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.k();
                    return true;
                }
            });
            Preference a2 = (Preference) findPreference("bri");
            a2.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.l();
                    return true;
                }
            });
            Preference a3 = (Preference) findPreference("vol");
            a3.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.m();
                    return true;
                }
            });
            Preference a4 = (Preference) findPreference("cusP");
            a4.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                     a10.b25();
                     return true;
                }
            });
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}