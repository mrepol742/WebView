package com.android.DROID_MJ.P;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import com.android.DROID_MJ.U.U1;



public class P14 extends PreferenceFragment {

    public void onCreate(Bundle b1) {
        super.onCreate(b1);
try {
        a(b1);
} catch (Exception e) {
U1.a(e);
}
    } 

    public void a(Bundle b1) {
    }
}
