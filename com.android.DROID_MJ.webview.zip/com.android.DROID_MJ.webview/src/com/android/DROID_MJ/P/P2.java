package com.android.DROID_MJ.P;
import android.os.Bundle;
import android.preference.Preference;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.W.W30;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

public class P2 extends P14 {

    private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.i);
            A10.h18.setText(getActivity().getResources().getString(R.string.l));
            Preference a7 = (Preference) findPreference("terms");
            a7.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a11(U4.a(W5.u()));
                    return true;
                }
            });
            Preference a8 = (Preference) findPreference("privacy");
            a8.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a11(U4.a(W5.v()));
                    return true;
                }
            });
            Preference a5 = (Preference) findPreference("webviewV");
            a5.setSummary(W5.d()+ " | " + W5.t());
          
            Preference a7762 = (Preference) findPreference("webviewN");
            a5.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
          Intent intent = new Intent();   intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", U4.a(W5.a10()), null);
        intent.setData(uri);
getActivity().startActivity(intent);
                return true;
                }
            });
            a7762.setSummary(W30.d(getActivity()).versionName+ " | " + Integer.toString(W30.d(getActivity()).versionCode));
  a7762.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
          Intent intent = new Intent();   intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", "com.google.android.webview", null);
        intent.setData(uri);
getActivity().startActivity(intent);
                return true;
                }
            });
            Preference a5777 = (Preference) findPreference("th5");
            a5777.setSummary(getActivity().getResources().getString(R.string.m9));
            Preference p = (Preference) findPreference("fbpage");
            p.setSummary(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDI="));
            p.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDI="));
                    return true;
                }
            });
            Preference p2222 = (Preference) findPreference("fbpage2");
            p2222.setSummary(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDIud2Vidmlldw=="));
            p2222.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDIud2Vidmlldw=="));
                    return true;
                }
            });
            Preference q = (Preference) findPreference("fb");
            
q.setSummary(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDIuZHJvaWRtag=="));
            q.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDIuZHJvaWRtag=="));
                    return true;
                }
            });
            Preference r = (Preference) findPreference("git");
            r.setSummary(U4.a("aHR0cHM6Ly9pbnN0YWdyYW0uY29tL21yZXBvbDc0Mg=="));
            r.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly9pbnN0YWdyYW0uY29tL21yZXBvbDc0Mg=="));
                    return true;
                }
            });

            Preference p67 = (Preference) findPreference("hub");
            p67.setSummary(U4.a("aHR0cHM6Ly9naXRodWIuY29tL21yZXBvbDc0Mg=="));
            p67.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    A10.getInstance().a9(U4.a("aHR0cHM6Ly9naXRodWIuY29tL21yZXBvbDc0Mg=="));
                    return true;
                }
            });
            Preference r5555 = (Preference) findPreference("twtt");
            r5555.setSummary(U4.a("aHR0cHM6Ly90d2l0dGVyLmNvbS9tcmVwb2w3NDI="));
            r5555.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly90d2l0dGVyLmNvbS9tcmVwb2w3NDI="));
                    return true;
                }
            });
            Preference r55555 = (Preference) findPreference("drdj");
            r55555.setSummary(U4.a("aHR0cHM6Ly9kcm9pZG1qLjAwMHdlYmhvc3RhcHAuY29t"));
            r55555.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly9kcm9pZG1qLjAwMHdlYmhvc3RhcHAuY29t"));
                    return true;
                }
            });
            Preference r555555 = (Preference) findPreference("wht");
            r555555.setSummary(U4.a("aHR0cHM6Ly93YS5tZS82MzkyODM1NTk1MDc="));
            r555555.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a9(U4.a("aHR0cHM6Ly93YS5tZS82MzkyODM1NTk1MDc="));
                    return true;
                }
            });

            Preference s = (Preference) findPreference("pro");
            s.setSummary(U4.a("bXJlcG9sNzQyQGdtYWlsLmNvbQ=="));
            s.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a10();
                    return true;
                }
            });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}


