package com.android.DROID_MJ.P;
import android.os.Bundle;
import android.preference.Preference;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
public class P12 extends P14 {
    private static A10 a10;
    public void a(Bundle b1) {
        try {
      a10 = A10.getInstance();
            addPreferencesFromResource(R.xml.x);
 

            A10.h18.setText(getActivity().getResources().getString(R.string.t6));
            Preference n = (Preference) findPreference("res");
            n.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) { 
                    a10.a6();
                    return true;
                }
            });
            Preference l = (Preference) findPreference("ets");
            l.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                   a10.a13();
                    return true;
                }
            });
            Preference a1 = (Preference) findPreference("its");
            a1.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                   a10.a15();
                    return true;
                }
           });
            Preference l1 = (Preference) findPreference("se");
            l1.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                 a10.a17();
                    return true;
                }
            });
            Preference a12 = (Preference) findPreference("si");
            a12.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                   a10.a19();
                    return true;
                }
           });
            Preference l11 = (Preference) findPreference("he");
            l11.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                 a10.b1();
                    return true;
                }
            });
            Preference a122 = (Preference) findPreference("hi");
            a122.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                   a10.b3();
                    return true;
                }
           });
            Preference l111 = (Preference) findPreference("be");
            l111.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                   a10.b5();
                    return true;
                }
            });
            Preference a1222 = (Preference) findPreference("bi");
            a1222.setOnPreferenceClickListener(new P16() {
                public boolean a(Preference a) {
                 a10.b7();
                    return true;
                }
           });
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}