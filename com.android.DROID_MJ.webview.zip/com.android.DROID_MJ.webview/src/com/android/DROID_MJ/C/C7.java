package com.android.DROID_MJ.C;
import android.view.MotionEvent;
import android.view.View;

public class C7 implements View.OnTouchListener {
    public boolean onTouch(View a, MotionEvent b) {
        return a(a, b);
    }

    public boolean a(View a, MotionEvent b) {
        return false;
    }
}