package com.android.DROID_MJ.C;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import com.android.DROID_MJ.U.U1;

public class C10 {
    public static void a(Context a, String b, int c) {
        try {
            PackageManager pm  =  a.getPackageManager();
            ComponentName cn = new ComponentName(a, b);
            pm.setComponentEnabledSetting(cn, c,PackageManager.DONT_KILL_APP);
        } catch (Exception ex) {
           U1.a(ex);
        }
    }
}