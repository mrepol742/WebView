package com.android.DROID_MJ.C;

import com.android.DROID_MJ.U.U1;
import android.content.ClipData;
import android.content.Context;
import android.content.ClipboardManager;

public class C2 {
    public static void a(Context a, String b) {
        try {
            ClipboardManager c =  (ClipboardManager) a.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = ClipData.newPlainText("text", b);
            c.setPrimaryClip(d);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static String b(Context a) {
        try {
            ClipboardManager b = (ClipboardManager) a.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData c = b.getPrimaryClip();
            ClipData.Item d = c.getItemAt(0);
            return d.getText().toString();
        } catch (Exception ex) {
            U1.a(ex);
        }
        return null;
    }

}