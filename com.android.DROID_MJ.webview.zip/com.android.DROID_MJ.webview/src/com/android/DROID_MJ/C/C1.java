package com.android.DROID_MJ.C;

import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.U.U4;

public class C1 {
    public static void a(Context a, Class<?> b) {
         try {
             Intent c = new Intent(a.getApplicationContext(), b);
             c.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
             if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
                 a.getApplicationContext().startActivity(c);
             }
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public static void b(Context a, Class<?> b) {
         try {
             Intent c = new Intent(a.getApplicationContext(), b);
             if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
                 a.getApplicationContext().startService(c);
             }
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public static void c(Context a, String b) {
        try { 
            Intent c = a.getApplicationContext().getPackageManager().getLaunchIntentForPackage(b);
c.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
                a.getApplicationContext().startActivity(c);
            }
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public static void d(Context a, String b, String c, Activity e) {
        try {
            Intent d = new Intent();
				      d.putExtra(b, c);

				      e.setResult(Activity.RESULT_OK, d);

        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void e(Context a, String b, String c, Class<?> e) {
        try {
            Intent d = new Intent(a.getApplicationContext(), e);
				      d.putExtra(b, c);
            d.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           if (d.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
				          a.getApplicationContext().startActivity(d);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void f(Context a, Activity b, Class<?> c, int d) {
        try {
            Intent e = new Intent(a.getApplicationContext(), c);
            if (e.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
				          b.startActivityForResult(e, d);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void g(Context a, String b, String c) {
        try {
            Intent d = new Intent(Intent.ACTION_MAIN);
            d.setClassName(b, c);
            d.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          if (d.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
                a.getApplicationContext().startActivity(d);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void h(Context a, Activity b, Class<?> c, int d, String h, String i) {
        try {
            Intent e = new Intent(a.getApplicationContext(), c);
            e.putExtra(h, i);
            if (e.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
				          b.startActivityForResult(e, d);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void i(Context a, Class<?> b) {
         try {
             Intent c = new Intent(a.getApplicationContext(), b);
             c.setPackage(U4.a(W5.b()));
            if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
                 a.getApplicationContext().stopService(c);
             }
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public static void j(Context a, String b) {
         try {
             Intent c = new Intent(b);
             c.setPackage(U4.a(W5.b()));
if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
             a.getApplicationContext().startService(c);
}
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public static void k(Context a, String b) {
         try {
             Intent c = new Intent(b);
             
c.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
if (c.resolveActivity(a.getApplicationContext().getPackageManager()) != null) {
             a.getApplicationContext().startActivity(c);
}
         } catch (Exception ex) {
             U1.a(ex);
         }
    }
}



/*

    private void b(String a) {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", a);
        String c = getResources().getString(R.string.l8);
        String d = c.replaceAll("WebView", "\""+a+"\"");
        startActivity(Intent.createChooser(b, d));
    }

*/




























