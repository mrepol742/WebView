package com.android.DROID_MJ.C;
 
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.io.File;
import com.android.DROID_MJ.U.U1;

public class C4 {
    public static void a(Context a, String b) {
        try {
            Intent intent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            intent.setData(Uri .fromFile(new File (b)));
         intent.putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, false);
           intent.putExtra(Intent.EXTRA_ALLOW_REPLACE, true);
        intent.putExtra(Intent.EXTRA_INSTALLER_PACKAGE_NAME,
            a.getApplicationContext().getApplicationInfo().packageName);
       a.getApplicationContext().startActivity(intent);
       } catch (Exception e) {
           U1.a(e);
       }
    }
}


