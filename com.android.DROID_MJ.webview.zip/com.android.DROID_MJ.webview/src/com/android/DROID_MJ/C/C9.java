package com.android.DROID_MJ.C;
import android.view.View;   import com.android.DROID_MJ.C.C9;

public class C9 implements View.OnClickListener {
    public void onClick(View v) {
        a(v);
    }

    public void a(View v) {
 
    }
}
