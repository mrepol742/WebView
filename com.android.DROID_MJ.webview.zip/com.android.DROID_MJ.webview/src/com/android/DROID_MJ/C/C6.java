package com.android.DROID_MJ.C;

import android.content.DialogInterface;  

public class C6 implements DialogInterface.OnClickListener{
    public void onClick(DialogInterface a, int b) {
        a(a, b);
    }

    public void a(DialogInterface a, int b) {
 
    }
}