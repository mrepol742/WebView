package com.android.DROID_MJ.C;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
public class C11 {
    public static void a(Context a, String b) {
        Intent f = new Intent();          
        f.setAction(b);     
f.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        a.getApplicationContext().sendBroadcast(f);
    }

    public static void b(Context a, String b, String c, String d) {
        Intent f = new Intent();          
        f.setAction(b);     
f.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        f.putExtra(c, d);
        
a.getApplicationContext().sendBroadcast(f);
    }
}
 