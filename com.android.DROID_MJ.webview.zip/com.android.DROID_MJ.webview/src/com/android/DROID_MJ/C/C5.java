package com.android.DROID_MJ.C;
import android.content.Context;
import android.os.Build;
import android.graphics.drawable.Drawable;
import android.graphics.Bitmap;
import android.graphics.Canvas;

public class C5 {
   public static Drawable a(Context a, int i) {
        if (Build.VERSION.SDK_INT >= 21) {
            return a.getDrawable(i);
        }
        return a.getResources().getDrawable(i);
    }

    public static int b(Context a, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            return a.getColor(i);
        }
        return a.getResources().getColor(i);
    }

    public static Bitmap c(Context context, int res) {
        Drawable drawable = a(context, res);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
        drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}