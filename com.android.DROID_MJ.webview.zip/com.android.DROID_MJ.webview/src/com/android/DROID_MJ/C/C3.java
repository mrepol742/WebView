package com.android.DROID_MJ.C;

import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;

public class C3 {
    public static boolean a(String a, PackageManager b) {
        boolean c = true;
        try {
             b.getPackageInfo(a, 0);
        } catch (NameNotFoundException e) {
             c = false;
        }
        return c;
    }

    public static String b(Context a) {
        return a.getApplicationContext().getPackageName();
    }

    public static String c(Context a) {
        return a.getApplicationContext().getApplicationInfo().loadLabel(a.getApplicationContext().getPackageManager()).toString();
    }

    public static byte[] d(Context a, String b, int it) {
        try {
            PackageInfo packageInfo = a.getApplicationContext().getPackageManager().getPackageInfo(b, it);
            return packageInfo.signatures[0].toByteArray();
        } catch (NameNotFoundException e) {
        }
        return null;
    }

}