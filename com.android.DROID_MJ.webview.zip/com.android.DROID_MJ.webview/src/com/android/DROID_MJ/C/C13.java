package com.android.DROID_MJ.C;

import android.content.DialogInterface;  

public class C13 implements DialogInterface.OnDismissListener{
    public void onDismiss(DialogInterface a) {
        a(a);
    }

    public void a(DialogInterface a) {
 
    }
}