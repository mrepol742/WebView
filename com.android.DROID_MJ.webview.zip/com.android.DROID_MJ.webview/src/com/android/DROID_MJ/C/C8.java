package com.android.DROID_MJ.C;
import android.view.View;    
public class C8 implements View.OnLongClickListener {
    public boolean onLongClick(View v) {
        return a(v);
    }

    public boolean a(View v) {
        return true;
    }
}
