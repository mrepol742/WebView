package com.android.DROID_MJ.O;

 

import android.os.CountDownTimer;
import com.android.DROID_MJ.A.A4;

    public class O3 extends CountDownTimer  {

    public O3(long a, long b) {
        super(a, b);
    }
 
    public void onTick(long a) {
    }

    public void onFinish() {
      A4.getInstance().finish();
    }
}