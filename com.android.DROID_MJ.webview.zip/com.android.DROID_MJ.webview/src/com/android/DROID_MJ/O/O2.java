package com.android.DROID_MJ.O;
import com.android.DROID_MJ.A.A21;
import android.os.CountDownTimer;

public class O2 extends CountDownTimer {

    public O2(long a, long b) {
        super(a, b);
    }
 
    public void onTick(long a) {
    }

    public void onFinish() {
        A21.getInstance().c42();
    }
}