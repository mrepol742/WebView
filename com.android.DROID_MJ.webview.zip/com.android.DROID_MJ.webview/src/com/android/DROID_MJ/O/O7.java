package com.android.DROID_MJ.O;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import com.android.DROID_MJ.U.U1;

public class O7 {
    public static boolean a(Context a) {
        try {
            PowerManager b = (PowerManager) a.getApplicationContext().getSystemService(Context.POWER_SERVICE);
                if (b.isPowerSaveMode()) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception ex) {
                U1.a(ex);
            }
        
        return false;
    }
}