package com.android.DROID_MJ.O;
 

import android.os.CountDownTimer;
import com.android.DROID_MJ.A.A10;
import android.app.AlertDialog;


public class O5 extends CountDownTimer {
    private static AlertDialog ad;
    public O5(long a, long b, AlertDialog gj) {
        super(a, b);
       ad = gj;
    }
 
    public void onTick(long a) {
    }

    public void onFinish() {
        ad.dismiss();
        A10.getInstance().a8();
    }
}

