package com.android.DROID_MJ.O;

 

import android.os.CountDownTimer;
import com.android.DROID_MJ.A.A11;

public class O6 extends CountDownTimer {

    public O6(long a, long b) {
        super(a, b);
    }
 
    public void onTick(long a) {
    }

    public void onFinish() {
        A11.getInstance().d();
    }
}
