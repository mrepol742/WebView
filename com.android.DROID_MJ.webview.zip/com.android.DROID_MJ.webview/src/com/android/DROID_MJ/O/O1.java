package com.android.DROID_MJ.O;

import com.android.DROID_MJ.U.U1;
import android.content.Context;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.os.Build;

public class O1 {

    @SuppressWarnings("deprecation")
    public static void a(Context a, int b ) {
        try {
            Vibrator v = (Vibrator) a.getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= 27) {
               v.vibrate(VibrationEffect.createOneShot(b, VibrationEffect.DEFAULT_AMPLITUDE));
            } else { 
                v.vibrate(b);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}