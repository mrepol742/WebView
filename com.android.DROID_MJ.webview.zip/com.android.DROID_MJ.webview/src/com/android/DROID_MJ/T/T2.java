package com.android.DROID_MJ.T;

 

import android.text.method.PasswordTransformationMethod;
import android.view.View;   

public class T2 extends PasswordTransformationMethod {
    @Override
    public CharSequence getTransformation(CharSequence source, View view) {
return source;

    }
}