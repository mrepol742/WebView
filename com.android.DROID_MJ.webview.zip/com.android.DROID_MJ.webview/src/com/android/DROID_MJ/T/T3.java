package com.android.DROID_MJ.T;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.Editable;
import android.text.Selection;
import android.text.style.UnderlineSpan;
import android.widget.TextView;
 
import com.android.DROID_MJ.T.T4;
import com.android.DROID_MJ.W.W28;
import com.java.DROID_MJ.U.U4;

public class T3 {

public static boolean a = false;
public static U4 b;
private T4 c;
private TextView d;

    public T3(TextView textView) {
		    d = textView;
       b = new U4();
       c = new T4();
       d.addTextChangedListener(c);
	  }

    public void disconnect() {
	      d.removeTextChangedListener(c);
    }

    public void setMaxHistorySize(int i) {
		    b.setMaxHistorySize(i);
	  }

    public void clearHistory() {
		    b.clear();
	  }

    public boolean getCanUndo() {
        return (b.mmPosition > 0);
    }

    public void undo() {
        W28 edit = b.getPrevious();
        if (edit == null) {
            return;
        }
        Editable text = d.getEditableText();
        int start = edit.a;
        int end = start + (edit.c != null ? edit.c.length() : 0);
	     	a = true;
		     text.replace(start, end, edit.b);
		     a = false;
        for (Object o : text.getSpans(0, text.length(), UnderlineSpan.class)) {
			       text.removeSpan(o);
		     }
        Selection.setSelection(text, edit.b == null ? start : (start + edit.b.length()));
    }

    public boolean getCanRedo() {
        return (b.mmPosition < b.mmHistory.size());
    }

    public void redo() {
        W28 edit = b.getNext();
        if (edit == null) {
            return;
        }
        Editable text = d.getEditableText();
        int start = edit.a;
        int end = start + (edit.b != null ? edit.b.length() : 0);
	     	a = true;
	     	text.replace(start, end, edit.c);
	      	a = false;
        for (Object o : text.getSpans(0, text.length(), UnderlineSpan.class)) {
			       text.removeSpan(o);
	     	}
        Selection.setSelection(text, edit.c == null ? start : (start + edit.c.length()));
    }

    public void storePersistentState(Editor editor, String prefix) {
		    editor.putString(prefix + ".hash", String.valueOf(d.getText().toString().hashCode()));
       editor.putInt(prefix + ".maxSize", b.mmMaxHistorySize);
       editor.putInt(prefix + ".position", b.mmPosition);
       editor.putInt(prefix + ".size", b.mmHistory.size());
       int i = 0;
       for (W28 ei : b.mmHistory) {
            String pre = prefix + "." + i;
            editor.putInt(pre + ".start", ei.a);
            editor.putString(pre + ".before", ei.b.toString());
			       editor.putString(pre + ".after", ei.c.toString());
			       i++;
        }
    }

    public boolean restorePersistentState(SharedPreferences sp, String prefix) throws IllegalStateException {
       boolean ok = doRestorePersistentState(sp, prefix);
       if (!ok) {
			      b.clear();
		    }
       return ok;
    }

    private boolean doRestorePersistentState(SharedPreferences sp, String prefix) {
        String hash = sp.getString(prefix + ".hash", null);
        if (hash == null) {
            return true;
        }
        if (Integer.valueOf(hash) != d.getText().toString().hashCode()) {
            return false;
        }
        b.clear();
        b.mmMaxHistorySize = sp.getInt(prefix + ".maxSize", -1);
        int count = sp.getInt(prefix + ".size", -1);
        if (count == -1) {
            return false;
        }
        for (int i = 0; i < count; i++) {
            String pre = prefix + "." + i;
            int start = sp.getInt(pre + ".start", -1);
            String before = sp.getString(pre + ".before", null);
            String after = sp.getString(pre + ".after", null);
            if (start == -1 || before == null || after == null) {
                return false;
		       	}
			       b.add(new W28(start, before, after));
        }
	      b.mmPosition = sp.getInt(prefix + ".position", -1);
       if (b.mmPosition == -1) {
           return false;
		    }
       return true;
    }
}