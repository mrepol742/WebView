package com.android.DROID_MJ.T;
import android.text.style.ClickableSpan;
import android.view.View;

public class T5 extends ClickableSpan {
    public void onClick(View v) {
        a(v);
    }

    public void a(View v) {
 
    }
}