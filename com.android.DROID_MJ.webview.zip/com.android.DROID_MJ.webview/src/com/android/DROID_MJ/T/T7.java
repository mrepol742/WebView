package com.android.DROID_MJ.T;
import android.os.Build;
import android.text.Html;
import android.widget.TextView;

public class T7 {
    public static void a(TextView tv, String sg) {
        if (Build.VERSION.SDK_INT >= 24) {
            tv.setText(Html.fromHtml(sg,Html.FROM_HTML_MODE_LEGACY));
        } else {
           tv.setText(Html.fromHtml(sg));
        }
    }
}