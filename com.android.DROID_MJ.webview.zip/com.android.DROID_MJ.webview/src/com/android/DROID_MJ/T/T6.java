package com.android.DROID_MJ.T;

import android.text.Editable;
import android.text.TextWatcher;

public class T6 implements TextWatcher {
    public T6() {
        T6 t6 = this;
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        a(charSequence, i, i2, i3);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        b(charSequence, i, i2, i3);
    }

    public void afterTextChanged(Editable editable) {
        c(editable);
    }

    public void a(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void b(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void c(Editable editable) {
    }
}
