package com.android.DROID_MJ.T;
import android.text.Editable;
 import com.android.DROID_MJ.T.T6;
import com.android.DROID_MJ.T.T3;
import com.android.DROID_MJ.W.W28;

public class T4 extends T6 {

private static CharSequence a;
private static CharSequence b;

    public void a(CharSequence s, int start, int count, int after) {
        if (T3.a) {
            return;
        }
		    	a = s.subSequence(start, start + count);
		}

   public void b(CharSequence s, int start, int before, int count) {
       if (T3.a) {
           return;
       }
       b = s.subSequence(start, start + count);
       T3.b.add(new W28(start, a, b));
    }

    public void c(Editable s) {
    }
}

