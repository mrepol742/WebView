package com.android.DROID_MJ.A;

// Welcome Beta WINDOW


import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;

import android.app.Activity;
import android.preference.PreferenceManager;

import com.android.DROID_MJ.webview.R;

import com.android.DROID_MJ.O.O6;
import android.app.AlertDialog;
import com.android.DROID_MJ.W.W1;

import com.android.DROID_MJ.C.C5;

import android.widget.Toolbar;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
 
import android.widget.TextView;

import android.view.View;
import com.android.DROID_MJ.C.C9;
import android.content.Context;
import android.view.KeyEvent;
import android.text.Html;
import android.widget.Button;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.os.Build;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.T.T7;



public class A11 extends Activity  {
public static A11 A11;
    
        private static SharedPreferences sp;
    
    
public static A11 getInstance() {
return A11;
}
    protected void onCreate(Bundle a) {
      sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.b2);

        
        
        
        
        Toolbar h17 = (Toolbar)
 findViewById(R.id.c3);
        TextView h18 = (TextView) findViewById(R.id.c4);
        TextView h19 = (TextView) findViewById(R.id.c5);
        TextView h20 = (TextView) findViewById(R.id.a8);

        TextView i4 = (TextView) findViewById(R.id.i4);

       Button i5= (Button) findViewById(R.id.i5);
A11 = this;
        Typeface c = G1.a(this, 200);
        h18.setTypeface(c);
       i4.setTypeface(c);
h19.setTypeface(c);
h20.setTypeface(G1.a(this, 100));
h18.setText(getString(R.string.p20));
h19.setText(getString(R.string.n16));
i4.setText(getString(R.string.n17));

i4.setBackgroundResource(R.drawable.c11);
        setActionBar(h17);
        h17.setElevation(10);
        int d = C5.b(this,R.color.c);
        int e = C5.b(this,R.color.b);
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);


        if (sp.getBoolean("autoUpdate", false) == false) {
            h18.setTextColor(d);
 h19.setTextColor(d);
 h20.setTextColor(d);
        } else {

            h18.setTextColor(e);
 h19.setTextColor(e);
 h20.setTextColor(e);
        }
i5.setTextColor(e);
           h17.setBackgroundResource(R.drawable.p);
i5.setBackgroundResource(R.drawable.a5);
            h17.setNavigationIcon(R.drawable.a2);
        h17.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        }); 

       T7.a(h20, getString(R.string.n20));

SharedPreferences prefs = getSharedPreferences("webDa",Context.MODE_PRIVATE);
boolean webDa = prefs.getBoolean("webDa", false);
if (webDa == true) {
i4.setVisibility(View.VISIBLE);
i5.setText(getString(R.string.n19));
} else {
i4.setVisibility(View.GONE);
i5.setText(getString(R.string.n18));
}
i5.setOnClickListener(new C9() {

public void a(View a) {
SharedPreferences prefs = getSharedPreferences("webDa",Context.MODE_PRIVATE);
boolean webDa = prefs.getBoolean("webDa", false);
if (webDa == true) {
b();

} else {
a1();
}
c();
}
});
}
protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}
    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            finish();

            return true;
        }

        return super.onKeyUp(a, b);
    }
    private void a1() {
        SharedPreferences b = getSharedPreferences("webDa", 0);
        SharedPreferences.Editor c = b.edit();
        c.putBoolean("webDa", true);
        c.apply();
        W1.a(getApplicationContext(),getString(R.string.o2), 0);
    }

    private void b() {
        SharedPreferences b = getSharedPreferences("webDa", 0);
        SharedPreferences.Editor c = b.edit();
        c.putBoolean("webDa", false);
        c.apply();
        W1.a(getApplicationContext(), getString(R.string.o3), 0);
    }

    public void c() {

            AlertDialog.Builder c =  new AlertDialog.Builder(this);


            LayoutInflater d = getLayoutInflater();
            View e = d.inflate(R.layout.a12, null);
            c.setCancelable(false); 
            c.setView(e);
            TextView f = (TextView) e.findViewById(R.id.g1);
            f.setText(getString(R.string.o1));
          if (sp.getBoolean("autoUpdate", false) == false) {

f.setTextColor(C5.b(this,R.color.c));

           } else{

f.setTextColor(C5.b(this,R.color.b));
}
            
           final AlertDialog g = c.create();
           g.show();
      CountDownTimer      timer = new O6(1000, 1000);
            timer.start();
    } 
public void d() {
finishAffinity();

}
}