package com.android.DROID_MJ.A;

// SCREEN SHOT 1 SECONDS POPUP 

import android.os.Bundle;
import android.app.Activity;

import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.graphics.BitmapFactory;
import com.android.DROID_MJ.O.O3;
import com.android.DROID_MJ.V.V1;
import com.android.DROID_MJ.M.M1;
import android.os.CountDownTimer;
import android.content.pm.ActivityInfo;


public class A4 extends Activity  {
    public static ImageView c19;
    public static A4 A4;
    
        
    
    
    public static A4 getInstance() {
        return A4;
    }

    protected void onCreate(Bundle a) {
        SharedPreferences b6 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (b6.getBoolean("autoUpdate", false) == false) {
          
                setTheme(R.style.b8);
        } else {

                setTheme(R.style.b14);
 
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.a8);
        A4 = this;
        
        
        
        
        c19 = (ImageView) findViewById(R.id.c19);
        LinearLayout h20 = (LinearLayout) findViewById(R.id.h20);
        h20.setBackgroundColor(android.R.color.transparent);
      
           if (b6.getString("hori", "").length() == 0){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (b6.getString("hori", "").equals("1c")){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (b6.getString("hori", "").equals("7c")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
           }
           if (b6.getString("hori", "").equals("30c")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
           }
      CountDownTimer      timer = new O3(1000, 1000);
            timer.start();

V1.a(this, R.anim.e, c19);

    }

    protected void onResume() {
        super.onResume();
        onNewIntent(getIntent());


if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();
}

    }

   protected void onNewIntent(Intent a) {
        try {
          String b = a.getStringExtra("hajaha");
            if (b != null) {
               c19.setImageBitmap(BitmapFactory.decodeFile(b));
           
a.removeExtra("hajaha");
            }
 
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}