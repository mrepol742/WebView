package com.android.DROID_MJ.A;

// WEBVIEW LOCK SETTING 

import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View; 
import com.android.DROID_MJ.C.C9;
import android.widget.Toolbar;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import android.app.Activity;

import android.widget.TextView;
import android.content.Context;
import android.view.KeyEvent;
import com.android.DROID_MJ.P.P13;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;



public class A5 extends Activity  {
    
        
    
    

      protected void onCreate(Bundle a) {
          SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
          

O8.b();
super.onCreate(a);

setContentView(R.layout.a9);
        
        
        
        
        Toolbar h17 = (Toolbar) findViewById(R.id.c3);
       TextView h18 = (TextView) findViewById(R.id.c4);
       TextView k8 = (TextView) findViewById(R.id.c5);

       
        h18.setTypeface(G1.a(this, 200));
k8.setTypeface(G1.a(this, 200));
        setActionBar(h17);
        h17.setElevation(10);
h18.setText(getString(R.string.l10));
      k8.setText(getString(R.string.l13));
SharedPreferences prefs = getSharedPreferences("webDa",Context.MODE_PRIVATE);
       boolean d78 = prefs.getBoolean("webDa",false);

if (d78 == true) {
k8.setVisibility(View.VISIBLE);
} else {
k8.setVisibility(View.GONE);
}
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);

        if (sp.getBoolean("autoUpdate", false) == false) {
            h18.setTextColor(C5.b(this,R.color.c));
k8.setTextColor(C5.b(this,R.color.c));
        } else {

            h18.setTextColor(C5.b(this,R.color.b));
k8.setTextColor(C5.b(this,R.color.b));
        }
h17.setBackgroundResource(R.drawable.p);
            h17.setNavigationIcon(R.drawable.a2);
        h17.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        });


getFragmentManager().beginTransaction().replace(R.id.i6, new P13 ()).commit();


}
protected void onResume() {
super.onResume();
if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();
}
}
    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            finish();


            return true;
        }

        return super.onKeyUp(a, b);
    }

    public boolean onKeyLongPress(int a, KeyEvent b) {
        if (a == 4 && !b.isCanceled()) {
            finish();

        }
        return false;
    }
}
