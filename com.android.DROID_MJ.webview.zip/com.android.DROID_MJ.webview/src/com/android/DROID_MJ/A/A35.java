package com.android.DROID_MJ.A;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;

import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.webview.R;

import android.app.AlertDialog;
import android.content.DialogInterface;
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.I.I2;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.view.View;
import android.widget.Toast;
import android.widget.TextView;
import android.view.ViewGroup;
import com.android.DROID_MJ.C.C13;
import java.io.File;
public class A35 extends Activity {
        protected void onCreate(Bundle a) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
          if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a);

setContentView(R.layout.b14);

}



}