package com.android.DROID_MJ.A;

// SCREEN SHOT WINDOW

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;

import com.android.DROID_MJ.I.I3;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.app.AlertDialog;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.A.A10;
import android.widget.Toolbar;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View; 
import com.android.DROID_MJ.C.C9;
//import android.print.PrintHelper;
import android.graphics.BitmapFactory;
import android.view.WindowManager;
import android.content.res.Configuration;
import android.view.Menu;
import android.view.MenuItem;
import android.net.Uri;
import android.content.DialogInterface; 
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.I.I1;
import android.view.KeyEvent;
import android.print.PrintManager;
import android.content.Context;
import com.android.DROID_MJ.W.W4;


public class A3 extends Activity  {
    private static TextView h18;
    private static ImageView h19;
    private static int on;
    private static String st = "/WebView/Screenshot/";
    
        
    
    
    protected void onCreate(Bundle a) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.a7);
        
        
        
        
        Toolbar h17 = (Toolbar) findViewById(R.id.h17);
        h18 = (TextView) findViewById(R.id.h18);
        h19 = (ImageView) findViewById(R.id.h19);
        Typeface c = G1.a(this, 200);
        h18.setTypeface(c);
        setActionBar(h17);
        h17.setElevation(10);
        int d = C5.b(this,R.color.c);
        int e = C5.b(this,R.color.b);
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);


        if (sp.getBoolean("autoUpdate", false) == false) {
            h18.setTextColor(d);
        } else {
            h18.setTextColor(e);
        }
h17.setBackgroundResource(R.drawable.p);
            h17.setNavigationIcon(R.drawable.a2);
        h17.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        });
      
getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); 
    }

    public boolean onCreateOptionsMenu(Menu a) {

            getMenuInflater().inflate(R.menu.h, a);

        MenuItem b1 = a.findItem(R.id.i1);
        MenuItem c1 = a.findItem(R.id.i2);
        MenuItem e1 = a.findItem(R.id.i3);
           b1.setIcon(C5.a(this, R.drawable.b15)); 
if (on == Configuration.ORIENTATION_LANDSCAPE) { 
             c1.setIcon(C5.a(this, R.drawable.b10)); 
           e1.setIcon(C5.a(this, R.drawable.c4)); 
}
        return super.onCreateOptionsMenu(a);
    }

    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.i1:
                b(h18.getText().toString());
                return true;
            case R.id.i2:
                d(h18.getText().toString());
                return true;
            case R.id.i3:
                e(h18.getText().toString());
                return true;
            case R.id.m:
                C1.e(this, "search", "a", A10.class);

                return true;
            case R.id.a12:
                f(h18.getText().toString());

                return true;
            default:
                return super.onOptionsItemSelected(a);
         }
    }
    protected void onResume() {
        super.onResume();
        onNewIntent(getIntent());


if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();
}

    }

 
    private void b(String a) {
        Intent f = new Intent(Intent.ACTION_SEND);
        f.setType("image/*");
        f.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://"+ 
I3.a()+st+a));
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+a+"\"");
        startActivity(Intent.createChooser(f, d));


    }

    private void d(final String b) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.k1));
        String c = getString(R.string.l11);
        String d = c.replaceAll("%a", "\""+b+"\"");
        a.setMessage(d);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b1) { 
        I1.a(st+b, 2);
               finish();


            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    private void e(final String b) {
try {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
/*
        File b67 = new File(st+b);
        File[] cj = b67.listFiles();
        long lg = cj.length;
        String sg2 = Formatter.formatFileSize(getApplicationContext(), lg);
       */ a.setTitle(getString(R.string.k1));
        a.setMessage("This feature is not available for now... ");
        a.setPositiveButton("Close", new C6() {
            public void a(DialogInterface a, int b1) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
} catch (Exception ex) {
U1.a(ex);
}
    } 

    private void f(String a) {

   /* PrintHelper photoPrinter = new PrintHelper(this);
    photoPrinter.setScaleMode(PrintHelper.SCALE_MODE_FIT);

    photoPrinter.printBitmap(a, BitmapFactory.decodeFile(I3.a() + "/WebView/Screenshot/"+a));*/

W4 w4 = new W4(this);
w4.loadDataWithBaseURL(null,"<!DOCTYPE html><html><head><title></title></head><body><img src=\"file://"+I3.a() + "/WebView/Screenshot/"+a+"\"/></body></html>", "text/html", "UTF-8", null);

PrintManager aa = (PrintManager) getSystemService(
                Context.PRINT_SERVICE);
 
        aa.print(a, w4.createPrintDocumentAdapter(a), null);
}

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        on = newConfig.orientation;
        invalidateOptionsMenu();
    }

    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            finish();


            return true;
        }

        return super.onKeyUp(a, b);
   }
   protected void onNewIntent(Intent a) {
        try {
           String b = a.getStringExtra("a56hj");
            if (b != null) {
                String c = b.replaceAll(I3.a()+st, "");
               h19.setImageBitmap(BitmapFactory.decodeFile(b));
                h18.setText(c);
a.removeExtra("a56hj");
            }
 
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}