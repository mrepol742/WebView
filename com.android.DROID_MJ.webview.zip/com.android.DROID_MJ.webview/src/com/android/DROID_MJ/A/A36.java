package com.android.DROID_MJ.A;

import android.widget.TextView;
import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.content.Intent;
import android.widget.LinearLayout;
import android.view.View;
import com.android.DROID_MJ.G.G1;
import com.android.DROID_MJ.C.C10;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;

import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.C.C5;
public class A36 extends Activity {
    private SharedPreferences sp;
    protected void onCreate(Bundle a) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        
O8.b();
        super.onCreate(a);
         
        setContentView(R.layout.v);
        final TextView b = (TextView) findViewById(R.id.l9);
        LinearLayout e = (LinearLayout) findViewById(R.id.k4);
        b.setText(getString(R.string.h35));
        b.setTypeface(G1.a(this, 200));
        int f = C5.b(this,R.color.c);
 
        int g = C5.b(this,R.color.b);
        if (sp.getBoolean("autoUpdate", false) == false) {
            b.setTextColor(f);
            e.setBackgroundResource(R.drawable.e16);
        } else {
            b.setTextColor(g);
            e.setBackgroundResource(R.drawable.e17);
        }
        e.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                 String f = b.getText().toString();
                 String g = getString(R.string.h35);
                 String h = getString(R.string.h36);
                 if (f.equals(g)) {
                     b.setText(h);
                 } else {
                     b.setText(g);
                 }
            }
        });
        a();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    moveTaskToBack(true);
             return false;
            }

        }
        return false;
    }


private void a() {
  

b("com.android.DROID_MJ.b", 2);
b("com.android.DROID_MJ.c", 2);
b("com.android.DROID_MJ.d", 2);
b("com.android.DROID_MJ.e", 2);
b("com.android.DROID_MJ.f", 2);
b("com.android.DROID_MJ.g", 2);
b("com.android.DROID_MJ.q", 2);
b("com.android.DROID_MJ.s", 2);
b("com.android.DROID_MJ.t", 2);
 b("com.android.DROID_MJ.w", 2);
b("com.android.DROID_MJ.y", 2);
b("com.android.DROID_MJ.z", 2);
b("com.android.DROID_MJ.a1", 2);
 b("com.android.DROID_MJ.a2", 2);
 b("com.android.DROID_MJ.a3", 2);
 b("com.android.DROID_MJ.a4", 2);
 b("com.android.DROID_MJ.a5", 2);
 b("com.android.DROID_MJ.a6", 2);
 b("com.android.DROID_MJ.a7", 2);
 b("com.android.DROID_MJ.a8", 2);
 b("com.android.DROID_MJ.a9", 2);
b("com.android.DROID_MJ.a12", 1);
b("com.android.DROID_MJ.a13", 1);
b("com.android.DROID_MJ.x", 1);
 b("com.android.DROID_MJ.A.A33", 2);
  b("com.android.DROID_MJ.A.A21", 2);
  b("com.android.DROID_MJ.A.A16", 2);
  b("com.android.DROID_MJ.A.A14", 2);
b("com.android.DROID_MJ.m", 2);
}

public void b(String a, int b) {
 C10.a(this, a, b);


}
}