package com.android.DROID_MJ.A;

import android.app.Activity;

import android.os.Bundle;
import com.android.DROID_MJ.I.I3;
import java.io.File;
import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.C.C5;
import android.widget.TextView;
import android.widget.Toolbar;
import android.graphics.Typeface;
import com.android.DROID_MJ.G.G1;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.C.C9;
import android.view.View;
import android.widget.ScrollView;
import java.io.IOException;
import java.io.InputStream;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.widget.ProgressBar;
import com.android.DROID_MJ.W.W4;
import android.graphics.Bitmap;
import android.webkit.WebView;
import com.android.DROID_MJ.W.W34;
import com.android.DROID_MJ.W.W35;
public class A24 extends Activity {
private static   SharedPreferences sp;
          private static W4 w4;
    private static ProgressBar pb;
     private static Executor er = Executors.newCachedThreadPool();
                String log = "";
public static A24 A24;

public static A24 getInstance() {
return A24;
}
    protected void onCreate(Bundle a) {
         sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
        super.onCreate(a);
try {
        A24 = this;
setContentView(R.layout.n);
     Toolbar a1 = (Toolbar) findViewById(R.id.b7);
       TextView   a2 = (TextView) findViewById(R.id.b8);
        w4 = (W4) findViewById(R.id.j);
        pb = (ProgressBar) findViewById(R.id.h);
 
setActionBar(a1);
getActionBar().setDisplayShowTitleEnabled(false);

        getActionBar().setDisplayHomeAsUpEnabled(true);
        int f = C5.b(this,R.color.c);
 
        int g = C5.b(this,R.color.b);
 
        a2.setTypeface(G1.a(this, 200));
        a2.setText(getString(R.string.f30));
        if (sp.getBoolean("autoUpdate", false) == false) {
            a2.setTextColor(f);
        } else {

            a2.setTextColor(g);
        }
w4.setBackgroundResource(R.color.b);
a1.setBackgroundResource(R.drawable.p);
            a1.setNavigationIcon(R.drawable.a2);
        a1.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                
                finish();

            }
        });
pb.setMax(100);
a1.setElevation(10);
WebSettings ws = w4.getSettings();
        ws.setJavaScriptEnabled(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setDomStorageEnabled(false);
        ws.setDatabaseEnabled(false);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
ws.setBuiltInZoomControls(true);
    w4.setWebViewClient(new W34());
 w4.setWebChromeClient(new W35());
                       a("-d");
 
} catch (Exception rx) {
U1.a(rx);
}
    }
    public boolean onCreateOptionsMenu(Menu a) {
            getMenuInflater().inflate(R.menu.i, a);
        MenuItem b1 = a.findItem(R.id.c15);
        b1.setIcon(C5.a(this, R.drawable.b11)); 
        return super.onCreateOptionsMenu(a);
    }
 
    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.c15:
                a("-d");
                return true;
           case R.id.l16:
                a("-d");
                return true;
           case R.id.l17:
                a("-i");
                return true;
           case R.id.l18:
                a("-w");
                return true;
           case R.id.l19:
                a("-e");
                return true;
           case R.id.l20:
                a("-f");
                return true;
           case R.id.m1:
                a("-s");
                return true;

            default:
                return super.onOptionsItemSelected(a);
         }
    }


    public void a(final String dy) {
        P15 e = new P15() {
            public void a() {
                String str;
                try {
                   InputStream is = Runtime.getRuntime().exec("logcat "+dy).getInputStream();
                   InputStreamReader isr = new InputStreamReader(is);
                   BufferedReader br = new BufferedReader(isr);
                   str = br.readLine();
                   while (str != null) {
                       log += str+"\n";
                       str = br.readLine();
                   }
                } catch (IOException e) {
                   U1.a(e);
                }
                runOnUiThread(new P15() {
                    public void a() {
                        w4.loadDataWithBaseURL(null, log, "text", "UTF-8", null);
                    }
                });
             }
         };
         er.execute(new Thread(e));
     }

    public void b(WebView a, int b) {
        pb.setProgress(b);
        if (b >= 100) {
            pb.setVisibility(View.GONE);
            w4.pageDown(true);
        } 
    }

    public void c(WebView a, String b, Bitmap c) {
        pb.setVisibility(View.VISIBLE);
    }
}