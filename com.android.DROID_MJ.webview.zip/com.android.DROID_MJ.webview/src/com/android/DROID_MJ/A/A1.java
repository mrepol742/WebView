package com.android.DROID_MJ.A;

// HISTORY 

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import com.android.DROID_MJ.C.C5;
import android.widget.TextView;
import android.app.AlertDialog;
import android.app.Activity;

import android.view.WindowManager;

import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface; 
 
import android.preference.PreferenceManager;
import android.view.View; 
 import com.android.DROID_MJ.C.C9;
import java.util.ArrayList;

import android.content.Intent;
import android.widget.AdapterView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.Menu;
import java.util.List;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.view.KeyEvent;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.webview.R;

import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.C.C1;

import com.android.DROID_MJ.D.D1;
import android.database.Cursor;
import android.net.Uri;
import android.text.Editable;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import com.android.DROID_MJ.T.T6;
import com.android.DROID_MJ.W.W15;
import com.android.DROID_MJ.D.D3;

import java.io.File;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.widget.SearchView;
//import android.widget.SearchView.SearchAutoComplete;
import android.content.res.Resources;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.W.W13;
import com.android.DROID_MJ.W.W5;
import android.widget.Toolbar;
import android.content.Intent.ShortcutIconResource;
import com.android.DROID_MJ.C.C11;
import android.text.InputType;
import com.android.DROID_MJ.U.U5;
 

public class A1 extends Activity  {
private static W15 w15;
    private static ListView a3;
    private static LinearLayout f2;
    private static ImageView f3;
    private static TextView f4;
 
private static Cursor res;
private static D1 d1;
 
private   List<String> ls= new ArrayList<>(10000);
private   List<String> ls0= new ArrayList<>(10000);
private   int[] it = new int[]{R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u,R.drawable.u};
TextView a2 ;
Button b;
    
     private static   SharedPreferences sp;
    
         
    protected void onCreate(Bundle a) {
         sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.i);
try {
         
        
        
        
        Toolbar a1 = (Toolbar) findViewById(R.id.b7);
          a2 = (TextView) findViewById(R.id.b8);
        a3 = (ListView) findViewById(R.id.a3);
        f2 = (LinearLayout) findViewById(R.id.f2);
        f3 = (ImageView) findViewById(R.id.f3);
        f4 = (TextView) findViewById(R.id.f4);
b = (Button) findViewById(R.id.h16);
        setActionBar(a1);
          d1 = D1.getInstance(getApplicationContext());


a1.setElevation(10);

 res = d1.a();
if (res.getCount() ==  0) {
           f2.setVisibility(View.VISIBLE);
            a3.setVisibility(View.GONE);
} else {
while(res.moveToNext()) { 
    

 ls.add(res.getString(1));
ls0.add(res.getString(2));

}

}

 getActionBar().setDisplayShowTitleEnabled(false);

        getActionBar().setDisplayHomeAsUpEnabled(true);
        int f = C5.b(this,R.color.c);
 
        int g = C5.b(this,R.color.b);
        if (sp.getBoolean("blockSV", true) == true) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        f3.setImageResource(R.drawable.a28);
        f4.setText(getString(R.string.k5));
        Typeface h = G1.a(this, 200);
        a2.setTypeface(h);
        a2.setText(getString(R.string.h18));
f4.setTypeface(h);
            a1.setBackgroundResource(R.drawable.p);
        if (sp.getBoolean("autoUpdate", false) == false) {
           
            a2.setTextColor(f);
   b.setTextColor(f);
f4.setTextColor(f);
        
        } else {

            a2.setTextColor(g);
           b.setTextColor(g);
f4.setTextColor(g);
          
        }
b.setBackgroundResource(R.drawable.e20);
 a1.setNavigationIcon(R.drawable.a2);
        a1.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                
                finish();

            }
        });
 
        
b.setText(getString(R.string.m3));
b.setTypeface(h);

b.setOnClickListener(new C9() {
            public void a(View v) {

                  finish();
            }
        });
if (ls != null && ls0 != null && it != null) {
w15 = new W15(getApplicationContext(), it, ls, ls0, R.layout.b3, 0);
        }
        a3.setAdapter(w15);
        a3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View b, int c, long d) {
         
C1.d(A1.this, "result", ls0.get(c), A1.this);

                finish();

            }
        });

        registerForContextMenu(a3);
        } catch (Exception ex) {
            U1.a(ex);
            finish();
Intent asd = new Intent(getApplicationContext(), A34.class);
asd.putExtra("value", "b");
startActivity(asd);
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                     finish();
                    return false;
            }
        }
        return false;
    }

    public void onCreateContextMenu(final ContextMenu a, View b, ContextMenu.ContextMenuInfo c) {
        super.onCreateContextMenu(a, b, c); 
        MenuItem.OnMenuItemClickListener d = new MenuItem.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem a1) {
                AdapterContextMenuInfo info = (AdapterContextMenuInfo) a1.getMenuInfo();
     
              
       String  a5 = ls.get(info.position);
String a2 = ls0.get(info.position);
                    
                switch (a1.getItemId()) { 
                    case 1:
                        b(a2);
                        return true;
                    case 2:
                      C2.a(A1.this,a2);
                       f(getString(R.string.k9));
                        return true;
                    case 3:
                        c(a2, a5);
                        return true;
                    case 4:
                       
                        h(a5, a2);
                        return true;
    case 9:
                       
                            C2.a(A1.this,a5);
                       f(getString(R.string.k9));
                        return true;
case 6:
a(a2, a5);
return true;
 
               case 5:
                      l(a2, 7);
                    return true;
case 15:
      
l(a2,0);
 
                    return true;
case 16:
       
l(a2, 1);
 
                    return true;
case 17:
       
l(a2,2);
 
                    return true;
case 18:
                           
l(a2, 3);
 
                    return true;
case 19:
                           
l(a2, 5);
 
                    return true;
case 20:
                           
l(a2, 4);
 
                    return true;
case 21:
                           
l(a2, 6);
 
                    return true;
case 22:
                           
l(a2, 8);
 
                    return true;
 }
return true;
            }
        };               
 
        a.add(0, 1, 0, getString(R.string.a8)).setOnMenuItemClickListener(d);
        a.add(0, 2, 0, getString(R.string.k6)).setOnMenuItemClickListener(d);
        a.add(0, 9, 0, getString(R.string.k7)).setOnMenuItemClickListener(d);

        a.add(0, 4, 0, getString(R.string.h11)).setOnMenuItemClickListener(d);
        a.add(0, 6, 0, getString(R.string.h12)).setOnMenuItemClickListener(d);
  
        a.add(0, 3, 0, getString(R.string.k8)).setOnMenuItemClickListener(d);
     
            a.add(0, 19, 0, getString(R.string.y15)).setOnMenuItemClickListener(d);
            a.add(0, 15, 0, getString(R.string.x9)).setOnMenuItemClickListener(d);
            a.add(0, 20, 0, getString(R.string.z15)).setOnMenuItemClickListener(d);
            a.add(0, 21, 0, getString(R.string.f32)).setOnMenuItemClickListener(d);
            a.add(0, 16, 0, getString(R.string.x16)).setOnMenuItemClickListener(d);
            a.add(0, 17, 0, getString(R.string.y11)).setOnMenuItemClickListener(d);
            a.add(0, 18, 0, getString(R.string.z4)).setOnMenuItemClickListener(d);
            a.add(0, 13, 0, getString(R.string.h6)).setOnMenuItemClickListener(d);
            a.add(0, 5, 0, getString(R.string.j)).setOnMenuItemClickListener(d);
            a.add(0, 22, 0, getString(R.string.z12)).setOnMenuItemClickListener(d);
            a.add(0, 12, 0, getString(R.string.i4)).setOnMenuItemClickListener(d);


    }

protected void onResume() {
super.onResume();
d1 = D1.getInstance(getApplicationContext());
}


protected void onDestroy() {
d1.d();
res.close();
super.onDestroy();


if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}

    public boolean onCreateOptionsMenu(Menu a) {
            getMenuInflater().inflate(R.menu.e, a);
 /*
MenuItem mis = a.findItem(R.id.h10);
final SearchView sv5 = (SearchView)
mis.getActionView();
 sv5.setQueryHint(getString(R.string.e));
SearchAutoComplete searchAutoComplete = (SearchAutoComplete) sv5.findViewById(android.R.id.search_src_text);
 if (sp.getBoolean("autoUpdate", false) == false) {
            mis.setIcon(C5.a(this, R.drawable.a)); 
} else {
mis.setIcon(C5.a(this, R.drawable.a)); 
}
        if (sp.getBoolean("autoUpdate", false) == false) {
searchAutoComplete.setHintTextColor(C5.b(this,R.color.j));
searchAutoComplete.setTextColor(C5.b(this,R.color.c));
} else {
searchAutoComplete.setHintTextColor(C5.b(this,R.color.k));
searchAutoComplete.setTextColor(C5.b(this,R.color.b));
}

           searchAutoComplete.setTypeface(G1.a(this, 100));
           
sv5.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
							    sv5.clearFocus();
						      //c49(query);
							    return false;
						}
						public boolean onQueryTextChange(String newText) {
w15.getFilter().filter(newText);
								return false;
						}
       });*/
        return super.onCreateOptionsMenu(a);
    }

    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.d18:
    i();
                return true;
  
            default:
                return super.onOptionsItemSelected(a);
         }
    }


    public void a(String a23, String asd) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.z, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.h12));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.f9);
        final EditText ed = (EditText) c.findViewById(R.id.f10);
        final TextView ti1 = (TextView) c.findViewById(R.id.f11);
        final EditText ed1 = (EditText) c.findViewById(R.id.f12);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
         
        if (sp.getBoolean("autoUpdate", false) == false) {
           ed.setTextColor(e);
   ed1.setTextColor(e);
 ti.setTextColor(e);
   ti1.setTextColor(e);
        } else {
           ed.setTextColor(f);
   ed1.setTextColor(f);
 ti.setTextColor(f);
   ti1.setTextColor(f);
        }
ti.setText(getString(R.string.t3));
ti1.setText(getString(R.string.t4));
if (asd != null) {
   ed.setText(asd);
} else {
Uri hl = Uri.parse(a23);
ed.setText(hl.getHost());
}
   ed1.setText(a23);
        a.setPositiveButton(getString(R.string.i6), new C6() { 
            public void a(DialogInterface a2, int b) { 
             m(ed.getText().toString() ,ed1.getText().toString());
  	        } 
  	    });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
      ed.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  ed1.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
String azx  = ed.getText().toString().replaceAll(" ","");
String aqw  = ed1.getText().toString().replaceAll(" ","");
       if ( azx.length() != 0 && aqw.length() != 0) {
 g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); 
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }
    private void b(String a) {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", a);
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+a+"\"");
        startActivity(Intent.createChooser(b, d));
    }

    private void c(final String b, final String kl) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.h18));
        String c = getString(R.string.l7);
        String d = c.replaceAll("%a", "\""+b+"\"");
        a.setMessage(d);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b1) { 
                 d1.b(b,kl);
String a56 = getString(R.string.h5).replaceAll("%a", b);

f(a56);
                k();
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 



    private void f(String a) {
        W1.b(this, a);

    }
    private void g(String a, String b) {            
D3 d3 = D3.getInstance(getApplicationContext());
d3.c(a, b);
 
}

    public void h(String a23, String asd) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.z, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.h11));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.f9);
        final EditText ed = (EditText) c.findViewById(R.id.f10);
        final TextView ti1 = (TextView) c.findViewById(R.id.f11);
        final EditText ed1 = (EditText) c.findViewById(R.id.f12);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
         
        if (sp.getBoolean("autoUpdate", false) == false) {
           ed.setTextColor(e);
   ed1.setTextColor(e);
 ti.setTextColor(e);
   ti1.setTextColor(e);
        } else {
           ed.setTextColor(f);
   ed1.setTextColor(f);
 ti.setTextColor(f);
   ti1.setTextColor(f);
        }
ti.setText(getString(R.string.t3));
ti1.setText(getString(R.string.t4));
if (a23 != null) {
   ed.setText(a23);
} else {
Uri hl = Uri.parse(asd);
ed.setText(hl.getHost());
}
   ed1.setText(asd);
        a.setPositiveButton(getString(R.string.i6), new C6() { 
            public void a(DialogInterface a2, int b) { 
            g(ed.getText().toString(),ed1.getText().toString());
f(getString(R.string.t2));
  	        } 
  	    });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
      ed.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  ed1.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
String azx  = ed.getText().toString().replaceAll(" ","");
String aqw  = ed1.getText().toString().replaceAll(" ","");
       if ( azx.length() != 0 && aqw.length() != 0) {
 g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); 
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }

  private void i() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.h18));
        a.setMessage(getString(R.string.t5)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
File fl = new File(U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYS5kYg=="));

if (fl.exists()) {
fl.delete();
       f(getString(R.string.t1));
     f2.setVisibility(View.VISIBLE);
                    a3.setVisibility(View.GONE);

}
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    private void j(final List<String> a1, final List<String> a2) {
        runOnUiThread(new P15() {
            public void a() {
                w15.a(a1, a2);
                w15.notifyDataSetChanged();
            }
        });
    }

    private void k() {
        runOnUiThread(new P15() {
            public void a() {
                List<String> itemIdsh= new ArrayList<>(10000);
                List<String> itemIdsh1= new ArrayList<>(10000);
                 res = d1.a();
                if (res.getCount() ==  0) {
                    f2.setVisibility(View.VISIBLE);
                    a3.setVisibility(View.GONE);

                } else {
                    while (res.moveToNext()) { 
                        itemIdsh.add(res.getString(1));
                        itemIdsh1.add(res.getString(2));
                    }
                    if (itemIdsh.size() == 0) {
                        f2.setVisibility(View.VISIBLE);
                        a3.setVisibility(View.GONE);
 
                    } else {
                        j(itemIdsh, itemIdsh1);
                    }
                }
            }
        });
    }
   
    public void l(String url, final int type) {
        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b8, null);
        a.setCancelable(true); 
        switch (type) {
            case 0:
                a.setTitle(getString(R.string.x9)); // LINKS
            break;
            case 1:
                a.setTitle(getString(R.string.x16)); // TRANCEROUT
            break;
            case 2:
                a.setTitle(getString(R.string.y11)); //NPing
            break;
            case 3:
                a.setTitle(getString(R.string.z4)); //Whois
            break;
            case 4:
                a.setTitle(getString(R.string.z15)); //Meta Tags
            break;
            case 5:
                a.setTitle(getString(R.string.y15)); // Headers
            break;
            case 6:
                a.setTitle(getString(R.string.f32)); // Robots
            break;
            case 7:
                a.setTitle(getString(R.string.j)); // Source Code
            break;
            case 8:
                a.setTitle(getString(R.string.z12)); // IP Geolocation
            break;
        }
        a.setView(c);
        final EditText ed = (EditText) c.findViewById(R.id.g8);
        final TextView ti = (TextView) c.findViewById(R.id.e2);
        final Button bn = (Button) c.findViewById(R.id.k20);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        int e3 = C5.b(this,R.color.j);
        int f3 = C5.b(this,R.color.k);
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
bn.setTextColor(e);
            ti.setTextColor(e3);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f3);
bn.setTextColor(f);
        }
        if (type == 0 || type == 4 || type == 5 || type == 7 || type == 6) {
            ed.setText(url);
        } else if (type == 8) {
            ed.setText(U5.c(url));
        } else {
            ed.setText(Uri.parse(url).getHost().replaceAll("www.", ""));
        }
        bn.setText(getString(R.string.i6));
        bn.setBackgroundResource(R.drawable.e20);
        ti.setText(getString(R.string.f31).replaceAll("%a", "\nhttps://example.com").replaceAll("%b", "http://example.com").replaceAll("%c", "example.com"));
 
        bn.setOnClickListener(new C9() {
            public void a(View v) {
                 String a = ed.getText().toString();
                 switch (type) {
                     case 0:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.z()) + a), getString(R.string.x9) +" | " + a);
}
                     break;
                     case 1:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(1)+ a), getString(R.string.x16) +" | " + a);
}
                     break;
                     case 2:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a( 2) + a), getString(R.string.y11) +" | " + a);
}
                     break;
                     case 3:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(  3) + a), getString(R.string.z4) +" | " + a);
}
                     break;
                     case 4:
                         if (W13.a(a) == true) {
                         b(Uri.parse(U4.a(W5.a1()) + a), getString(R.string.z15) +" | " + a);
}
                     break;
                     case 5:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.y()) + a), getString(R.string.y15) +" | " + a);
}
                     break;
                     case 6:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a.replaceAll("/", "")+"/robots.txt"), getString(R.string.f32) +" | " + a);
                             } else {
                                 b(Uri.parse("http://"+a.replaceAll("/", "")+"/robots.txt"), getString(R.string.f32) +" | " + a);
                             }
                         }
                     break;
                     case 7:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a), getString(R.string.j) +" | " + a);
                             } else {
                                 b(Uri.parse("http://"+a), getString(R.string.j) +" | " + a);
                             }
                         }
                     break;
                     case 8:
                         b(Uri.parse(U4.a(W5.a17())+a+U4.a(W5.a18())), getString(R.string.z12) +" | " + a);
                     break;
                 }
            }

            public void b(Uri a, String qr) {
                Intent it = new Intent("com.android.DROID_MJ.webview.intent.action.TOOLS");
                it.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
                it.setPackage(U4.a(W5.a10()));
                it.putExtra("qr", qr);
                it.setData(a);
                if (it.resolveActivity(A1.this.getPackageManager()) != null) {
                    A1.this.startActivity(it);
                }
            }
        });
        ed.addTextChangedListener(new T6 () {
            private void a() {
                String url = ed.getText().toString().replaceAll(" ","");
                if (type == 6 || type == 7) {
                    if (W13.a(url) == false) {
                        ed.setError(getString(R.string.c32));
                    }
                }
            }
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        final AlertDialog g = a.create();
        g.show();
    }

    public void m(String a, String c) { 
try {
        Intent e = new Intent("com.android.DROID_MJ.webview.intent.action.LAUNCH"); 
        e.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        if (sp.getBoolean("dup", false) == true) {
            e.putExtra("duplicate", true);
        } else {
            e.putExtra("duplicate", false);
        }
        e.putExtra("webview", c);
        Intent f = new Intent();
        f.putExtra("android.intent.extra.shortcut.INTENT", e); 
        f.putExtra("android.intent.extra.shortcut.NAME", a);
        f.putExtra("android.intent.extra.shortcut.ICON_RESOURCE",
ShortcutIconResource.fromContext(this, R.drawable.u));
        if (sp.getBoolean("dup", false) == true) {
            f.putExtra("duplicate", true);
        } else {
            f.putExtra("duplicate", false);
        } 
        f.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        sendBroadcast(f);
        C11.a(this, "com.android.DROID_MJ.webview.intent.action.INSTALL_SHORTCUT");
} catch (Exception et) { W1.e(this, getString(R.string.a36),2); }
    }
}