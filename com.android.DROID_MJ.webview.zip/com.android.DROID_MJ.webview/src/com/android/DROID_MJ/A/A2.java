package com.android.DROID_MJ.A;

// SEARCH

import android.app.Activity;


import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.Toolbar;
import android.content.res.Resources;
import android.view.KeyEvent;
import android.app.AlertDialog;
import android.widget.TextView.OnEditorActionListener;
import android.view.WindowManager;
import android.content.Intent;
import android.view.View;  import com.android.DROID_MJ.C.C9;

import android.view.Menu;
import android.view.MenuItem;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.content.ActivityNotFoundException;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import java.util.Locale;
import android.text.Editable;
import com.android.DROID_MJ.T.T6;


import android.widget.AdapterView;
import android.preference.PreferenceManager;
import android.content.pm.ActivityInfo;
import com.android.DROID_MJ.C.C5;

import android.content.pm.ApplicationInfo;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Comparator;

import android.widget.LinearLayout;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.BitmapFactory;

import android.view.ContextMenu;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ImageView;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.C.C3;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.view.inputmethod.EditorInfo;
import java.io.File;
import com.android.DROID_MJ.I.I3;
import android.view.ViewGroup;
import android.widget.Toast;
import com.android.DROID_MJ.V.V2;
import android.database.Cursor;
import com.android.DROID_MJ.D.D2;
import java.util.List;
import com.android.DROID_MJ.W.W16;
import java.util.Collections;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.P.P15;
import android.content.pm.PackageManager.NameNotFoundException;
import com.android.DROID_MJ.D.D1;
import com.android.DROID_MJ.D.D3;
import com.android.DROID_MJ.W.W1;

import android.content.Context;

public class A2 extends Activity  {
    private static EditText p;
    private static ListView d;
    private static LinearLayout cd;
    private static LinearLayout b19;
    private static W16 aa;
    private static ImageView hau;
    private static D3 d3;
    private static D2 d2;
    private static D1 d1;
    private  List<String> ls = new ArrayList<>(10000);

    private  List<String> ls1 = new ArrayList<>(10000);
    private  List<String> ls12 = new ArrayList<>(10000);

    private  List<String> ls2 = new ArrayList<>(10000);
    private  List<String> ls22 = new ArrayList<>(10000);

    private static Cursor res;
    private static SharedPreferences sp;
        
    
    
    protected void onCreate(Bundle savedInstanceState) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("webviewB", false) == false) {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.d);
                } else {
                    setTheme(R.style.b15);
                }
            } else {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.a);
                } else {
                    setTheme(R.style.b19);
                }
            }
        } else {
            if (sp.getBoolean("webviewB", false) == false) {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.e);
                } else {
                    setTheme(R.style.b16);
                }
            } else {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.g);
                } else {
                    setTheme(R.style.c2);
                }
            }
        }
        

O8.b();
super.onCreate(savedInstanceState);
        
setContentView(R.layout.e);
        try {
        
        
        
        
            Toolbar o = (Toolbar) findViewById(R.id.o);
            p = (EditText) findViewById(R.id.p);
            cd = (LinearLayout) findViewById(R.id.y);
            d = (ListView) findViewById(R.id.a3);
            b19 = (LinearLayout) findViewById(R.id.b19);
            hau = (ImageView) findViewById(R.id.e7);
 
            p.setHint(getString(R.string.e));
            if (sp.getBoolean("blockSV", true) == true) {
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            }

            

  d2 = D2.getInstance(getApplicationContext());  
 d1 = D1.getInstance(getApplicationContext());  
d3 = D3.getInstance(getApplicationContext());  
 res = d2.a();
Cursor rest = d1.a();
 Cursor rest1 = d3.a();
if (res.getCount() ==  0) {
d.setVisibility(View.GONE);
} else {
while(res.moveToNext()) { 
ls.add(res.getString(1));
}
}

if (rest.getCount() !=  0) {
while(rest.moveToNext()) { 
ls1.add(rest.getString(1));
ls12.add(rest.getString(2));
}
}

if (rest1.getCount() !=  0) {
while(rest1.moveToNext()) { 
ls2.add(rest1.getString(1));
ls22.add(rest1.getString(2));
}
}

    
 
          aa = new W16(this,ls,ls1, ls12, ls2, ls22);
    if (sp.getString("arrange", "").length() == 0){
                
        }
           if (sp.getString("arrange", "").equals("1z")){
Collections.sort(ls);
           }
       if (sp.getString("arrange", "").equals("7z")){
Collections.sort(ls, Collections.reverseOrder());
           }
        if (sp.getString("arrange", "").equals("30z")){
        }
       if (sp.getString("arrange", "").equals("60z")){
Collections.reverse(ls);
           }
          
            d.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> a1, View b1, int c1, long d1) {
 
                    if (getCallingActivity() != null) {
                        C1.d(A2.this, "result", (String)aa.getItem(c1), A2.this);
                    } else {
                        C1.e(A2.this, "value", (String)aa.getItem(c1), A21.class);
                    }
                    finish();
                    V2.b(A2.this, b19);
                    
                }
            });
	          d.setAdapter(aa);
           getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
           setActionBar(o);
           o.setElevation(10);
           if (sp.getBoolean("showS", true) == true) {
               d.setVisibility(View.VISIBLE);
           } else {
               d.setVisibility(View.GONE);
           }
				     getActionBar().setDisplayShowTitleEnabled(false);
           int d1 = C5.b(this,R.color.c);
           int e = C5.b(this,R.color.b);
           int f = C5.b(this,R.color.j);
           int g = C5.b(this,R.color.k);
           if (sp.getString("hori", "").length() == 0){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (sp.getString("hori", "").equals("1c")){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (sp.getString("hori", "").equals("7c")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
           }
        if (sp.getString("hori", "").equals("30c")) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
           if (sp.getString("hide", "").length() == 0){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); 
m();
           }
           if (sp.getString("hide", "").equals("1d")){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); 
m();
           }
           if (sp.getString("hide", "").equals("7d")) {
               getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); 
           }
           Typeface j = G1.a(this, 100);
           p.setTypeface(j);
           final File fe = new File(I3.a() + "/WebView/.cache/"+"a.cache");
           if (sp.getBoolean("autoUpdate", false) == false) {
               if (sp.getBoolean("webviewB", false) == false) {
                            o.setBackgroundResource(R.drawable.p);
                   b19.setBackgroundResource(R.color.b);
                   cd.setBackgroundResource(R.drawable.w);
                    hau.setImageResource(R.mipmap.b);
               } else {
                   if (!fe.exists()) {
                       o.setBackgroundResource(R.drawable.p);
                       b19.setBackgroundResource(R.color.b);
                       cd.setBackgroundResource(R.drawable.w);
                        hau.setImageResource(R.mipmap.b);
                   } else {
                       o.setBackgroundResource(android.R.color.transparent);
                       b19.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache"))); 
                       cd.setBackgroundResource(R.drawable.w);
                       hau.setImageResource(R.mipmap.b);
                   }
               }
           } else {
               if (sp.getBoolean("webviewB", false) == false) {
                   o.setBackgroundResource(R.drawable.p);
                   cd.setBackgroundResource(R.drawable.w);
                   b19.setBackgroundResource(R.color.n);
                   hau.setImageResource(R.mipmap.b);
               } else {
                   if (!fe.exists()) {
                       o.setBackgroundResource(R.drawable.p);
                       cd.setBackgroundResource(R.drawable.w);
                       b19.setBackgroundResource(R.color.n);
                       hau.setImageResource(R.mipmap.b);
                   } else {
                       o.setBackgroundResource(android.R.color.transparent);
                       b19.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache")));
                       cd.setBackgroundResource(R.drawable.w);
                       hau.setImageResource(R.mipmap.b);
                   }
               }
           }
       
       if (sp.getBoolean("autoUpdate", false) == false) {
           p.setTextColor(d1);
           p.setHintTextColor(f);
       } else {
           p.setTextColor(e);
           p.setHintTextColor(g);
       }
       p.addTextChangedListener(new T6() {   
           public void c(Editable a) {
           }
           public void a(CharSequence a, int b, int c, int d) {     
           }
           public void b(CharSequence a1, int b1, int c1, int d1) {
               invalidateOptionsMenu();
 
               aa.getFilter().filter(p.getText().toString());
           }
       });
       cd.setOnClickListener(new C9() {
           public void a(View a) {
                V2.a(A2.this, p);
           }
       });
       p.setOnEditorActionListener(new OnEditorActionListener() {
           public boolean onEditorAction(android.widget.TextView v, int actionId, KeyEvent event) {
               boolean handled = false;
               if (actionId ==   EditorInfo.IME_ACTION_SEARCH) {
                   handled = true;
                   getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                                   V2.b(A2.this, b19);
                   String query = p.getText().toString();

                   d2.c(query, A2.this);
                       if (getCallingActivity() != null) {
                           C1.d(A2.this, "result", query, A2.this);
                       } else {
                           C1.e(A2.this, "value", query, A21.class);
                       }
                       finish();
                       
                   
               }
               return handled;
            }
        });
        registerForContextMenu(d);
        } catch (Exception ex) {
            U1.a(ex);
            finish();
Intent asd = new Intent(getApplicationContext(), A34.class);
asd.putExtra("value", "a");
startActivity(asd);
        }
    }

     protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
 
        switch (requestCode) {
            case 100:
            if (resultCode == RESULT_OK && null != data) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String speechText = result.get(0);
         d2.c(speechText, this);
                p.setText(speechText);

            }
            break;
        }
 
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:   
       
                     finish();

          return false;
            }

        }
        return false;
    }
protected void onResume() {
super.onResume();
getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
onNewIntent(getIntent());
        File f = new File(I3.a() + "/WebView/.cache");
        if (!f.exists()) {
            f.mkdirs();
        }
invalidateOptionsMenu();

d2 = D2.getInstance(getApplicationContext());
}


protected void onDestroy() {
d2.d();

res.close();
super.onDestroy();


if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}
protected void onStop() {
super.onStop();
                V2.b(this, b19);
}
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.c, menu);
 

        return super.onCreateOptionsMenu(menu);
    }
public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem a = menu.findItem(R.id.d15);
        MenuItem b = menu.findItem(R.id.a19);

      SharedPreferences hahahh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (hahahh.getBoolean("voice", true) == true) {
            if (p.getText().toString().length() == 0) {
                invalidateOptionsMenu();
                if (n() == true) {
                    b.setVisible(true);
                    a.setVisible(false);
                } else {
                    b.setVisible(false);
                    a.setVisible(true);
                }
            } else {
                b.setVisible(false);
                a.setVisible(true);
            }
        } else {
            a.setVisible(true);
            b.setVisible(false);
        }

            a.setIcon(C5.a(this, R.drawable.d)); 
            b.setIcon(C5.a(this, R.drawable.f)); 

return true;
}
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.d15:
if (p.getText().toString().length() == 0) {

finish();

} else {
                f2();
}
                return true;
            case R.id.a19:
                f3();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
         }
    }

    public void onCreateContextMenu(ContextMenu a, View b, ContextMenu.ContextMenuInfo c) {
        super.onCreateContextMenu(a, b, c); 

        MenuItem.OnMenuItemClickListener d = new MenuItem.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem a1) {
       AdapterContextMenuInfo info = (AdapterContextMenuInfo) a1.getMenuInfo();
     
  

              
       String query23 = (String)aa.getItem(info.position);
                switch (a1.getItemId()) { 
                    case 1:
                         f4(query23);
                        break;
                    case 2:
C2.a(A2.this,query23); f6(getString(R.string.k9));
                        break;
                    case 3:
f5(query23);


                        break;
case 4:
      if (getCallingActivity() != null) {
                           C1.d(A2.this, "result", query23, A2.this);
                       } else {
                           C1.e(A2.this, "value", query23, A21.class);
                       }
                       finish();
                       
break;
                }
                return true;
            }
        };               
        a.add(0, 4, 0, getString(R.string.o5)).setOnMenuItemClickListener(d);
               a.add(0, 1, 0, getString(R.string.a8)).setOnMenuItemClickListener(d);
               a.add(0, 2, 0, getString(R.string.u)).setOnMenuItemClickListener(d);
               a.add(0, 3, 0, getString(R.string.k8)).setOnMenuItemClickListener(d);
        
    }

    private void f2() {
 
     p.getText().clear();
        invalidateOptionsMenu();
    }

    private void f3() {
 
        Intent a = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        a.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        a.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        a.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.k10));
         try {
            startActivityForResult(a, 100);
            p.getText().clear();
        } catch (ActivityNotFoundException b) {
        }
 
    }
    public void f4(String a) {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", a);
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+a+"\"");
        startActivity(Intent.createChooser(b, d));
    }

   public void f5(final String b) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.e));
        String c = getString(R.string.l7);
        String dy = c.replaceAll("%a", "\""+b+"\"");
        a.setMessage(dy);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b1) { 
         d2.b(b);

								
String a56 = getString(R.string.h5).replaceAll("%a", b);

f6(a56);
                k();
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    private void f6(String a) {
        W1.b(this, a);
    }

    private void j(final List<String> a1) {
        runOnUiThread(new P15() {
            public void a() {
                aa.a(a1);
                aa.notifyDataSetChanged();
            }
        });
    }

    private void k() {
        runOnUiThread(new P15() {
            public void a() {
                List<String> itemIdsh= new ArrayList<>(10000);
                res = d2.a();
                if (res.getCount() ==  0) {
                    d.setVisibility(View.GONE);
                } else {
                    while (res.moveToNext()) { 
                        itemIdsh.add(res.getString(1));
                       
                    }
                    if (itemIdsh.size() == 0) {
         d.setVisibility(View.GONE);
                    
                    } else {
                        j(itemIdsh);
                    }
                }
            }
        });
    }

    private void l() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void m() {
        View a = getWindow().getDecorView();
        a.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
       
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("webviewB", false) == false) {
                a.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); 
                getWindow().setStatusBarColor(C5.b(this,R.color.b));
            }
        } 
    }
    private boolean n() {
        try {
            boolean bn = C3.a(U4.a("Y29tLmdvb2dsZS5hbmRyb2lkLmdvb2dsZXF1aWNrc2VhcmNoYm94"), this.getPackageManager());
            final ApplicationInfo ai = this.getPackageManager().getApplicationInfo(U4.a("Y29tLmdvb2dsZS5hbmRyb2lkLmdvb2dsZXF1aWNrc2VhcmNoYm94"),0);
            boolean bn1 = ai.enabled;
            if (bn == true) {
                if (bn1 == true) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }       
        } catch (NameNotFoundException e) {
            U1.a(e);
                return false;
        }
     
    }  
    protected void onNewIntent(Intent a) {
        try {
            String val = a.getStringExtra("value");
            if (val != null) {
                p.setText(val);
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
a.removeExtra("value");
                        setIntent(a);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        
        if (sp.getString("hide", "").equals("30d")) {
            if (hasFocus) {
                l();
            }
        }
    }

}