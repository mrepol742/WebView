package com.android.DROID_MJ.A;

// databases error 

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;

import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.webview.R;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.I.I2;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.C.C13;
import java.io.File;
import com.android.DROID_MJ.W.W1;

public class A34 extends Activity  {
    protected void onCreate(Bundle a) {
         
              SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (b.getBoolean("autoUpdate", false) == false) {
           
                setTheme(R.style.b8);
         
        } else {
        
                setTheme(R.style.b14);
         
        }
 
        

O8.b();
super.onCreate(a);


    }

   protected void onResume() {
       super.onResume();
        onNewIntent(getIntent());

if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();


}
   }
    private void a(final String b) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.n10));
final String b56 = b.replaceAll(" ", "").toLowerCase();
if (b56.endsWith("b")) {
 
        a.setMessage(getString(R.string.n7));
} else if (b56.endsWith("c")) {
 
a.setMessage(getString(R.string.n8));
} else if (b56.endsWith("a")) {
 
a.setMessage(getString(R.string.n9));

}
 
        a.setPositiveButton(getString(R.string.q15), new C6() {
            public void a(DialogInterface a, int b1) { 
 String hj = b.replaceAll("file://", "");
if (b56.endsWith("b")) {
 b(hj,U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYS5kYg=="));
} else if (b56.endsWith("c")) {
 b(hj, U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYy5kYg=="));
} else if (b56.endsWith("a")) {
 b(hj, U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYi5kYg=="));
} 


            } 
   	     });
        a.setNegativeButton(getString(R.string.a13), new C6() {
            public void a(DialogInterface a, int which) { 
if (b56.endsWith("b")) {
 e(U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYS5kYg=="));
} else if (b56.endsWith("c")) {
e( U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYy5kYg=="));
} else if (b56.endsWith("a")) {
e( U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYi5kYg=="));
} 
            } 
   	     });
        a.setNeutralButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
finish();
            } 
   	     });
a.setOnDismissListener(new C13() {
            public void a(DialogInterface di) {
                finish();
            }
        });
        a.create().show();
    } 
private void b(String a, String b) {
synchronized (a) {
synchronized (b) {
        boolean bn = I2.a(a, b);
        if (bn == true) {
            c(getString(R.string.d21));
 
        } else {
            d(getString(R.string.d22));
        }
}
}
finish();
}
    public void c(String a) {
        W1.b(this, a);
    }
    public void d(String a) {
        W1.c(this, a);
    }
    private void e(String a) {
        File file = new File(a);
        if ( file.exists() ) {
            file.delete();
        }
    }
    protected void onNewIntent(Intent a) {
        try {
            String val = a.getStringExtra("value");
            if (val != null) {
                a(val);
            a.removeExtra("value");
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
            

        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}