package com.android.DROID_MJ.A;
import android.os.Bundle;
import com.android.DROID_MJ.C.C1;

public class A25 extends A22 {
    protected void a1(Bundle be) {
        C1.e(this, "search", "b", A10.class);
    }
}