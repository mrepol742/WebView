package com.android.DROID_MJ.A;
import android.content.Context;
import android.os.Build;
import android.app.Notification;

public class A37 {
    public static Notification.Builder a(Context ct, String ch) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(ct, ch);
        } 
        return new Notification.Builder(ct);
    }
}