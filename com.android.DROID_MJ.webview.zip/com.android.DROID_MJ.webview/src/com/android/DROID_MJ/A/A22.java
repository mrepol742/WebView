package com.android.DROID_MJ.A;
import android.app.Activity;

import android.os.Bundle;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;

public class A22 extends Activity {
    protected void onCreate(Bundle be) {
        a(be);
        

O8.b();
super.onCreate(be);
        a1(be);
    }
    protected void onResume() {
        b();
        super.onResume();

if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();

}
    }
    protected void onStop() {
        c();
        super.onStop();
    }
    protected void onDestroy() {
        d();
        super.onDestroy();
    }
    protected void a(Bundle be) {
    }
    protected void a1(Bundle be) {
    }
    protected void b() {
    }
    protected void c() {
    }
    protected void d() {
    }
}