package com.android.DROID_MJ.A;

// backup auto immport
import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.webview.R;

import android.app.AlertDialog;
import android.content.DialogInterface;
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.I.I2;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.C.C13;
import com.android.DROID_MJ.W.W1;

public class A8 extends Activity  {
    protected void onCreate(Bundle a) {
         
            setTheme(R.style.b8);
 
        

O8.b();
super.onCreate(a);


    }

   protected void onResume() {
       super.onResume();
        onNewIntent(getIntent());

if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();


}
   }
    private void a(final String b) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
final String b56 = b.replaceAll(" ", "").toLowerCase();
if (b56.endsWith(".history")) {
a.setTitle(getString(R.string.h18));
        a.setMessage(getString(R.string.d33).replaceAll("%a", b));
} else if (b56.endsWith(".bookmarks")) {
a.setTitle(getString(R.string.h11));
a.setMessage(getString(R.string.d34).replaceAll("%a", b));
} else if (b56.endsWith(".search")) {
a.setTitle(getString(R.string.e));
a.setMessage(getString(R.string.d35).replaceAll("%a", b));
} else if (b56.endsWith(".settings")) {
a.setTitle(getString(R.string.h3));
a.setMessage(getString(R.string.d36).replaceAll("%a", b));
}
 
        a.setPositiveButton(getString(R.string.q15), new C6() {
            public void a(DialogInterface a, int b1) { 
 String hj = b.replaceAll("file://", "");
if (b56.endsWith(".history")) {
 b(hj,U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYS5kYg=="));
} else if (b56.endsWith(".bookmarks")) {
 b(hj, U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYy5kYg=="));
} else if (b56.endsWith(".search")) {
 b(hj, U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYi5kYg=="));
} else if (b56.endsWith(".settings")) {
b(hj, U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9zaGFyZWRfcHJlZnMvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlld19wcmVmZXJlbmNlcy54bWw="));
}


            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
finish();
            } 
   	     });
a.setOnDismissListener(new C13() {
            public void a(DialogInterface di) {
                finish();
            }
        });
        a.create().show();
    } 
private void b(String a, String b) {
synchronized (a) {
synchronized (b) {
        boolean bn = I2.a(a, b, 20);
        if (bn == true) {
            c(getString(R.string.b27));
 
        } else {
            d(getString(R.string.b28));
        }
}
}
finish();
}
    public void c(String a) {
        W1.b(this, a);
    }
    public void d(String a) {
        W1.c(this, a);
    }
    protected void onNewIntent(Intent a) {
        try {
            String action = a.getAction();
            String data = a.getDataString();
            if (Intent.ACTION_VIEW.equals(action) || "com.android.DROID_MJ.webview.intent.action.VIEW".equals(action)) {
      if (data != null) {
          a(data);
            } else {
finish();
}
} else {
finish();
}
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
            

        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}