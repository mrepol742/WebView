package com.android.DROID_MJ.A;

// SETTINGS
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import com.android.DROID_MJ.C.C5;
import android.widget.TextView;
import android.widget.Toolbar;
import android.app.Activity;

import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import com.android.DROID_MJ.W.W15;
import java.util.ArrayList;
import java.util.List;
import com.android.DROID_MJ.webview.R;
import android.preference.PreferenceManager;
import android.view.View; 
  import com.android.DROID_MJ.C.C9;
import android.widget.AdapterView;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import com.android.DROID_MJ.W.W5;
import android.app.AlertDialog;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.text.Editable;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.T.T6;
import com.android.DROID_MJ.C.C13;
import com.android.DROID_MJ.V.V2;
import com.android.DROID_MJ.P.P15;

public class A19 extends Activity {
    private static TextView c;
    private static SharedPreferences sp;
        
            List<String> lt = new ArrayList<>();
        List<String> lt2 = new ArrayList<>();
    W15 aa;
    protected void onCreate(Bundle a) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.a);
        
        
        
        
      final  ListView a3 = (ListView) findViewById(R.id.a3);
        Toolbar tl = (Toolbar) findViewById(R.id.c3);
        TextView b = (TextView) findViewById(R.id.c4);
        setActionBar(tl);
        c = (TextView) findViewById(R.id.c5);
        Typeface j = G1.a(this, 200);
        int k = C5.b(this,R.color.c);
        int l = C5.b(this,R.color.b);
        b.setTypeface(j);
        c.setTypeface(j);        
        if (sp.getBoolean("autoUpdate", false) == false) {
            b.setTextColor(k);
            c.setTextColor(k);
        } else {
            b.setTextColor(l);
            c.setTextColor(l);
        }
       tl.setBackgroundResource(R.drawable.p);
            tl.setNavigationIcon(R.drawable.a2);
        tl.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();
            }
        });
        SharedPreferences prefs = getSharedPreferences("webDa",0);
        boolean d78 = prefs.getBoolean("webDa", false);
        int[] it = new int[]{R.drawable.c17, R.drawable.c18, R.drawable.c19, R.drawable.c20, R.drawable.d1, R.drawable.d2, R.drawable.d3, R.drawable.d4, R.drawable.d5, R.drawable.e1,R.drawable.e12, R.drawable.d6, R.drawable.e13, R.drawable.d20};
       lt.add(getString(R.string.a));
        lt.add(getString(R.string.o10));
        lt.add(getString(R.string.e));
        lt.add(getString(R.string.f));
        lt.add(getString(R.string.b));
        lt.add(getString(R.string.g));
        lt.add(getString(R.string.c));
        lt.add(getString(R.string.i));
        lt.add(getString(R.string.h10));
        lt.add(getString(R.string.t6));
        lt.add(getString(R.string.l14));
        lt.add(getString(R.string.l));
        lt.add(getString(R.string.f14));
        if (d78 == true) {
            lt.add(getString(R.string.t7));
        }

        lt2.add(getString(R.string.t8));
        lt2.add(getString(R.string.t9));
        lt2.add(getString(R.string.t10));
        lt2.add(getString(R.string.t11));
        lt2.add(getString(R.string.t12));
        lt2.add(getString(R.string.t13));
        lt2.add(getString(R.string.t14));
        lt2.add(getString(R.string.t15)); 
        lt2.add(getString(R.string.t16));
        lt2.add(getString(R.string.t17));
        lt2.add(getString(R.string.f16));
        lt2.add(getString(R.string.t18));
        lt2.add(getString(R.string.f15));
        if (d78 == true) {
            lt2.add(getString(R.string.t19));     
        }

        b.setText(getString(R.string.h3));

        c.setText(getString(R.string.l13));

        aa = new W15(getApplicationContext(), it, lt, lt2, R.layout.b3, 2);
        a3.setAdapter(aa);
        a3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView <?> a, View b, int c, long d) {
                a(c);
            }
        });
        a3.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView <?> a, View b, int c, long d) {
                lt.remove(c);
                lt2.remove(c);
               d(lt, lt2);
                return true;
            }
        });
        if (d78 == true) {
            c.setVisibility(View.VISIBLE);
        } else {
            c.setVisibility(View.GONE);
        }
    }
protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}

 
    private void a(int a) {

        switch (a) {

            case 0: 
                C1.e(this, "search", "b", A10.class);
            break;
            case 1: 
                C1.e(this, "search", "f", A10.class);
            break;
            case 2: 
                C1.e(this, "search", "d", A10.class);
            break;
            case 3: 
                C1.e(this, "search", "e", A10.class);
            break;
            case 4: 
  if (sp.getBoolean("lockWn99", false) == true ){
          
              C1.a(this, A31.class);
 
            } else {
                C1.e(this, "search", "g", A10.class);
}
            break;
            case 5: 
                C1.e(this, "search", "i", A10.class);
            break;
            case 6: 
                C1.e(this, "search", "h", A10.class);
            break;
            case 7: 
                C1.e(this, "search", "c", A10.class);
            break;
            case 8: 
                C1.e(this, "search", "a", A10.class);
            break;
            case 9: 
  if (sp.getBoolean("lockWn99", false) == true ){
          
              C1.a(this, A30.class);
 
            } else {
 
                C1.e(this, "search", "l", A10.class);
}
            break;
            case 10:
                C1.a(this,  A33.class);
            break;
            case 11: 
                C1.e(this, "search", "j", A10.class);
            break;
            case 12: 
                b();
            break;
case 13: 
                C1.e(this, "search", "k", A10.class);
            break;
        }
    }
         
     public void b() {
final AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b18, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.f14));
        a.setView(c);
        final EditText ti = (EditText) c.findViewById(R.id.k16);
        final TextView ti2 = (TextView) c.findViewById(R.id.b15);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        ti2.setText(getString(R.string.f36));
        if (sp.getBoolean("autoUpdate", false) == false) {
            ti.setTextColor(e); ti2.setTextColor(e);
        } else {
            ti.setTextColor(f); ti2.setTextColor(f);
        }
        a.setPositiveButton(getString(R.string.w13), new C6() {
            public void a(DialogInterface a, int b) {
                c(ti.getText().toString().replaceAll(" ", "+"));
                a.dismiss();
W1.b(A19.this, getString(R.string.g27));
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
              
                a.dismiss();
            }
        });

 
        final AlertDialog g = a.create();

ti.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton= g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ti.getText().toString().replaceAll(" ","");

     if (jhh.length() >= 30) {

                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);

     ti.setError(getString(R.string.g32).replaceAll("%a",Integer.toString(jhh.length())));



                }

            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
    }
public void c(final String a) {
new Thread() {
public void run() {
U6.a(U4.a(W5.a2())+a);
}
}.start();

}

    private void d(final List<String> a1, final List<String> a2) {
        runOnUiThread(new P15() {
            public void a() {
                aa.a(a1, a2);
                aa.notifyDataSetChanged();
            }
        });
    }
}