package com.android.DROID_MJ.A;

// WEBVIEW
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;

import com.android.DROID_MJ.webview.R;
import android.app.NotificationManager;
import com.android.DROID_MJ.S.S4;
import com.android.DROID_MJ.C.C1;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.O.O8;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.io.InputStreamReader;
import android.app.Notification;
import com.android.DROID_MJ.C.C5;
import android.graphics.BitmapFactory;
import android.app.Notification;
import com.android.DROID_MJ.U.U4;
import com.java.DROID_MJ.U.U5;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.P.P15;
import android.content.Context;
import java.util.concurrent.Executor;
import com.id;
import java.text.DateFormat;
import java.util.Date;
import java.text.SimpleDateFormat;
import android.content.Intent;
import com.android.DROID_MJ.W.W1;
import android.app.PendingIntent;
import com.android.DROID_MJ.W.W13;
import com.android.DROID_MJ.C.C11;
import com.android.DROID_MJ.U.U6;
import java.io.File;
import com.java.DROID_MJ.U.U7;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.I.I3;
import android.net.Uri;
import com.notif_id;
import android.webkit.URLUtil;
import com.android.DROID_MJ.C.C3;
import com.android.DROID_MJ.S.S3;
import com.android.DROID_MJ.webview.WebView;
import java.io.InputStream;
import android.content.res.Resources;
import com.android.DROID_MJ.W.W11;


public class A20 extends A23 {
    private static NotificationChannel nc;
    private static SharedPreferences sp;

    public void a() {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        try {
            k();
            h();
            if (sp.getBoolean("nCV", false) == true) {
                C1.b(this, S4.class); 
            } else {
                C1.i(this, S4.class);
            }
            U1.a("WebView Created");
            if (Build.VERSION.SDK_INT >= 26) {
                a1("a", getString(R.string.y16));
                a1("b", getString(R.string.y17));
                a1("c", getString(R.string.y18));
                a1("d", getString(R.string.y19));
                a1("e", getString(R.string.y20));
                a1("f", getString(R.string.z1));
                a1("g", getString(R.string.z2));
                a1("h", getString(R.string.z3));
                a1("i", getString(R.string.g26));
                U1.a("Notification Channel Created");
            }
 
         } catch (Exception ex5) {
             U1.a(ex5);
         }
         boolean bn = getResources().getBoolean(R.bool.b);
         if (bn) {
             g(true);
         } else if (sp.getBoolean("autoUpdate55", false) == false) {
             g(false);
         }
         final SharedPreferences crn = getSharedPreferences("crn", 0);
         final SimpleDateFormat crnD = new SimpleDateFormat("MMddyyyy");
         P15 crnP15 = new P15() {
             public void a() {
                  try {
                      if (crn.getInt("crn",0) == 0 || Integer.parseInt(crnD.format(new Date())) >crn.getInt("crn",0)) {
                          SharedPreferences.Editor se = crn.edit();
                          se.putInt("crn", Integer.parseInt(crnD.format(new Date())));
                           se.apply();
                           j();
                      }
                  } catch (NumberFormatException nfe) {
                      U1.a(nfe);
                  }
             }
         }; 
         new Thread(crnP15).start();
    }

    private void a1(String a, String b) {
        
        try {
            if (sp.getString("py", "").length() == 0) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_DEFAULT);
            }
            if (sp.getString("py", "").equals("1x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_DEFAULT);
            }
            if (sp.getString("py", "").equals("7x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_HIGH);
            }
            if (sp.getString("py", "").equals("30x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_LOW);
            }
            if (sp.getString("py", "").equals("60x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_MAX);
            }
            if (sp.getString("py", "").equals("120x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_MIN);
            }
            if (sp.getString("py", "").equals("240x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_NONE);
            }
            if (sp.getString("py", "").equals("480x")) {
                nc = new NotificationChannel(a, a, NotificationManager.IMPORTANCE_UNSPECIFIED);
            }
            nc.setDescription(b);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(nc);
        } catch (Exception ec) {
            U1.a(ec);
        }
    }

    private void g(boolean bn ){
        SharedPreferences.Editor se = sp.edit();
        se.putBoolean("autoUpdate", bn);
        se.apply();
    }

    public void h() {
       Date date = new Date();     
       DateFormat sdf = new   SimpleDateFormat("HHmmss");
       String fi = sdf.format(date);
       if (sp.getBoolean("autoUpdate55", false) == true) {
           try {
              if (Integer.parseInt(fi) >= 183000 || 053000 <= Integer.parseInt(fi)) {
                  if (sp.getBoolean("autoUpdate", false) == false) {
                      g(true);
                  }
              } else {
                  if (sp.getBoolean("autoUpdate", false) == true) {
                      g(false);
                  }
              }
           } catch (NumberFormatException nfe) {
              U1.a(nfe);
           }
        }  
    }

    public void j() {
        Notification.Builder m = A37.a(this, "i"); // i
        m.setSmallIcon(R.drawable.r);
        m.setContentTitle(getString(R.string.f39));
            m.setContentText(getString(R.string.g24));
Notification.BigTextStyle bigText = new Notification.BigTextStyle();
                            bigText.bigText(getString(R.string.g24));
                            bigText.setBigContentTitle(getString(R.string.f39));
                            bigText.setSummaryText(getString(R.string.g25));
         
m.setStyle(bigText);
            m.setColor(C5.b(this,R.color.e));
        m.setAutoCancel(false);
        m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT <= 26) {
                m.setPriority(Notification.PRIORITY_MAX);
        }
 m.setVisibility(Notification.VISIBILITY_PUBLIC);

 Intent j11 = new Intent(this, A26.class);

        PendingIntent k567 = PendingIntent.getActivity(this, 2, j11,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.setContentIntent(k567);
        m.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.r));
Intent j = new Intent(this, A21.class);
j.putExtra("webview", U4.a(W5.a7()));
PendingIntent pi23 = PendingIntent.getActivity(this, 3, j,  PendingIntent.FLAG_UPDATE_CURRENT);
       


 m.addAction(new Notification.Action(R.drawable.q, getString(R.string.g22), pi23));

Intent j55 = new Intent(this, A21.class);
j55.putExtra("webview", U4.a(W5.a8()));
PendingIntent pi235 = PendingIntent.getActivity(this, 0, j55,  PendingIntent.FLAG_UPDATE_CURRENT);
        

m.addAction(new Notification.Action(R.drawable.q, getString(R.string.g23), pi235));
                NotificationManager nmc = (NotificationManager) getSystemService("notification");
        nmc.notify(notif_id.a, m.build());
}


   private void k() {
       P15 p = new P15() {
           public void a() {
               File fe = new File(U4.a(W5.s())+WebView.Cache.f);
               if (!fe.exists()) {
                    fe.mkdir();
               }

           }
       };
       new Thread(p).start();
   }
}

