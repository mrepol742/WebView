package com.android.DROID_MJ.A;

// TERMS AND CONDITIONS 
// PRIVACY POLICY

import com.android.DROID_MJ.W.W4;
import com.android.DROID_MJ.webview.R;
import android.app.Activity;

import android.os.Bundle;
import com.android.DROID_MJ.C.C5;
import android.view.KeyEvent;
import android.widget.Toolbar;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.widget.TextView;
import android.view.View; 
 import com.android.DROID_MJ.C.C9;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.W.W3;
import android.content.Intent;
import android.webkit.WebView;
import java.util.HashMap;
import java.util.Map;
import android.graphics.Bitmap;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.webkit.WebSettings;


public class A6 extends Activity  {
    
        
    
    
    private static W4 a;
    private static A6 A6;
   private static Map<String, String> ms;
private static TextView d;
    public static A6 getInstance() {
        return A6;
    }

    protected void onCreate(Bundle savedInstanceState) {
  SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(savedInstanceState);
        
setContentView(R.layout.o);
A6 = this;
        
        
        
        
   ms = new HashMap<String, String>();
        ms.put("DNT", "1");
     a = (W4)findViewById(R.id.j);
Toolbar c = (Toolbar) findViewById(R.id.b7);
  d = (TextView) findViewById(R.id.b8);
 d.setTypeface(G1.a(this, 200));
    setActionBar(c);
c.setElevation(10);
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);
        SharedPreferences sp1 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        c.setNavigationIcon(R.drawable.d);
        if (sp.getBoolean("autoUpdate", false) == false) {
a.setBackgroundResource(R.color.b);
         d.setTextColor(C5.b(this,R.color.c));

findViewById(R.id.l11).setBackgroundResource(R.color.b);
        } else {
         d.setTextColor(C5.b(this,R.color.b));
a.setBackgroundResource(R.color.n);
        
            findViewById(R.id.l11).setBackgroundResource(R.color.n);
        }

c.setBackgroundResource(R.drawable.p);
c.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        });
        WebSettings ws = a.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
    a.setWebViewClient(new W3());

    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (a.canGoBack()) {
                        a.goBack();
                    } else {
                        finish();

                    }
                    return false;
            }

        }
        return false;
    }
    protected void onResume() {
 
super.onResume();
onNewIntent(getIntent());


if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();


}
}
    public boolean a(WebView a, String b) {
       b(b);
d.setText(a.getTitle());
        return true;
    }

 
    private void b(String b) {
        SharedPreferences c = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (c.getBoolean("dont", true) == true) {
            a.loadUrl(b,ms);
        } else {
            a.loadUrl(b);
        }
    }
 
   protected void onNewIntent(Intent a) {
        try {
            String val = a.getStringExtra("value");
            if (val != null) {
                b(val);
                if (val.contains("terms")) {
                    d.setText(getString(R.string.f12));
                } else {
                    d.setText(getString(R.string.f13));
                }
                a.removeExtra("value");
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}