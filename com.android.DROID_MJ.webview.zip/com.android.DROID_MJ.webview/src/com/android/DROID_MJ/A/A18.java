package com.android.DROID_MJ.A;

// Manage Space
import com.android.DROID_MJ.webview.R;
import android.widget.Toolbar;
import android.widget.TextView;
import com.android.DROID_MJ.C.C5;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.AlertDialog;
import android.preference.PreferenceManager;
import android.app.Activity;

import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.text.format.Formatter;
import java.io.File;

import android.widget.ListView;
import com.android.DROID_MJ.W.W19;
import android.view.View; 
import com.android.DROID_MJ.C.C9;
import android.widget.AdapterView;
import com.android.DROID_MJ.U.U4;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.content.Intent;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import android.view.ViewGroup;
import android.net.Uri;
import android.provider.Settings;
import com.android.DROID_MJ.I.I3;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import com.java.DROID_MJ.I.I2;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import com.android.DROID_MJ.T.T6;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.W.W5;
import com.id;
import android.os.CountDownTimer;
import com.android.DROID_MJ.O.O5;
import com.android.DROID_MJ.C.C11;
import com.android.DROID_MJ.M.M2;
import com.android.DROID_MJ.D.D1;

public class A18 extends Activity  {
    private static W19 w19;
   private static ListView a3 ;

        private List<String> a = new ArrayList<>(8);

   private List<String> b = new ArrayList<>(8);
    private static SharedPreferences sp;

    protected void onCreate(Bundle a22) {
         sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(a22);
        
setContentView(R.layout.a4);

        Toolbar g5 = (Toolbar) findViewById(R.id.b7);
        TextView g6 = (TextView) findViewById(R.id.b8);
         a3 = (ListView) findViewById(R.id.a3);
setActionBar(g5);
        getActionBar().setDisplayShowTitleEnabled(false);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        int it = C5.b(this,R.color.c);
        int it2 = C5.b(this,R.color.b);
        if (sp.getBoolean("autoUpdate", false) == false) {
            g6.setTextColor(it);
        } else {
            g6.setTextColor(it2);
        }
        g5.setBackgroundResource(R.drawable.p);
            g5.setNavigationIcon(R.drawable.a2);
         g6.setTypeface(G1.a(this, 200));
       g6.setText(getString(R.string.l14));
        g5.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();
            }
        });
        g5.setElevation(10);
        M2.a(this, M2.STORAGE, 1);
        a();
a2();

    }

    protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
a1();
}


    private void a() {
        w19 = new W19(this, a, b);
        a3.setAdapter(w19);
        a3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View b, int c, long d) {
                i(c);
            }
        });
    }

    public long b(String as) {
        File a = new File(as);
        return f(a);
    }

    private String c(long a) {
        String f = Formatter.formatFileSize(this, a);
        return f;
    }

    private long d(String as) {
        long f = 0;
        File a = new File(as);
        if (a.exists()) {
            String[] b = a.list();
            if ( b != null) {
                f = b.length;
            }
        }
        return f;
    }

    private long e(File a) {
        return f(a);
    }

    private long e(String a) {
        return f(new File(a));
    }

    public long f(File a) {
        long b = 0;
        if (a.exists()) {
            File[] c = a.listFiles();
            if (c != null) {
            int d = c.length;
            for (int e = 0; e < d; e++) {
                 if (c[e].isFile()) {
                     b += c[e].length();
                 } else {
                     b += f(c[e]);
                 }
            }
        }
}
        return b;
    }

    private String g(String as) {
        long h = 0;
        File a = new File(as);
        if (a.exists()) {
            h = a.length();
        }
        return Long.toString(h);
    }

    private long h(String as) {
        long h = 0;
        File a = new File(as);
        if (a.exists()) {
            h = a.length();
        }
        return h;
    }

    private void i(int a) {
        if (a == 0) {
            k(getString(R.string.l14), getString(R.string.u4));
        } else if ( a == 1 ) {
            m(getString(R.string.l14), getString(R.string.u5));
        } else if ( a == 2 ) {
            n(getString(R.string.l14),getString(R.string.t5));
        } else if ( a == 3 ) {
            o(getString(R.string.l14),getString(R.string.u6));
        } else if ( a == 4 ) {
            x(getString(R.string.l14),getString(R.string.u7));
        } else if ( a == 5 ) {
            if (M2.a(this, M2.STORAGE, 2) == true) {
                t(getString(R.string.l14),getString(R.string.u8));
            }
        } else if ( a == 6 ) {
            if (M2.a(this, M2.STORAGE, 3) == true) {
                u(getString(R.string.l14),getString(R.string.u9));
            }
        } else if ( a == 7 ) {
            if (M2.a(this, M2.STORAGE, 4) == true) {
                v(getString(R.string.l14),getString(R.string.u10));
            }
        } else if ( a == 8 ) {
            if (M2.a(this, M2.STORAGE, 5) == true) {
                y(getString(R.string.l14), getString(R.string.u11) );
            }
        }

    }

    private void j(String a) {
        File file = new File(a);
        if ( file.exists() ) {
            file.delete();
        }
    }

    private void k(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               j(U4.a(W5.a13())+U4.a(W5.a16())+".db");
               a.dismiss();
 a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private static void l(String a) {
        File b = new File(a);
        if (b.exists()) {
            I2.a(b);
        }
    }

    private static void l(File b) {
        if (b.exists()) {
            I2.a(b);
        }
    }

    private void m(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               l(U4.a(W5.a20()));

               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void n(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               j(U4.a(W5.a13())+U4.a(W5.a14())+".db");
D1.getInstance(getApplicationContext());
if (A21.bl2 == true) {
A21.getInstance().c63();
}
               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void o(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               j(U4.a(W5.a13())+U4.a(W5.a15())+".db");
               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void q(String jk) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.l14));
        a.setMessage(jk);
        a.setPositiveButton(getString(R.string.u14), new C6() {
            public void a(DialogInterface a, int b) {
Intent intent = new Intent();
    
        intent.setAction(Settings .ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", U4.a(W5.a10()), null);
        intent.setData(uri);
startActivity(intent);
               a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void r(String a) {
        W1.c(this, a);
    }

    public void s(String a) {
        W1.b(this, a);
    }


    public void onRequestPermissionsResult(int a, String[] b, int[] c) {
        super.onRequestPermissionsResult(a, b, c);
        switch (a) {
            case 1:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) {  
                    a();
                } else {  
                     if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                       r(getString(R.string.u17));
                   } else {
                        q(getString(R.string.u18));
                   }
              }
              break;
            case 2:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) {  
a();
                    t(getString(R.string.l14),getString(R.string.u8));
                } else {  
                     if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                       r(getString(R.string.u15));
                   } else {
                        q(getString(R.string.u16));
                   }
              }
              break;
        case 3:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) {  
a();
                    u(getString(R.string.l14),getString(R.string.u9));
                } else {  
                     if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                       r(getString(R.string.u15));
                   } else {
                        q(getString(R.string.u16));
                   }
              }
              break;
        case 4:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) {  
a();
                      v(getString(R.string.l14),getString(R.string.u10));
                } else {  
                     if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                       r(getString(R.string.u15));
                   } else {
                        q(getString(R.string.u16));
                   }
              }
              break;
        case 5:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) {  
a();
                     y(getString(R.string.l14), getString(R.string.u11) );
                } else {  
                     if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                       r(getString(R.string.u15));
                   } else {
                        q(getString(R.string.u16));
                   }
              }
              break;
         }
    }

    private void t(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               l(I3.a() + "/WebView/Source Code/");
               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void u(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               l(I3.a() + "/WebView/Screenshot/");
               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void v(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
               l(I3.a() + "/WebView/Downloads/");
               a.dismiss();
a1();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void x(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {
                        

        SharedPreferences.Editor b5 = sp.edit(); 
        b5.clear(); 
        b5.apply(); 
l(U4.a(W5.a19())); 
               a.dismiss();
System.exit(0);

            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void y(String a1, String b1) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(a1);
        a.setMessage(b1);
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {

        SharedPreferences.Editor b5 = sp.edit(); 
        b5.clear(); 
        b5.apply();
           l(U4.a(W5.a20())); j(U4.a(W5.a13())+U4.a(W5.a14())+".db"); j(U4.a(W5.a13())+U4.a(W5.a15())+".db"); j(U4.a(W5.a13())+U4.a(W5.a16())+".db"); 
l(U4.a(W5.a19())); 
               l(I3.a() + "/WebView/");
if (A21.bl2 == true) {
A21.getInstance().c63();
}
               a.dismiss();
System.exit(0);
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void a1() {
a2();
        runOnUiThread(new Runnable() {
            public void run() {
                w19.a(a, b);
                w19.notifyDataSetChanged();
            }
        });
    }
    private void a2() {
a = Arrays.asList(getString(R.string.i13), getString(R.string.e10), getString(R.string.d12), getString(R.string.d14), getString(R.string.c35), getString(R.string.p11), getString(R.string.p12), getString(R.string.c36), getString(R.string.c37));
     b = Arrays.asList(getString(R.string.c38) + c(h(U4.a(W5.a13())+U4.a(W5.a16())+".db")) + " (" + g(U4.a(W5.a13())+U4.a(W5.a16())+".db") +"B) ", getString(R.string.c38) + c(e(U4.a(W5.a20()))) + " (" + e(U4.a(W5.a20())) + "B) ", getString(R.string.c38) + c(h(U4.a(W5.a13())+U4.a(W5.a14())+".db")) + " (" + g(U4.a(W5.a13())+U4.a(W5.a14())+".db") +"B) ", getString(R.string.c38) + c(h(U4.a(W5.a13())+U4.a(W5.a15())+".db")) + " (" + g(U4.a(W5.a13())+U4.a(W5.a15())+".db") +"B) ", getString(R.string.c38) + c(b(U4.a(W5.a19()))) + " (" + b(U4.a(W5.a19())) + "B) ", getString(R.string.c39) + d(I3.a() + "/WebView/Source Code/") + " Size: " + c(b(I3.a() + "/WebView/Source Code/")) + " (" + b(I3.a() + "/WebView/Source Code/") + "B) ", getString(R.string.c39) + d(I3.a() + "/WebView/Screenshot/") + " Size: " + c(b(I3.a() + "/WebView/Screenshot/")) + " (" + b(I3.a() + "/WebView/Screenshot/") + "B) ", getString(R.string.c39) + d(I3.a() + "/WebView/Downloads/") + " Size: " + c(b(I3.a() + "/WebView/Downloads/")) + " (" + b(I3.a() + "/WebView/Downloads/") + "B) ", "");

}


    public boolean onCreateOptionsMenu(Menu a) {
            getMenuInflater().inflate(R.menu.g, a);
        MenuItem b1 = a.findItem(R.id.l1);
        MenuItem b2 = a.findItem(R.id.l7);
        b1.setIcon(C5.a(this, R.drawable.b15)); 
        b2.setIcon(C5.a(this, R.drawable.e10));
        return super.onCreateOptionsMenu(a);
    }
 
    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.l1:
      a3();
                return true;
case R.id.l7:
      a4();
                return true;
  
            default:
                return super.onOptionsItemSelected(a);
         }
    }

private void a3() {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", getString(R.string.f33).replaceAll("%a", id.c).replaceAll("%b", W5.d()).replaceAll("%c", U4.a(W5.a4())).replaceAll("%d", U4.a(W5.a5())));
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+getString(R.string.p20)+"\"");
        startActivity(Intent.createChooser(b, d));
    }


     public void a4() {
final AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b18, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.f14));
        a.setView(c);
        final EditText ti = (EditText) c.findViewById(R.id.k16);
        final TextView ti2 = (TextView) c.findViewById(R.id.b15);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        ti2.setText(getString(R.string.f36));
        if (sp.getBoolean("autoUpdate", false) == false) {
            ti.setTextColor(e); ti2.setTextColor(e);
        } else {
            ti.setTextColor(f); ti2.setTextColor(f);
        }
        a.setPositiveButton(getString(R.string.w13), new C6() {
            public void a(DialogInterface a, int b) {
                a5(ti.getText().toString().replaceAll(" ", "+"));
                a.dismiss();
W1.b(A18.this, getString(R.string.g27));
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
              
                a.dismiss();
            }
        });


        final AlertDialog g = a.create();

ti.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton= g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ti.getText().toString().replaceAll(" ","");

     if (jhh.length() >= 30) {

                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
ti.setError(getString(R.string.g32).replaceAll("%a",Integer.toString(jhh.length())));


                }

            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
    }
public void a5(final String a) {
new Thread() {
public void run() {
U6.a(U4.a(W5.a2())+a);
}
}.start();

}
    public void a6(int vr) {
        AlertDialog.Builder c =  new AlertDialog.Builder(this);


        LayoutInflater d = getLayoutInflater();
        View e = d.inflate(R.layout.a12, null);
        c.setCancelable(false); 
        c.setView(e);
        TextView f = (TextView) e.findViewById(R.id.g1);
        f.setText(getString(R.string.o1));
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (vr == 1) {
                f.setTextColor(C5 .b(this,R.color.b));
            } else {
                f.setTextColor(C5.b(this,R.color.c));
            }
        } else{
            if (vr == 1) {
                f.setTextColor(C5.b(this,R.color.c));
            } else {
                f.setTextColor(C5.b(this,R.color.b));
            }
        }
        AlertDialog j5= c.create();

        CountDownTimer timer = new O5(2000, 2000, j5);
        timer.start();
                  j5.show();
    } 
}