package com.android.DROID_MJ.A;

 
// WebVew Lock

import android.widget.TextView;
import android.widget.ImageButton;
import android.app.Activity;


import android.content.SharedPreferences;
import android.os.Bundle;
import com.android.DROID_MJ.C.C5;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.webview.R;

import com.android.DROID_MJ.O.O1;
import android.widget.LinearLayout;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;

import android.view.View;   import com.android.DROID_MJ.C.C9;
import android.text.Editable;
 import com.android.DROID_MJ.T.T6;
import android.view.KeyEvent;
import android.content.pm.ActivityInfo;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.android.DROID_MJ.I.I3;

import java.io.File;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
 
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.C.C8;
import com.java.DROID_MJ.S.S1;

public class A28 extends Activity  {
    private static LinearLayout d12;
    private static TextView d13;
private static TextView i8;
     
        
    
    
  
    protected void onCreate(Bundle a) {
        final SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (b.getBoolean("autoUpdate", false) == false) {
           
                setTheme(R.style.a);
         
        } else {
        
                setTheme(R.style.g);
         
        }
        

O8.b();
super.onCreate(a);
if (b.getBoolean("webviewB", false) == true) {
        
setContentView(R.layout.a10);
} else {

setContentView(R.layout.b13);
}
try {
        
        
        
        
        LinearLayout i7 = (LinearLayout) findViewById(R.id.i7);
        d12 = (LinearLayout) findViewById(R.id.d12);
        d13 = (TextView) findViewById(R.id.d13);
         i8 = (TextView) findViewById(R.id.i8);
 
        ImageButton i9 = (ImageButton) findViewById(R.id.i9);
        TextView i10 = (TextView) findViewById(R.id.i10);
        TextView i11 = (TextView) findViewById(R.id.i11);
        TextView i12 = (TextView) findViewById(R.id.i12);
        TextView i13 = (TextView) findViewById(R.id.i13);
        TextView i14 = (TextView) findViewById(R.id.i14);
        TextView i15 = (TextView) findViewById(R.id.i15);
        TextView i16 = (TextView) findViewById(R.id.i16);
        TextView i17 = (TextView) findViewById(R.id.i17);
        TextView i18 = (TextView) findViewById(R.id.i18);
        TextView i19 = (TextView) findViewById(R.id.i19);
        TextView i20 = (TextView) findViewById(R.id.i20);
        ImageButton j1 = (ImageButton) findViewById(R.id.j1);
        i8.setText("");
        i9.setImageResource(R.drawable.b27);
        i10.setText(getString(R.string.m11));
        i11.setText(getString(R.string.m12));
        i12.setText(getString(R.string.m13));
        i13.setText(getString(R.string.m14));
        i14.setText(getString(R.string.m15));
        i15.setText(getString(R.string.m16));
        i16.setText(getString(R.string.m17));
        i17.setText(getString(R.string.m18));
        i18.setText(getString(R.string.m19));
        i19.setText("");
        i20.setText(getString(R.string.m20));
    final File fe = new File(I3.a() + "/WebView/.cache/"+"a.cache");
        j1.setImageResource(R.drawable.b28);
        Typeface tf = G1.a(this, 200);
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
 
        Typeface tf2 = G1.a(this, 100);
        i10.setTypeface(tf);
        i11.setTypeface(tf);
        i12.setTypeface(tf);
        i13.setTypeface(tf);
        i14.setTypeface(tf);
        i15.setTypeface(tf);
        i16.setTypeface(tf);
        i17.setTypeface(tf);
        i18.setTypeface(tf);
        i19.setTypeface(tf);
        i20.setTypeface(tf);
        i8.setTypeface(tf2);
       d13.setTypeface(tf2);
        int it = C5.b(this,R.color.b);
        i10.setTextColor(it);
        i11.setTextColor(it);
        i12.setTextColor(it);
        i13.setTextColor(it);
        i14.setTextColor(it);
        i15.setTextColor(it);
        i16.setTextColor(it);
        i17.setTextColor(it);
        i18.setTextColor(it);
        i19.setTextColor(it);
        i20.setTextColor(it);
        i8.setTextColor(it);
        d13.setTextColor(it);

    if (b.getBoolean("webviewB", false) == false) {
       if (b.getBoolean("autoUpdate", false) == false) {
                  i7.setBackgroundResource(R.color.b);
        } else {
         i7.setBackgroundResource(R.color.n);
        }

} else {
if (!fe.exists()) {
 if (b.getBoolean("autoUpdate", false) == false) {
                  i7.setBackgroundResource(R.color.b);
        } else {
         i7.setBackgroundResource(R.color.n);
        }
} else {
  i7.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache")));
}

}

//d12.setBackgroundResource(R.drawable.c3);
    i10.setBackgroundResource(R.drawable.c3);
        i9.setBackgroundResource(R.drawable.c3);
        j1.setBackgroundResource(R.drawable.c3);
        i11.setBackgroundResource(R.drawable.c3);
        i12.setBackgroundResource(R.drawable.c3);
        i13.setBackgroundResource(R.drawable.c3);
        i14.setBackgroundResource(R.drawable.c3);
        i15.setBackgroundResource(R.drawable.c3);
        i16.setBackgroundResource(R.drawable.c3);
        i17.setBackgroundResource(R.drawable.c3);
        i18.setBackgroundResource(R.drawable.c3);
       
        i20.setBackgroundResource(R.drawable.c3);
        i9.setOnClickListener(new C9() {
            public void a(View v) {
String b = i8.getText().toString();
String c = b.replaceAll(" ", "");
if (c.length() != 0) {
String a = b.substring(0, b.length() - 1);
i8.setText(a);
}
}
});
        i9.setOnLongClickListener(new C8() {
            public boolean  a(View v) {

i8.setText("");
return true;
}
});
        i10.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m11));

            }
        });
        i11.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m12));

            }
        });
        i12.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m13));

            }
        });
        i13.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m14));

            }
        });
        i14.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m15));

            }
        });
        i15.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m16));

            }
        });
        i16.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m17));

            }
        });
        i17.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m18));

            }
        });
        i18.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m19));

            }
        });
        i20.setOnClickListener(new C9() {
            public void a(View v) {
                i8.append(getString(R.string.m20));

            }
        });
        j1.setOnClickListener(new C9() {
            public void a(View v) {
                a1(i8.getText().toString());
            }
        });

        i8.addTextChangedListener(new T6() {
            private void a() {
                if (i8.getText().toString().length() >= 2) {
                    d13.setText("");
             
                }
            }
            public void c(Editable arg0) {
            }
            public void a(CharSequence s, int start, int count, int after) {
            }
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
       });

} catch (Exception ex) {
U1.a(ex);
}
}
protected void onResume() {
super.onResume();
if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();
}
}
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                                  
                    System.exit(0);
        return false;

            }

        }
        return false;
    }

     private void a1(String a) {
                  SharedPreferences b = getSharedPreferences("bhJmWwkvsbQJD" ,0);
         String c = b.getString("bhJmWwkvsbQJD","");
 
if (c.length() !=  0) {
         if (c.equals(S1.a("SHA-512",a))) {
finish();
         } else {
             d13.setText(getString(R.string.c40));
      i8.setText("");
Animation am76 = AnimationUtils.loadAnimation(this,R.anim.f);
        d12.startAnimation(am76);
O1.a(this, 100);
         }
} 
     }
}
