package com.android.DROID_MJ.A;

// PASTE SHORTCUT

import android.app.Activity;

import android.os.Bundle;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.A.A2;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.webview.R;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.W.W1;

public class A13 extends Activity  {
private static SharedPreferences sp;
    protected void onCreate(Bundle jk) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        

O8.b();
super.onCreate(jk);
        
        try {
            String c = C2.b(this);
            String e = c.replaceAll(" ", "");
            if (e.length() != 0) {
                C1.e(this, "value", c, A2.class);
            } else {
                a(getString(R.string.t20));
            }
             
        } catch (Exception ex) {
            U1.a(ex);
a(getString(R.string.t20));
        }
finish();
    }
protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}
    private void a(String a) {
W1.c(this, a);
    }
}