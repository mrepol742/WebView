package com.android.DROID_MJ.A;

// Wcome sceeens

import android.os.Bundle;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.app.Activity;

import android.view.View;   import com.android.DROID_MJ.C.C9;
import android.widget.TextView;
import android.widget.ImageView;

import android.view.KeyEvent;
import com.android.DROID_MJ.C.C5;
import android.os.Build; 
import android.widget.LinearLayout;
import android.content.Intent;
import android.text.method.LinkMovementMethod;
import android.text.SpannableStringBuilder;
import android.widget.TextView.BufferType;
import android.graphics.Color;
 
import android.text.style.ForegroundColorSpan;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Button;
import android.app.AlertDialog;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.content.Intent.ShortcutIconResource;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.T.T5;
import com.android.DROID_MJ.C.C11;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.C.C13;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.W.W6;
import com.android.DROID_MJ.W.W24;
import com.android.DROID_MJ.W.W32;
import com.android.DROID_MJ.W.W1;


public class A17 extends Activity  {
    private static ImageView a;
    private static TextView b;
    private static TextView c;
    private static Button d;
    private static LinearLayout b20;
    private static SharedPreferences sp;

    protected void onCreate(Bundle be) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
        O8.b();
        super.onCreate(be);
        setContentView(R.layout.p);  
        a = (ImageView) findViewById(R.id.c6);
        b = (TextView) findViewById(R.id.c7);
        c = (TextView) findViewById(R.id.c8);
        d = (Button) findViewById(R.id.c9);
        b20 = (LinearLayout) findViewById(R.id.b20);
        //a.setImageResource(R.mipmap.c);
        b.setText(getString(R.string.p20));
        d.setText(getString(R.string.i14));
        int e = C5.b(this,R.color.i);
        int f = C5.b(this,R.color.b);
        int f1 = C5.b(this,R.color.n);
        int g = C5.b(this,R.color.d);
        if (sp.getBoolean("autoUpdate", false) == false) {
            b.setTextColor(e);
            d.setTextColor(f);
            c.setTextColor(g);
        } else {
            b.setTextColor(f);
            d.setTextColor(f);
            c.setTextColor(f);
        }

b20.setBackgroundResource(R.drawable.s);
b20.setElevation(10);
        /*W24 w24 = (W24) findViewById(R.id.c6);
w24.a(this, R.raw.b);*/
        SpannableStringBuilder spanTxt = new SpannableStringBuilder(getString(R.string.i15));
       spanTxt.append(" "); spanTxt.append(getString(R.string.f12));
        spanTxt.setSpan(new T5() {
            public void a(View widget) {
                l1(U4.a(W5.u()));

            }
        }, spanTxt.length() - getString(R.string.f12).length(), spanTxt.length(), 0);
        spanTxt.append(getString(R.string.i16));
        if (sp.getBoolean("autoUpdate", false) == false) {
            spanTxt.setSpan(new ForegroundColorSpan(C5.b(this,R.color.c)), 32, spanTxt.length(), 0); 
        } else {
            spanTxt.setSpan(new ForegroundColorSpan(C5.b(this,R.color.b)), 32, spanTxt.length(), 0); 
        }
        spanTxt.append(" ");
        spanTxt.append(getString(R.string.f13));
        spanTxt.setSpan(new T5() {
            public void a(View widget) {
                l1(U4.a(W5.v()));

            }
        }, spanTxt.length() - getString(R.string.f13).length(), spanTxt.length(), 0);
        spanTxt.append(".");
        c.setMovementMethod(LinkMovementMethod.getInstance());
        c.setText(spanTxt, BufferType.SPANNABLE);

        Typeface k = G1.a(this, 200);
        Typeface k78 = G1.a(this, 100);
        c.setTypeface(k78);
        d.setTypeface(k);
        b.setTypeface(k);
        d.setBackgroundResource(R.drawable.a5);
        d.setOnClickListener(new C9() {
            public void a(View v) {
        l4();

            }
        });
       

    }

    public void l1(String b) {
        Intent a = new Intent(getApplicationContext(), A6.class);
        a.putExtra("value", b);
        startActivity(a);
    }

    protected void onResume() {
        super.onResume();
        if (sp.getBoolean("qwe73", false) == true) {
            System.gc();
        }
    }

    private void l3() {
        SharedPreferences a5 = getSharedPreferences("wlcmscnn", 0);   
        SharedPreferences.Editor b5 = a5.edit(); 
        b5.putInt("wlcmscnn", 275);
        b5.apply();
        finish();
    }

    private void l4() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.p20));
        a.setMessage(getString(R.string.i17));
        a.setPositiveButton(getString(R.string.z11), new C6() {
            public void a(DialogInterface a, int b) { 
                l3();
l6();
l7();
                }
           });
           a.setNegativeButton(getString(R.string.c34), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
l3();
l7();
            }
        });
a.setOnDismissListener(new C13() {
        public void a(final DialogInterface arg0) {
                    l3();
                    l7();
        }
    });
        a.create().show();
    } 


     private void l7() {
         new Thread() {
             public void run() {
                 W32.d();
         }
         }.start();
     }
    private void l6() {
try {
        Intent e = new Intent("com.android.DROID_MJ.webview.intent.action.LAUNCH"); 
        e.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        e.putExtra("duplicate", false);
        Intent f = new Intent();
        f.putExtra("android.intent.extra.shortcut.INTENT", e); 
        f.putExtra("android.intent.extra.shortcut.NAME", getString(R.string.p20));
        f.putExtra("android.intent.extra.shortcut.ICON_RESOURCE",
ShortcutIconResource.fromContext(this, R.mipmap.c));
        f.putExtra("duplicate", false);
        f.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        sendBroadcast(f);
        C11.a(this, "com.android.DROID_MJ.webview.intent.action.MASTER_INSTALL_SHORTCUT");
} catch (Exception et) { W1.e(this, getString(R.string.a36),2); U1.a(et); }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    W6.a();
                  return true;
            }
        }
        return false;
    }
}