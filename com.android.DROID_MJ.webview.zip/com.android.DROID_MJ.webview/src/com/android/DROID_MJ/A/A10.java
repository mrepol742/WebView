package com.android.DROID_MJ.A;

// SETTINGS LAUNCHER

import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View; 
 import com.android.DROID_MJ.C.C9;
import com.android.DROID_MJ.C.C5;
import android.widget.Toolbar;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.webview.R;
import android.app.Activity;

import android.widget.TextView;
import com.android.DROID_MJ.P.P1;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import android.view.KeyEvent;
import android.content.Intent;

import java.io.InputStream;
import java.io.OutputStream;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import java.io.File;
import java.io.FileOutputStream;
import android.net.Uri;
import com.android.DROID_MJ.U.U4;
import android.provider.Settings;
import com.android.DROID_MJ.P.P3;
import android.media.AudioManager;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.widget.SeekBar;
import com.android.DROID_MJ.I.I3;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.BitmapFactory;
import com.android.DROID_MJ.P.P4;
import com.android.DROID_MJ.P.P5;
import com.android.DROID_MJ.P.P15;
import android.content.Context;
import com.android.DROID_MJ.P.P6;
import android.os.CountDownTimer;
import com.android.DROID_MJ.O.O5;
import com.android.DROID_MJ.P.P7;
import com.android.DROID_MJ.P.P8;
import com.android.DROID_MJ.P.P9;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.P.P10;
import com.android.DROID_MJ.P.P2;
import com.android.DROID_MJ.P.P11;
import com.android.DROID_MJ.P.P12;
import com.android.DROID_MJ.I.I2;
import com.android.DROID_MJ.C.C13;
import com.android.DROID_MJ.C.C2;
import android.widget.RadioGroup;
import com.android.DROID_MJ.W.W31;
import android.content.ComponentName;
import com.android.DROID_MJ.C.C10;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.O.O8;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import com.android.DROID_MJ.W.W5;
import java.io.InputStreamReader;
import android.app.admin.DevicePolicyManager;
import com.android.DROID_MJ.R.R20;
import android.text.Editable;
import android.widget.EditText;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.T.T6;
 import android.widget.Button;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
 import com.android.DROID_MJ.W.W25;
import android.view.MenuItem;
import android.view.Menu;
import com.id;
import com.android.DROID_MJ.M.M2;
import android.webkit.CookieManager;
import android.webkit.WebViewDatabase;
import android.webkit.WebStorage;


public class A10 extends Activity  {
      public static TextView h18;
      public static A10 A10;
private static ComponentName cn;
   private static SharedPreferences sp;
        private static CookieManager cm;
private static WebViewDatabase wd;
private static WebStorage ws;
    private static Executor er = Executors.newCachedThreadPool();
    
      public static A10 getInstance() {
           return A10;
      }

      protected void onCreate(Bundle a) {
          sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
          

O8.b();
super.onCreate(a);
          
setContentView(R.layout.a9);
          A10 = this;
          Toolbar h17 = (Toolbar) findViewById(R.id.c3);
          h18 = (TextView) findViewById(R.id.c4);
          TextView k8 = (TextView) findViewById(R.id.c5);
          
                 ws = WebStorage.getInstance();
       cm = CookieManager.getInstance();
        wd = WebViewDatabase.getInstance(getApplicationContext());
         h18.setTypeface(G1.a(this, 200));
          k8.setTypeface(G1.a(this, 200));
          setActionBar(h17);
          h17.setElevation(10);
          cn = new ComponentName(getApplicationContext(), R20.class); h18.setText(getString(R.string.l10));
          k8.setText(getString(R.string.l13));
       
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);

        if (sp.getBoolean("autoUpdate", false) == false) {
            h18.setTextColor(C5.b(this,R.color.c));
           k8.setTextColor(C5.b(this,R.color.c));
        } else {
            h18.setTextColor(C5.b(this,R.color.b));
            k8.setTextColor(C5.b(this,R.color.b));
        }
            h17.setBackgroundResource(R.drawable.p);
            h17.setNavigationIcon(R.drawable.a2);
        h17.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        });
        onNewIntent(getIntent());
        SharedPreferences prefs = getSharedPreferences("webDa",0);
        boolean d78 = prefs.getBoolean("webDa", false);
        if (d78 == true) {
            k8.setVisibility(View.VISIBLE);
        } else {
            k8.setVisibility(View.GONE);
        }
    }

protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}

    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            finish();
            return true;
        }
        return super.onKeyUp(a, b);
    }

    public boolean onKeyLongPress(int a, KeyEvent b) {
        if (a == 4 && !b.isCanceled()) {
            finish();
        }
        return false;
    }

    protected void onNewIntent(Intent a) {
        try {
            String val = a.getStringExtra("search");
            if (val == null) {
                  finish();
            }
          
            if (val.equals("a")) {
 getFragmentManager().beginTransaction().replace(R.id.i6, new P1()).commit();
            } else if (val.equals("b")) {
            // general
getFragmentManager().beginTransaction().replace(R.id.i6, new P3()).commit();
            } else if (val.equals("c")) {
            // vidoes
getFragmentManager().beginTransaction().replace(R.id.i6, new P4()).commit();
            } else if (val.equals("d")) {
            // search
getFragmentManager().beginTransaction().replace(R.id.i6, new P5()).commit();
            } else if (val.equals("e")) {
            // download
getFragmentManager().beginTransaction().replace(R.id.i6, new P6()).commit();
            } else if (val.equals("f")) {
            // interface
getFragmentManager().beginTransaction().replace(R.id.i6, new P7()).commit();
            } else if (val.equals("g")) {
            // privacy

getFragmentManager().beginTransaction().replace(R.id.i6, new P8()).commit();

            } else if (val.equals("h")) {
            // advanced
getFragmentManager().beginTransaction().replace(R.id.i6, new P9()).commit();
            } else if (val.equals("i")) {
            // advanced
getFragmentManager().beginTransaction().replace(R.id.i6, new P10()).commit();
            } else if (val.equals("j")) {
            // advanced
getFragmentManager().beginTransaction().replace(R.id.i6, new P2()).commit();
            } else if (val.equals("k")) {
            // advanced
getFragmentManager().beginTransaction().replace(R.id.i6, new P11()).commit();
            } else if (val.equals("l")) {
            // advanced

getFragmentManager().beginTransaction().replace(R.id.i6, new P12()).commit();

            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    private void a(String jk) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.h10));
        a.setMessage(jk);
        a.setPositiveButton(getString(R.string.u14), new C6() {
            public void a(DialogInterface a, int b) {
Intent intent = new Intent();
    
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", U4.a(W5.a10()), null);
        intent.setData(uri);
startActivity(intent);
               a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void d(String a) {
        W1.c(this, a);
    }

    public void e() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.h10));
        a.setMessage(getString(R.string.u8)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                h(I3.a() + "/WebView/Source Code/");
                g(getString(R.string.q1));
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void f() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.h10));
        a.setMessage(getString(R.string.u9)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                h(I3.a() + "/WebView/Screenshot/");
                g(getString(R.string.l16));

            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void g(String a) {
        W1.b(this, a);
    }

    public static void h(String a) {
        try {
            File b = new File(a); 
            if (b.isDirectory()) {
                String[] c = b.list();
                for (int d = 0; d < c.length; d++) {
                     new File(b, c[d]).delete();
                }
            }
        } catch (Exception ex) {
           U1.a(ex);
        }
    }


    public void i() {
        if (M2.a(this, M2.STORAGE, 1) == true) {
            e();
        }
    }

    public void j() {
        if (M2.a(this, M2.STORAGE, 2) == true) {
            f();
        }
    }

    public void k() {
        Intent i = new Intent(Settings.ACTION_CAPTIONING_SETTINGS);
        if (i != null) {
            startActivity(i);
        }
    }

    public void l() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(this);


        LayoutInflater a6 = getLayoutInflater();
        View a7 = a6.inflate(R.layout.m, null);
        a5.setCancelable(true); 
        a5.setView(a7);
        final SeekBar b10 = (SeekBar) a7.findViewById(R.id.c2);
        b10.setThumb(new BitmapDrawable(getResources(), BitmapFactory.decodeResource(getResources(),R.drawable.c16)));

        SharedPreferences a77 =  getSharedPreferences("brightness", 0);
        int c7 = a77.getInt("brightness", 0);
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        if (c7 == 0) {
            b10.setProgress(20);
            layoutParams.screenBrightness = (float)20/100;
        } else {
            b10.setProgress(c7);
            layoutParams.screenBrightness = (float)c7/100;
        }
        getWindow().setAttributes(layoutParams);
        a5.setOnDismissListener(new C13() {
        public void a(final DialogInterface arg0) {
                   SharedPreferences a5 = A10.this.getSharedPreferences("brightness", 0);   
               SharedPreferences.Editor b5 = a5.edit();
               b5.putInt("brightness", b10.getProgress());
               b5.apply();
        }
    });
        b10.setOnSeekBarChangeListener(new W25() {        
            public void a(SeekBar seekBar, int progress, boolean fromUser) {
 
               float gh = (float)progress/100;            
               WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
               layoutParams.screenBrightness = gh;
               getWindow().setAttributes(layoutParams);
            }
       
            public void b(SeekBar seekBar) {

            }
     
            public void c(SeekBar seekBar) {

 
            }
        });
        a5.create().show();
    }

    public void m() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(this);


        LayoutInflater a6 = getLayoutInflater();
        View a7 = a6.inflate(R.layout.m, null);
        a5.setCancelable(true); 
        a5.setView(a7);

        final SeekBar c2 = (SeekBar) a7.findViewById(R.id.c2);
        final AudioManager mAudio = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        SharedPreferences a76 =  getSharedPreferences("volume", 0);    
        int c72 = a76.getInt("volume", 0);
        if (c72 == 0) {
            c2.setProgress(10);
        } else {
            c2.setProgress(c72);
        }
          
c2.setThumb(new BitmapDrawable(getResources(), C5.c(this, R.drawable.a6)));
        c2.setMax(mAudio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        a5.setOnDismissListener(new C13 
() {
        public void a(final DialogInterface arg0) {
SharedPreferences a5 = A10.this.getSharedPreferences("volume", 0);   
                 SharedPreferences.Editor b5 = a5.edit(); 
                 b5.putInt("volume", c2.getProgress());
                 b5.apply();
}
});
        c2.setOnSeekBarChangeListener(new W25() {
            public void a(SeekBar bar, int progress, boolean fromUser) {
                 mAudio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, AudioManager.FLAG_PLAY_SOUND);
                 
            }
            public void b(SeekBar bar) {
        
            }
            public void c(SeekBar bar) {
            }
        });
        a5.create().show();
    }

    public void n() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b3));
        a.setMessage(getString(R.string.u13)); 
        a.setPositiveButton(getString(R.string.i18), new C6() {
            public void a(DialogInterface a, int b) { 
                o();
            } 
   	     });
        a.setNeutralButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    }

    public void o() {
        Intent a = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS); 
        a.setData(Uri.parse("package:" + U4.a(W5.a10())));
        if (a != null) {
            startActivity(a);
        }
    }

    public void p() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.f));
        a.setMessage(getString(R.string.u12)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                q();
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    public void q() {
       Intent a = new Intent();
            a.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
         if (a != null) {
                startActivity(a);
                W1.d(this, getString(R.string.a25));
            }

    }

    public void r() {
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
        d.setType("image/*");
        d.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 79);
    }

    public void s() {
        if (M2.a(this, M2.STORAGE, 3) == true) {
            r();
        }
    }

    public void t(int vr) {
        AlertDialog.Builder c =  new AlertDialog.Builder(this);


        LayoutInflater d = getLayoutInflater();
        View e = d.inflate(R.layout.a12, null);
        c.setCancelable(false); 
        c.setView(e);
        TextView f = (TextView) e.findViewById(R.id.g1);
        f.setText(getString(R.string.o1));
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (vr == 1) {
                f.setTextColor(C5.b(this,R.color.b));
            } else {
                f.setTextColor(C5.b(this,R.color.c));
            }
        } else{
            if (vr == 1) {
                f.setTextColor(C5.b(this,R.color.c));
            } else {
                f.setTextColor(C5.b(this,R.color.b));
            }
        }
        AlertDialog j5= c.create();

        CountDownTimer timer = new O5(2000, 2000, j5);
        timer.start();

        j5.show();
    } 

    public void u() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.u5)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) {               a5(getApplicationContext().getCacheDir());
                g(getString(R.string.a27));
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    public void v() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.t5)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                File fl = new File(U4.a(W5.a13())+U4.a(W5.a14())+".db");
                if (fl.exists()) {
                    fl.delete();
if (A21.bl2 == true) {
A21.getInstance().c63();
}
                    g(getString(R.string.t1));
                }
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void w(final int i) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.b));
if (i == 0) {
        a.setMessage(getString(R.string.a28));
} else {
a.setMessage(getString(R.string.x13));
}
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
if (i == 0) {
              cm.removeAllCookies(null); g(getString(R.string.a29));
} else {
cm.removeSessionCookies(null); g(getString(R.string.h28));
}
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void x() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.a31));
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
             wd.clearFormData();
  g(getString(R.string.a32));

        
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void y() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage("THIS FEATURE IS NOT AVAILABLE"); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                // locato"n
               // g("Location Cleared.");
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 



    public void a1() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.u4)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                File fl = new File(U4.a(W5.a13())+U4.a(W5.a15())+".db");
                if (fl.exists()) {
                    fl.delete();
                    g(getString(R.string.u3));
                }
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void a2() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.a37));
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
 if (A21.bl2 == true) {
A21.getInstance().c31();
              g(getString(R.string.a38));
} else {
  d(getString(R.string.a39));
}
  
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    public void a3() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.u6)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
File fl = new File(U4.a(W5.a13())+U4.a(W5.a16())+".db");

if (fl.exists()) {
fl.delete();
                g(getString(R.string.a40));
}
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int which) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 
 
    public void a4() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.b21)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 

wd.clearHttpAuthUsernamePassword();
                g(getString(R.string.b22));
 
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    }

    public static boolean a5(File a) {
        if (a != null && a.isDirectory()) {
            String[] children = a.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = a5(new File(a, children[i]));
                if (!success) {
                    return false;
                }
            }
            return a.delete();
        } else if (a!= null &&a.isFile()) {
            return a.delete();
        } else {
            return false;
        }
    }

    public void a6() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.b24));
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                a7();
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 

    public void a7() {
        SharedPreferences.Editor b = sp.edit(); 
        b.clear(); 
        b.apply();
        t(0);   
    }

    public void a8() {
        
finish();
        Intent it = new Intent(this, A21.class);
         if (A21.bl2 == true && A21.h != null && A21.h.getUrl() != null) {
                 it.putExtra("value", A21.h.getUrl());
            }
        it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(it);
    }

    public void a9(String a) {
        Intent b = new Intent("com.android.DROID_MJ.webview.intent.action.VIEW");
b.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        if (a != null) {
            b.setData(Uri.parse(a));
                startActivity(b);
         
        }
    }

    public void a10() {
        Intent a = new Intent(Intent.ACTION_SENDTO, Uri.parse(U4.a("bWFpbHRvOm1yZXBvbDc0MkBnbWFpbC5jb20=")));
        a.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.p20));
        a.putExtra(Intent.EXTRA_TEXT, "");
        File fe = new File(I3.a() + "/WebView/.log/webview.log");
        if (fe.exists()) {
            a.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" +I3.a() +"/WebView/.log/webview.log"));
        }
        startActivity(Intent.createChooser(a, getString(R.string.a26)));
    }

    public void a11(String b) {
Intent a = new Intent(this, A6.class);
a.putExtra("value", b);
        startActivity(a);
    }

    public void a12() {
        boolean bn = I2.a(U4.a(W5.a12()), I3.a() +"/WebView/Backup/webview.settings", 5);
        if (bn == true) {
            g(getString(R.string.b25));
        } else {
            d(getString(R.string.b26));
        }
    }

    public void a13() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.b38).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.b29), new C6() {
            public void a(DialogInterface a, int b) {
                a12();
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void a14() {   
        boolean bn = I2.a(I3.a() +"/WebView/Backup/webview.settings", U4.a(W5.a12()), 20);
        if (bn == true) {
            if (sp.getBoolean("ptm", false) == true) {
C10.a(this, "com.android.DROID_MJ.a14", 2);
C10.a(this,"com.android.DROID_MJ.d", 1);
            }
        SharedPreferences.Editor se = sp.edit();
        se.putBoolean("ptm", false);
        se.commit();
        SharedPreferences.Editor se5 = sp.edit();
        se5.putBoolean("lockWn99", false);
        se5.commit();
SharedPreferences a= getSharedPreferences("bhJmWwkvsbQJD", 0);
          a.edit().putString("bhJmWwkvsbQJD", ""). apply();
        SharedPreferences a5= getSharedPreferences("gsJsGsKSIgPes", 0);
a5.edit().putString("gsJsGsKSIgPes", ""). apply();

            g(getString(R.string.b27));
            t(0);   
        } else {
            d(getString(R.string.b28));
        }
    }

    public void a15() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.b39).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.b30), new C6() {
            public void a(DialogInterface a, int b) {
                a14(); 
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void a16() {
        boolean bn = I2.a(U4.a(W5.a13())+U4.a(W5.a15())+".db", I3.a() +"/WebView/Backup/webview.search", 5);
        if (bn == true) {
            g(getString(R.string.b25));
        } else {
            d(getString(R.string.b26));
        }
    }

    public void a17() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.b40).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q14), new C6() {
            public void a(DialogInterface a, int b) {
                a16();
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void a18() {   
        boolean bn = I2.a(I3.a() +"/WebView/Backup/webview.search", U4.a(W5.a13())+U4.a(W5.a15())+".db",20);
        if (bn == true) {
            g(getString(R.string.b27));
 
        } else {
            d(getString(R.string.b28));
        } 
    }

    public void a19() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
       a.setMessage(getString(R.string.c21).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q15), new C6() {
            public void a(DialogInterface a, int b) {
                a18(); 
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }
    
    public void a20() {
        boolean bn = I2.a(U4.a(W5.a13())+U4.a(W5.a14())+".db", I3.a() +"/WebView/Backup/webview.history", 5);
        if (bn == true) {
            g(getString(R.string.b25));
        } else {
            d(getString(R.string.b26));
        }
    }

    public void b1() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.c22).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q14), new C6() {
            public void a(DialogInterface a, int b) {
                a20();
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void b2() {   
        boolean bn = I2.a(I3.a() +"/WebView/Backup/webview.history", U4.a(W5.a13())+U4.a(W5.a14())+".db", 20);
        if (bn == true) {
            g(getString(R.string.b27));
 
        } else {
            d(getString(R.string.b28));
        }
    }

    public void b3() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.c23).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q15), new C6() {
            public void a(DialogInterface a, int b) {
                b2(); 
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

         try {
if (requestCode == 79 && data != null) {

             InputStream c = getContentResolver().openInputStream(data.getData());
             OutputStream d = new FileOutputStream(I3.a() +"/WebView/.cache/a.cache");
             byte[] e = new byte[1024];
             int f;
             while((f = c.read(e)) != -1) {
                 d.write(e, 0, f);
             }
             c.close();
             c = null;
             d.flush();
             d.close();
             d = null;
    t(0);
} else if (requestCode == 1234 && data != null) {
InputStream c5 = getContentResolver().openInputStream(data.getData());
             OutputStream d5 = new FileOutputStream(I3.a() +"/WebView/.cache/c.cache");
             byte[] e5 = new byte[1024];
             int f5;
             while((f5 = c5.read(e5)) != -1) {
                 d5.write(e5, 0, f5);
             }
             c5.close();
             c5 = null;
             d5.flush();
             d5.close();
             d5 = null;
    t(0);
} else if (requestCode == 12345 && data != null) {
InputStream c5 = getContentResolver().openInputStream(data.getData());
             OutputStream d5 = new FileOutputStream(I3.a() +"/WebView/.cache/d.cache");
             byte[] e5 = new byte[1024];
             int f5;
             while((f5 = c5.read(e5)) != -1) {
                 d5.write(e5, 0, f5);
             }
             c5.close();
             c5 = null;
             d5.flush();
             d5.close();
             d5 = null;
    t(0);
}else if (requestCode == 7423 && data != null) {
InputStream c5 = getContentResolver().openInputStream(data.getData());
             OutputStream d5 = new FileOutputStream(I3.a() +"/WebView/.cache/e.cache");
             byte[] e5 = new byte[1024];
             int f5;
             while((f5 = c5.read(e5)) != -1) {
                 d5.write(e5, 0, f5);
             }
             c5.close();
             c5 = null;
             d5.flush();
             d5.close();
             d5 = null;
W1.b(this, getString(R.string.h21));
}
         
         } catch (Exception ex) {
             U1.a(ex);
         }
    }

    public void b4() {
        boolean bn = I2.a(U4.a(W5.a13())+U4.a(W5.a16())+".db", I3.a() +"/WebView/Backup/webview.bookmarks" ,5);
        if (bn == true) {
            g(getString(R.string.b25));
        } else {
            d(getString(R.string.b26));
        }
    }

    public void b5() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.c24).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q14), new C6() {
            public void a(DialogInterface a, int b) {
                b4();
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void b6() {   
        boolean bn = I2.a(I3.a() +"/WebView/Backup/webview.bookmarks", U4.a(W5.a13())+U4.a(W5.a16())+".db", 20);
        if (bn == true) {
            g(getString(R.string.b27));
 
        } else {
            d(getString(R.string.b28));
        }
    }

    public void b7() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.t6));
        a.setMessage(getString(R.string.c25).replaceAll("%a", I3.a()));
        a.setPositiveButton(getString(R.string.q15), new C6() {
            public void a(DialogInterface a, int b) {
                b6(); 
                a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void b8() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.b));
        a.setMessage(getString(R.string.b36)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                C2.a(A10.this, "");
g(getString(R.string.b37));
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 
    
     public void b9() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(this);


View c = null;
        a5.setCancelable(true); 
 
           c = getLayoutInflater().inflate(R.layout.s, null);
 a5.setView(c);
 
        
        a5.setTitle(getString(R.string.b35));
        RadioGroup rg = (RadioGroup) c.findViewById(R.id.g11);
      
// 1 enabled
// 2 disabled
rg.setOnCheckedChangeListener(new W31() {
            public void a(RadioGroup rg, int i) {

                switch (i) {

                    case R.id.g12:
b10("com.android.DROID_MJ.b", 1);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g13:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 1);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g14:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 1);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g15:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 1);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g16:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 1);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g17:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 1);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g18:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 1);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.g19:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 1);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
                    case R.id.h4:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 1);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
                    break;
case R.id.j12:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 1);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j13:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 1);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j14:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 1);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j15:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 1);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j16:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 1);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j17:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 1);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j18:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 1);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j19:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 1);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.j20:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 1);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.k1:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);  
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 1);
 b10("com.android.DROID_MJ.a9", 2);
g(getString(R.string.b31));
break;
case R.id.k2:
b10("com.android.DROID_MJ.b", 2);
b10("com.android.DROID_MJ.c", 2);
b10("com.android.DROID_MJ.d", 2);
b10("com.android.DROID_MJ.e", 2);
b10("com.android.DROID_MJ.f", 2);
b10("com.android.DROID_MJ.g", 2);
b10("com.android.DROID_MJ.s", 2);
b10("com.android.DROID_MJ.t", 2);
 b10("com.android.DROID_MJ.w", 2);
b10("com.android.DROID_MJ.y", 2);
b10("com.android.DROID_MJ.z", 2);
b10("com.android.DROID_MJ.a1", 2);
 b10("com.android.DROID_MJ.a2", 2);
 b10("com.android.DROID_MJ.a3", 2);
 b10("com.android.DROID_MJ.a4", 2);
 b10("com.android.DROID_MJ.a5", 2);
 b10("com.android.DROID_MJ.a6", 2);
 b10("com.android.DROID_MJ.a7", 2);
 b10("com.android.DROID_MJ.a8", 2);
 b10("com.android.DROID_MJ.a9", 1);
g(getString(R.string.b31));
break;
                }
            }
        });
       a5.create().show();
     }
public void b10(String a, int b) {

if (sp.getBoolean("ptm", false) == true) {
d(getString(R.string.b15));
} else {
 C10.a(this, a, b);
}
}
     public void b11(String a5,   int b5) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.n12));
        a.setMessage(a5); 
         if (b5 == 2) {
 a.setPositiveButton(getString(R.string.b32), new C6() {
            public void a(DialogInterface a, int b) { 
    b13(A10.this);
a.dismiss();
            } 
   	     });
        a.setNeutralButton(getString(R.string.i5), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
} else {
a.setNeutralButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
}
        a.create().show();
    } 

    public void b12() {
        O8.a();
        int b = W5.e();
        try {
            URL u = new URL(U4.a(W5.m()));
            BufferedReader c =  new BufferedReader(new InputStreamReader(u.openStream()));   
            int newUpdate= 0 ;
            String f = new String();
            while ( (f =c.readLine()) != null){
                newUpdate = Integer.parseInt(f);
            } 
            if (newUpdate > b) {
               b11(getString(R.string.x12), 2);
U1.a("Update is available");
            } else {
b11(getString(R.string.b34), 742);
            }
} catch (MalformedURLException mu) {
 
        } catch (IOException io) {
              
        }
    }

public void b13(Context a56) {
finish();
try {
O8.a();
URL u5 = new URL(U4.a(W5.r()));
            BufferedReader c5 =  new BufferedReader(new InputStreamReader(u5.openStream()));   
           String gh = "";
            String f5 = new String();
            while ( (f5 =c5.readLine()) != null){
                gh = f5;
            } 
        Intent j = new Intent(this, A21.class);
        j.putExtra("value", gh);
startActivity(j);


} catch (MalformedURLException mu) {
 
        } catch (IOException io) {
              
        }
}
    public void b14() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.z18));
        a.setMessage(getString(R.string.a21)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
                b15();
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    public void b15() {
    
            Intent a = new Intent();
            a.setAction("android.settings.VOICE_INPUT_SETTINGS");
            if (a != null) {
                startActivity(a);
                W1.d(this, getString(R.string.b33));
            }
        
    }

 public void b16() {
Intent i = new Intent(DevicePolicyManager .ACTION_ADD_DEVICE_ADMIN);
                   i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,cn);
                i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "");
             
                startActivityForResult(i,5);
}

     public void b17() {
final AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b18, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.f14));
        a.setView(c);
        final EditText ti = (EditText) c.findViewById(R.id.k16);
        final TextView ti2 = (TextView) c.findViewById(R.id.b15);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        ti2.setText(getString(R.string.f36));
        if (sp.getBoolean("autoUpdate", false) == false) {
            ti.setTextColor(e); ti2.setTextColor(e);
        } else {
            ti.setTextColor(f); ti2.setTextColor(f);
        }
        a.setPositiveButton(getString(R.string.w13), new C6() {
            public void a(DialogInterface a, int b) {
                b18(ti.getText().toString().replaceAll(" ", "+"));
                a.dismiss();
W1.b(A10.this, getString(R.string.g27));
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
              
                a.dismiss();
            }
        });


        final AlertDialog g = a.create();

ti.addTextChangedListener(new T6() {
            private void a() {
                final Button okButton= g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ti.getText().toString().replaceAll(" ","");

     if (jhh.length() >= 30) {

                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
ti.setError(getString(R.string.g32).replaceAll("%a",Integer.toString(jhh.length())));


                }

            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
    }
public void b18(final String a) {
P15 p = new P15() {
public void a() {

U6.a(U4.a(W5.a2())+a);
}
};
er.execute(new Thread(p));

}
    public void b19() {
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
        d.setType("*/*");
        if (Build.VERSION.SDK_INT >= 21) {
            d.addCategory(Intent.CATEGORY_OPENABLE);
        }
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 1234);
    }

    public void b20() {
        if (M2.a(this, M2.STORAGE, 4) == true) {
            b19();
        }
    }

    public void b21() {
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
        d.setType("*/*");
        if (Build.VERSION.SDK_INT >= 21) {
            d.addCategory(Intent.CATEGORY_OPENABLE);
        }
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 12345);
    }

    public void b22() {
        if (M2.a(this, M2.STORAGE, 6) == true) {
            b21();
        }
    }
    public void onRequestPermissionsResult(int a, String[] b, int[] c) {
        super.onRequestPermissionsResult(a, b, c);
        switch (a) {
            case 1:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    e();
                } else {  
                    if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u15));
                    } else {
                        a(getString(R.string.u16));
                    }                 
                }
            break;
            case 2:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    f();
                } else {  
                    if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u15));
                    } else {
                        a(getString(R.string.u16));
                    }                
                }
            break;
            case 3:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    r();
                } else {  
                    if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u17));
                    } else {
                        a(getString(R.string.u18));
                    }                
                }
            break;
case 4:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    b20();
                } else {  
                    if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u17));
                    } else {
                        a(getString(R.string.u18));
                    }                
                }
            break;


case 6:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    b21();
                } else {  
                    if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u17));
                    } else {
                        a(getString(R.string.u18));
                    }                
                }
            break;
case 7:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    b25();
                } else {  
                    if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        d(getString(R.string.u17));
                    } else {
                        a(getString(R.string.u18));
                    }                
                }
            break;
        }
    }

    public boolean onCreateOptionsMenu(Menu a) {
            getMenuInflater().inflate(R.menu.g, a);
        MenuItem b1 = a.findItem(R.id.l1);
        MenuItem b2 = a.findItem(R.id.l7);
        b1.setIcon(C5.a(this, R.drawable.b15)); 
        b2.setIcon(C5.a(this, R.drawable.e10));
        return super.onCreateOptionsMenu(a);
    }
 
    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.l1:
      b23();
                return true;
case R.id.l7:
      b17();
                return true;
  
            default:
                return super.onOptionsItemSelected(a);
         }
    }

private void b23() {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", getString(R.string.f33).replaceAll("%a", id.c).replaceAll("%b", W5.d()).replaceAll("%c", U4.a(W5.a4())).replaceAll("%d", U4.a(W5.a5())));
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+getString(R.string.p20)+"\"");
        startActivity(Intent.createChooser(b, d));
    }

    public void b24() {
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
        d.setType("image/*");
        if (Build.VERSION.SDK_INT >= 21) {
            d.addCategory(Intent.CATEGORY_OPENABLE);
        }
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 7423);
    }

    public void b25() {
        if (M2.a(this, M2.STORAGE, 7) == true) {
            b24();
        }
    }

    public void b26() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.c));
        a.setMessage(getString(R.string.a33));
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a, int b) { 
              ws.deleteAllData(); g(getString(R.string.a34));
 
              
            } 
   	     });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            } 
   	     });
        a.create().show();
    } 
}
