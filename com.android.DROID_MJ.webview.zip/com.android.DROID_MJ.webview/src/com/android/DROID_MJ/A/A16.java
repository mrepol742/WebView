package com.android.DROID_MJ.A;

// souece coee

import android.app.Activity;

import android.content.Intent;
import android.os.Build;
import com.android.DROID_MJ.I.I3;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;  import com.android.DROID_MJ.C.C9;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.A.A10;
import com.android.DROID_MJ.webview.R;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import android.widget.Toolbar;
import android.app.AlertDialog;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.widget.EditText;
import android.view.LayoutInflater;
import android.content.SharedPreferences;
import android.widget.LinearLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.widget.Button; 
import com.android.DROID_MJ.T.T6;
import android.net.Uri;
import com.android.DROID_MJ.C.C5;
import android.view.ViewGroup;
import android.content.res.Configuration;
import com.android.DROID_MJ.U.U4;
import android.provider.Settings;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.W.W13;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.O.O8;
import java.io.BufferedReader;
import java.net.URL;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import android.view.ViewTreeObserver;
import com.android.DROID_MJ.W.W1;
import com.id;
import com.android.DROID_MJ.W.W5;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.N.N1;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.M.M2;
import android.widget.ProgressBar;
import com.android.DROID_MJ.W.W4;
import android.webkit.WebView;
import android.webkit.WebSettings;
import com.android.DROID_MJ.W.W29;
import android.graphics.Bitmap;
import com.android.DROID_MJ.W.W33;

public class A16 extends Activity  {

    private static String e;
    private static TextView k;
    private static int on;
    private static W4 w4;
    private static ProgressBar pb;
    private static Executor er = Executors.newCachedThreadPool();
    private static SharedPreferences sp;
    public static A16 A16;

    public static A16 getInstance() {
        return A16;
    }
    
    protected void onCreate(Bundle a) {
         sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }

O8.b();
super.onCreate(a);
setContentView(R.layout.d);
A16 = this;
        k = (TextView) findViewById(R.id.l);
        w4 = (W4) findViewById(R.id.j);
        pb = (ProgressBar) findViewById(R.id.h);
        Toolbar i = (Toolbar) findViewById(R.id.k);
        LinearLayout n = (LinearLayout) findViewById(R.id.n);
        Typeface m = G1.a(this, 200);
        Typeface kha = G1.a(this, 100);
        int o = C5.b(this,R.color.c);
        int p = C5.b(this,R.color.b);
        int a56 = C5.b(this,R.color.n);
        k.setTypeface(m);
        k.setText(getString(R.string.j));
        if (sp.getBoolean("autoUpdate", false) == false) {
   
            k.setTextColor(o);
            n.setBackgroundColor(p);
        } else {
            k.setTextColor(p);
            n.setBackgroundColor(a56);
        }
         w4.setBackgroundResource(R.color.b);
        i.setBackgroundResource(R.drawable.p);
        setActionBar(i);
pb.setMax(100);
i.setElevation(10);
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);
            i.setNavigationIcon(R.drawable.a2);
        i.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();
            }
        });
WebSettings ws = w4.getSettings();
        ws.setJavaScriptEnabled(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setDomStorageEnabled(false);
        ws.setDatabaseEnabled(false);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
ws.setBuiltInZoomControls(true);
    w4.setWebViewClient(new W29());
 w4.setWebChromeClient(new W33());

    }

    public boolean onCreateOptionsMenu(Menu a) {
            getMenuInflater().inflate(R.menu.b, a);
        return super.onCreateOptionsMenu(a);
    }
public boolean onPrepareOptionsMenu(Menu a) {
        MenuItem b1 = a.findItem(R.id.a15);
        MenuItem c1 = a.findItem(R.id.a14);
        MenuItem d1 = a.findItem(R.id.a17);
        MenuItem e1 = a.findItem(R.id.a16);
        MenuItem f1 = a.findItem(R.id.a20);
            b1.setIcon(C5.a(this, R.drawable.i)); 
            c1.setIcon(C5.a(this, R.drawable.g));
if (on ==Configuration.ORIENTATION_LANDSCAPE) { 
d1.setIcon(C5.a(this, R.drawable.b15)); 
            e1.setIcon(C5.a(this, R.drawable.b16)); 
}
return true;
}
    public boolean onOptionsItemSelected(MenuItem a) {
        switch (a.getItemId()) {
            case R.id.a16:
       //  C2.a(this, d.getText().toString());
          h(getString(R.string.c27));
                return true;
            case R.id.a17:
                d();
                return true;
     
            case R.id.a14:
 if (M2.a(this, M2.STORAGE, 1) == true) {
                f();
}
                return true;
            case R.id.a15:
              b();
                return true;
case R.id.a20:
                C1.e(this, "search", "a", A10.class);

return true;
            default:
                return super.onOptionsItemSelected(a);
         }
    }

    public boolean onKeyDown(int a, KeyEvent b1) {
        if (b1.getAction() == 0) {
            switch (a) {
                case 4:
                     finish();
        return true;
            }
        }
        return false;
    }
 
    protected void onResume() {
        super.onResume();
        i();

if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
         on = getResources().getConfiguration().orientation;
invalidateOptionsMenu();
        onNewIntent(getIntent());
    }

    private void a(String jk) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.j));
        a.setMessage(jk);
        a.setPositiveButton(getString(R.string.u14), new C6() {
            public void a(DialogInterface a, int b) {
Intent intent = new Intent();
    
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", U4.a(W5.a10()), null);
        intent.setData(uri);
startActivity(intent);
               a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    private void b() {
      e(k.getText().toString()+".html");
      Intent a = new Intent(Intent.ACTION_VIEW);
        
        a.setDataAndType(Uri.parse(I3.a() + "/WebView/Source Code/"+ k.getText().toString()+".html"), "text/html");
if (a.resolveActivity(getPackageManager()) != null) { 
startActivity(Intent.createChooser(a, getString(R.string.a26)));
}
    }

    private void d() {
        Intent a = new Intent("android.intent.action.SEND");
        a.setType("text/plain");
       // a.putExtra("android.intent.extra.TEXT", d.getText().toString());
        String c = getString(R.string.l8);
        String d = c.replaceAll("%a", "\""+k.getText().toString()+"\"");
        startActivity(Intent.createChooser(a, d));
    }

    public void e(String  ko) {
        try {
             File a2 = new File(I3.a() + "/WebView/Source Code/" + ko);
            if (!a2.exists()) {
             a2.createNewFile();
             FileOutputStream a3 = new FileOutputStream(a2);
            OutputStreamWriter a4 = new OutputStreamWriter(a3);
           //  a4.append(d.getText().toString());
            a4.close();
             a3.close();
          h(getString(R.string.c28).replaceAll("%a", ko));
}
        } catch (FileNotFoundException a) {
             M2.a(this, M2.STORAGE, 1);

        } catch (IOException b) {

        }
    }

    private void f() {
        AlertDialog.Builder a5 = new AlertDialog.Builder(this);
        LayoutInflater a6 = getLayoutInflater();
        View a7 = a6.inflate(R.layout.f, null);
        a5.setCancelable(true); 
        a5.setTitle(getString(R.string.c29));
        a5.setView(a7);
        final EditText a8 = (EditText) a7.findViewById(R.id.b3);
        TextView f14 = (TextView)a7.findViewById(R.id.f14);
        TextView f15 = (TextView)a7.findViewById(R.id.f15);
        final TextView f17 = (TextView)a7.findViewById(R.id.f17); 
        int a15 = C5.b(this,R.color.c);
        int a16 = C5.b(this,R.color.b);
        int f = C5.b(this,R.color.j);
        int g = C5.b(this,R.color.k);
        if (sp.getBoolean("autoUpdate", false) == false) {
            a8.setTextColor(a15);
            f14.setTextColor(a15);
            f15.setTextColor(a15);
            f17.setTextColor(a15);
            a8.setHintTextColor(f);
        } else {
            a8.setTextColor(a16);
            f14.setTextColor(a16);
            f15.setTextColor(a16);
            f17.setTextColor(a16);
            a8.setHintTextColor(g);
        }      
        a8.setHint(k.getText().toString()+".html");
        f14.setText(getString(R.string.c30));
        f15.setText(getString(R.string.c31));
        f17.setText("/Internal Storage/WebView/Source Code/");
        a5.setPositiveButton("Save", new C6() { 
            public void a(DialogInterface a, int b) { 
e(a8.getText().toString());
                a.dismiss();

  	         } 
  	     }); 
        a5.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a, int b) { 
                a.dismiss();
  	         } 
  	     }); 
        final AlertDialog d = a5.create();
            a8.addTextChangedListener(new T6() {
                private void a() {
        final Button okButton = d.getButton(AlertDialog.BUTTON_POSITIVE);
  String j78 = a8.getText().toString();
        String kj = j78.replaceAll(" ", "");
f17.setText("/Internal Storage/WebView/Source Code/"+j78);
        if(kj.length() == 0) {

            okButton.setEnabled(false);
        } else {
            File che = new File(I3.a() + "/WebView/Source Code/"+j78);
if (che.exists()) {
  okButton.setEnabled(false);
a8.setError(getString(R.string.u19));
} else {
okButton.setEnabled(true);
}
               
        }
    }
    public void c(Editable arg0) {
    }
    public void a(CharSequence s, int start, int count, int after) {
    }
    public void b(CharSequence s, int start, int before, int count) {
a();
    }
});
d.show();
d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);

    }
 

    public void g(String a) {
        W1.c(this, a);
    }

    public void h(String a) {
        W1.b(this, a);
    }

    public void i() {
        File b = new File(I3.a() + "/WebView", "Source Code");
        if (!b.exists()) {
            b.mkdirs();
        }
    }
 
    private void j(final String a) {
        pb.setIndeterminate(true);
        P15 p = new P15() {
            public void a() {
//System.setProperty("http-agent", "");
                final String cd = U6.b(a).replaceAll("><", ">\n\n<").replaceAll("> <", ">\n\n<").replaceAll(">  <", ">\n\n<").replaceAll("\\{", "\\{\n").replaceAll("\\}", "\\}\n").replaceAll("function()\\{", "\nfunction () \\{");
                runOnUiThread(new P15() {
                     public void a() {
                         w4.loadDataWithBaseURL(null, cd ,"text", "UTF-8", null);
        pb.setIndeterminate(false);
                      }
                  });
              }
         };
         er.execute(new Thread(p));
         invalidateOptionsMenu();
    }

    public void k(WebView a, int b) {
        pb.setProgress(b);
        if (b >= 100) {
            pb.setVisibility(View.GONE);
        } 
    }

    public void l(WebView a, String b, Bitmap c) {
        pb.setVisibility(View.VISIBLE);
    }

    public void onRequestPermissionsResult(int a, String[] b, int[] c) {
        super.onRequestPermissionsResult(a, b, c);
        switch (a) {
            case 1:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    f();
                } else {  
       
                        if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                            g(getString(R.string.u15));
                        } else {
         a(getString(R.string.u16));
}
                   
              }
              break;
        }
    }
public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
      on= newConfig.orientation;
invalidateOptionsMenu();
    }

    protected void onNewIntent(Intent a) {
        try {
            String action = a.getAction();
            String data = a.getDataString();
            if (Intent.ACTION_VIEW.equals(action) || "com.android.DROID_MJ.webview.intent.action.TOOLS".equals(action) || "com.android.DROID_MJ.webview.intent.action.VIEW".equals(action)) {
                if (data != null) {
                    if (!W13.i(data)) {
                       j(data);
                    } else {
                       j(U4.a(W5.x()));
                    }
                     k.setText(a.getStringExtra("qr"));
                     a.removeExtra("qr");
                }
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
}
 