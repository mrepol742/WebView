package com.android.DROID_MJ.A;

// databases error 

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;

import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.webview.R;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.android.DROID_MJ.C.C6;
import com.android.DROID_MJ.I.I2;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.C.C13;
import java.io.File;
import com.android.DROID_MJ.W.W1;

public class A26 extends Activity  {
    protected void onCreate(Bundle a) {
         
              SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (b.getBoolean("autoUpdate", false) == false) {
           
                setTheme(R.style.b8);
         
        } else {
        
                setTheme(R.style.b14);
         
        }
 
        

O8.b();
super.onCreate(a);

a();
    }

   protected void onResume() {
       super.onResume();

if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();


}
   }
    private void a() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.f39));
a.setMessage(getString(R.string.f40));
 
        a.setPositiveButton(getString(R.string.g21), new C6() {
            public void a(DialogInterface a, int b1) { 
a.dismiss();
finish();

            } 
   	     });

a.setOnDismissListener(new C13() {
            public void a(DialogInterface di) {
                finish();
            }
        });
        
a.create().show();
    } 
 
}