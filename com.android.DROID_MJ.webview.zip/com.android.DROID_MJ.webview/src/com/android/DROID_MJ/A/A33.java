package com.android.DROID_MJ.A;
import android.os.Bundle;
import com.android.DROID_MJ.C.C1;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class A33 extends A22 {
    protected void a1(Bundle be) {
SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
 
          if (b.getBoolean("lockWn99", false) == true) {
          
              C1.a(this, A29.class);
              
           }  else {
 C1.a(this, A18.class);
}
finish();
    }
}