package com.android.DROID_MJ.A;

// TEXT SIZE SETTINGS

import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import com.android.DROID_MJ.C.C9;
import com.android.DROID_MJ.C.C5;
import android.widget.Toolbar;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.webview.R;
import android.app.Activity;

import android.widget.TextView;
import android.view.KeyEvent;
import android.widget.SeekBar;
import com.android.DROID_MJ.W.W4;
import android.webkit.WebSettings;
import com.android.DROID_MJ.W.W7;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
import android.content.pm.ActivityInfo;
import com.android.DROID_MJ.W.W25;
import android.webkit.WebView;


public class A12 extends Activity  {
    private static SharedPreferences sp;
        
    
    
      protected void onCreate(Bundle a) {
          sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.d);
            } else {
                setTheme(R.style.b15);
            }
        } else {
            if (sp.getBoolean("autoUpdate742", false) == false) {
                setTheme(R.style.e);
            } else {
                setTheme(R.style.b16);
            }
        }
          

O8.b();
super.onCreate(a);
          
setContentView(R.layout.l);
        
        
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        
          Toolbar h17 = (Toolbar) findViewById(R.id.c3);
          TextView h18 = (TextView) findViewById(R.id.c4);
          TextView k8 = (TextView) findViewById(R.id.c5);
          TextView a11 = (TextView) findViewById(R.id.b16);
          final SeekBar a1 = (SeekBar) findViewById(R.id.a1);
          TextView a9 = (TextView) findViewById(R.id.b17);
          final SeekBar a10 = (SeekBar) findViewById(R.id.b18);
          final W4 w4 = (W4) findViewById(R.id.j);        
          
        h18.setTypeface(G1.a(this, 200));
k8.setTypeface(G1.a(this, 200));
a11.setTypeface(G1.a(this, 100));
a9.setTypeface(G1.a(this, 100));
        setActionBar(h17);
        h17.setElevation(10);
h18.setText(getString(R.string.g14));
      k8.setText(getString(R.string.l13));
       
getActionBar().setDisplayShowTitleEnabled(false);
getActionBar().setDisplayHomeAsUpEnabled(true);

        if (sp.getBoolean("autoUpdate", false) == false) {
            h18.setTextColor(C5.b(this,R.color.c));
a11.setTextColor(C5.b(this,R.color.c));
a9.setTextColor(C5.b(this,R.color.c));
k8.setTextColor(C5.b(this,R.color.c));
        } else {
            h18.setTextColor(C5.b(this,R.color.b));
k8.setTextColor(C5.b(this,R.color.b));
a11.setTextColor(C5.b(this,R.color.b));
a9.setTextColor(C5.b(this,R.color.b));
        }
         h17.setBackgroundResource(R.drawable.p);
            h17.setNavigationIcon(R.drawable.a2);
        h17.setNavigationOnClickListener(new C9() {
            public void a(View v) {
                finish();

            }
        });

        SharedPreferences prefs = getSharedPreferences("webDa",0);
        boolean d78 = prefs.getBoolean("webDa", false);
        if (d78 == true) {
            k8.setVisibility(View.VISIBLE);
        } else {
            k8.setVisibility(View.GONE);
        }
        w4.setWebViewClient(new W7());
w4.loadDataWithBaseURL(null,"<!DOCTYPE html><html><head><title>WebView Text Size</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no\"></head><body><h1>Heading 1</h1><h2>Heading 2</h2><h3>Heading 3</h3><h4>Heading 4</h4><h5>Heading 5</h5><h6>Heading 6</h6><p>Paragraph</p><span>Span</span><b>Bold</b><i>Italic</b></body></html>", "text/html", new WebView(this).getSettings().getDefaultTextEncodingName(), null);
a11.setText(getString(R.string.o8));
a9.setText(getString(R.string.f37));
final WebSettings ws = w4.getSettings();
final SharedPreferences a35 = getApplicationContext().getSharedPreferences("dr", 0);   
final SharedPreferences a25 = getApplicationContext().getSharedPreferences("dr55", 0);   
int it = a35.getInt("dr", 0);
if (it == 0) {
ws.setTextZoom(new WebView(this).getSettings().getTextZoom());
a10.setProgress(new WebView(this).getSettings().getTextZoom());
} else {
ws.setTextZoom(it);
a10.setProgress(it);
}
int it2 = a25.getInt("dr55", 0);
if (it2 == 0) {
ws.setDefaultFontSize(new WebView(this).getSettings().getDefaultFontSize());
a1.setProgress(new WebView(this).getSettings().getDefaultFontSize());
} else {
ws.setDefaultFontSize(it2);
a1.setProgress(it2);
}


     a10.setOnSeekBarChangeListener(new W25() {
            public void a(SeekBar seekBar, int progress, boolean fromUser) {
ws.setTextZoom(progress);
w4.reload();
SharedPreferences.Editor b5; 

 b5 = a35.edit(); 
 b5.putInt("dr",progress);
 b5.apply();
            }
            public void b(SeekBar seekBar) {
            }
            public void c(SeekBar seekBar) {
            }
        });
     a1.setOnSeekBarChangeListener(new W25() {
            public void a(SeekBar seekBar, int progress, boolean fromUser) {
ws.setDefaultFontSize(progress);
w4.reload();
SharedPreferences.Editor b5; 

 b5 = a25.edit(); 
 b5.putInt("dr55",progress);
 b5.apply();
            }
            public void b(SeekBar seekBar) {
            }
            public void c(SeekBar seekBar) {
            }
        });
        

}
protected void onResume() {
super.onResume();
if (sp.getBoolean("qwe73", false) == true) {
System.gc();
}
}
    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            finish();


            return true;
        }

        return super.onKeyUp(a, b);
    }
}