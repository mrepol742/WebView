package com.android.DROID_MJ.A;

// PRETEND MODE

import com.android.DROID_MJ.W.W4;
import com.android.DROID_MJ.webview.R;
import android.app.Activity;

import android.os.Bundle;
import com.android.DROID_MJ.C.C5;
import android.view.KeyEvent;
import android.widget.Toolbar;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.widget.TextView;
import android.view.View; 
 import com.android.DROID_MJ.C.C9;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.W.W3;
import android.content.Intent;
import android.webkit.WebView;
import java.util.HashMap;
import java.util.Map;
import android.graphics.Bitmap;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.W.W26;
import com.java.DROID_MJ.S.S1;
import com.android.DROID_MJ.W.W27;
import android.webkit.WebSettings;


public class A27 extends Activity  {
    
    private static W4 a;
    private static A27 A27;
    private static String b = "<!DOCTYPE html><html><head><title>DROID_CALCU</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no\"><style type=\"text/css\">body{margin:0;padding: 10px;display: grid; background:#000;} input {height:70px;width:20%;outline:none;transition:0.2s;font-family:maven;}input[type=\"text\"] {width: 80%;font-size:42px;margin-left: 10%;margin-right: 10%;background:transparent;border:none;color:#fff;}input[type=\"button\"] {background:#141414;color:#fff;border-style:solid;border-radius: 5px;border-width: 1px;border-color: transparent;margin: 2px;font-size:22px;}.equal{width:50%;}#rst{width:25%;background:#4285f4;color: #ffffff;border-style:solid;border-radius: 5px;border-width: 1px;border-color: transparent;}input:active {background:#4285f4;}input:active[type=\"text\"]{background:transparent;}@font-face maven{font-family:maven;src:url(\"MavenPro.ttf\");}</style></head><body><form name=\"c\" ><div><input type=\"text\" name=\"a\" disabled><br></div><div><br><center><input type=\"button\" onclick=\"seven()\" value=\"7\"><input type=\"button\" value=\"8\" onclick=\"eight()\"><input type=\"button\" value=\"9\" onclick=\"nine()\"><input type=\"button\" value=\"+\" onclick=\"add()\"><br><input type=\"button\" value=\"4\" onclick=\"four()\"><input type=\"button\" value=\"5\" onclick=\"five()\"><input type=\"button\" value=\"6\" onclick=\"six()\"><input type=\"button\" value=\"–\" onclick=\"mins()\"><br><input type=\"button\" value=\"1\" onclick=\"one()\"><input type=\"button\" value=\"2\" onclick=\"two()\"><input type=\"button\" value=\"3\" onclick=\"three()\"><input type=\"button\" value=\"×\" onclick=\"times()\"><br><input type=\"button\" value=\".\" onclick=\"dot()\"><input type=\"button\" value=\"0\" onclick=\"zero()\"><input type=\"button\"  onclick=\"document.c.a.value = document.c.a.value.slice(0, -1)\" value=\"←\" ><input type=\"button\" value=\"÷\" onclick=\"divide()\"><br><input type=\"button\" value=\"=\" class=\"equal\" onclick=\"calculate()\"><input type=\"reset\" value=\"AC\" id=\"rst\" ></center></div></form><script type=\"text/javascript\">function seven() {var a = document.c.a.value;document.c.a.value+=\"7\";}function eight() {var a = document.c.a.value;document.c.a.value+=\"8\";}function nine() {var a = document.c.a.value;document.c.a.value+=\"9\";}function four() {var a = document.c.a.value;document.c.a.value+=\"4\";}function five() {var a = document.c.a.value;document.c.a.value+=\"5\";}function six() {var a = document.c.a.value;document.c.a.value+=\"6\";}function one() {var a = document.c.a.value;document.c.a.value+=\"1\";}function two() {var a = document.c.a.value;document.c.a.value+=\"2\";}function three() {var a = document.c.a.value;document.c.a.value+=\"3\";}function add() {var a = document.c.a.value;if (!a.endsWith(\"+\") && !a.endsWith(\"*\") && !a.endsWith(\"/\") && !a.endsWith(\".\") && !a.endsWith(\"-\") && a.length != 0) {document.c.a.value+=\"+\";} else if (a.length != 0) {document.c.a.value = document.c.a.value.slice(0, -1)+\"+\";}}function mins() {var a = document.c.a.value;if (!a.endsWith(\"+\") && !a.endsWith(\"*\") && !a.endsWith(\"/\") && !a.endsWith(\".\") && !a.endsWith(\"-\") && a.length != 0) {document.c.a.value+=\"-\";} else if (a.length != 0) {document.c.a.value = document.c.a.value.slice(0, -1)+\"-\";}}function times() {var a = document.c.a.value;if (!a.endsWith(\"+\") && !a.endsWith(\"*\") && !a.endsWith(\"/\") && !a.endsWith(\".\") && !a.endsWith(\"-\") && a.length != 0) {document.c.a.value+=\"*\";} else if (a.length != 0) {document.c.a.value = document.c.a.value.slice(0, -1)+\"*\";}}function divide() {var a = document.c.a.value;if (!a.endsWith(\"+\") && !a.endsWith(\"*\") && !a.endsWith(\"/\") && !a.endsWith(\".\") && !a.endsWith(\"-\") && a.length != 0) {document.c.a.value+=\"/\";} else if (a.length != 0) {document.c.a.value = document.c.a.value.slice(0, -1)+\"/\";}}function zero() {var a = document.c.a.value;document.c.a.value+=\"0\";}function dot() {var a = document.c.a.value;if (!a.endsWith(\"+\") && !a.endsWith(\"*\") && !a.endsWith(\"/\") && !a.endsWith(\"-\") && a.length != 0 && !a.endsWith(\".\")) {document.c.a.value+=\".\";} else if (a.length != 0) {document.c.a.value = document.c.a.value.slice(0, -1)+\".\";}}function calculate() {var a = eval(document.c.a.value);if (document.c.a.value.includes(\"+\") || document.c.a.value.includes(\"/\") || document.c.a.value.includes(\"*\") || document.c.a.value.includes(\"-\")) {document.c.a.value =a;console.log(a);}}</script></body></html>";
    public static A27 getInstance() {
        return A27;
    }
    private static SharedPreferences sp;

    protected void onCreate(Bundle be) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        setTheme(R.style.e);
        O8.b();
        super.onCreate(be);
        
        setContentView(R.layout.b20);
        A27 = this;
        a = (W4)findViewById(R.id.j);
        a.setWebViewClient(new W26());
        a.setWebChromeClient(new W27());
        if (sp.getBoolean("autoUpdate", false) == false) {
            a.setBackgroundResource(R.color.b);
            findViewById(R.id.l10).setBackgroundResource(R.color.b);
        } else {
            a.setBackgroundResource(R.color.n);
findViewById(R.id.l10).setBackgroundResource(R.color.n);
        }
        WebSettings ws = a.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        a();
    }

    public boolean onKeyDown(int a5, KeyEvent b) {
        if (b.getAction() == KeyEvent.ACTION_DOWN) {
            switch (a5) {
                case KeyEvent.KEYCODE_BACK:

                        System.exit(0);
                    return true;
            }

        }
        return super.onKeyDown(a5, b);
    }

    protected void onResume() {
        super.onResume();
        if (sp.getBoolean("qwe73", false) == true) {
            System.gc();
        }
    }

    public void a() {
        a.loadDataWithBaseURL(null, b, "text/html", new WebView(this).getSettings().getDefaultTextEncodingName(), null);
    }

    public boolean b(String url) {
        SharedPreferences b = getSharedPreferences("gsJsGsKSIgPes" ,0);
        String c = b.getString("gsJsGsKSIgPes","");
        if (c.length() !=  0) {
            if (c.equals(S1.a("SHA-512",url))) {
                finish();
            } 
        }
        return true;
    }
}