package com.android.DROID_MJ.A;

import android.graphics.Bitmap;
import android.widget.LinearLayout;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.content.res.Resources;
import com.android.DROID_MJ.V.V1;
import android.text.Html;
import com.android.DROID_MJ.M.M1;
import com.android.DROID_MJ.C.C5;
import android.content.Intent.ShortcutIconResource;
import android.graphics.Bitmap.CompressFormat;
import android.provider.Settings;
import java.io.File;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.A.A1;
import com.android.DROID_MJ.O.O1;
import com.android.DROID_MJ.A.A4;
import android.net.Uri;
import android.media.MediaScannerConnection;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.webview.R;
import android.widget.Toast;
import android.app.PendingIntent;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import com.android.DROID_MJ.A.A3;
import android.os.Build;
import android.os.Handler;
import com.android.DROID_MJ.S.S1;
import com.android.DROID_MJ.O.O2;
import com.android.DROID_MJ.A.A17;
import com.android.DROID_MJ.A.A28;
import com.android.DROID_MJ.W.W10;
import com.android.DROID_MJ.A.A2;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.annotation.TargetApi;
import android.text.SpannableStringBuilder;
import android.graphics.Color;
import android.text.style.ForegroundColorSpan;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.content.DialogInterface; import com.android.DROID_MJ.C.C6;
import android.os.Bundle;
import com.android.DROID_MJ.I.I3;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;   import com.android.DROID_MJ.C.C9;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.Manifest;
import com.android.DROID_MJ.S.S3;
import android.content.pm.PackageManager;
import android.widget.Toolbar;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.widget.PopupMenu;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.graphics.BitmapFactory;
import android.webkit.JsResult;
import android.webkit.GeolocationPermissions;
import android.view.ContextMenu;
import android.webkit.WebView.HitTestResult;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.content.pm.ActivityInfo;
import android.webkit.DownloadListener;
import android.webkit.WebViewDatabase;
import android.webkit.CookieSyncManager;
import android.content.pm.ApplicationInfo;
import java.util.Map;
import android.view.LayoutInflater;
import android.content.ActivityNotFoundException;
import android.speech.RecognizerIntent;
import java.util.Locale;
import java.util.ArrayList;
import android.app.SearchManager;
import android.webkit.JsPromptResult;
import android.os.CountDownTimer;
import android.widget.HorizontalScrollView;
import android.text.format.Formatter;
import android.text.Editable;
import android.widget.Button;
 import com.android.DROID_MJ.T.T6;
import android.text.TextUtils;
import android.media.AudioManager;
import android.graphics.drawable.BitmapDrawable;
import android.view.MotionEvent;
import android.text.Spannable;
import android.provider.MediaStore;
import android.widget.TextView.OnEditorActionListener;
import android.content.res.Configuration;
import android.net.wifi.WifiManager;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.A.A16;
import com.android.DROID_MJ.W.W8;
import com.android.DROID_MJ.V.V2;
import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.C.C3;
import android.webkit.WebView;
import android.view.GestureDetector;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.W.W11;
import com.android.DROID_MJ.W.W13;
import com.android.DROID_MJ.D.D1;
import com.android.DROID_MJ.W.W14;
import android.widget.TextView.BufferType;
import com.android.DROID_MJ.U.U3;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import com.android.DROID_MJ.A.A15;
import com.android.DROID_MJ.D.D3;
import com.android.DROID_MJ.U.U4;
import android.content.res.AssetManager;
import java.io.InputStream;
import com.android.DROID_MJ.U.U5;
import java.util.HashMap;
import com.android.DROID_MJ.N.N2;
import android.net.http.SslCertificate;
import com.android.DROID_MJ.V.V4;
import com.android.DROID_MJ.W.W12;
import com.android.DROID_MJ.W.W21;
import android.net.wifi.WifiInfo;
import android.print.PrintManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.android.DROID_MJ.D.D2;
import android.content.IntentFilter;
import com.android.DROID_MJ.R.R14;
import com.android.DROID_MJ.P.P15;
import android.os.BatteryManager;
import android.widget.SearchView;
import com.android.DROID_MJ.C.C11;
import com.android.DROID_MJ.C.C8;
import android.webkit.WebResourceResponse;
import android.os.AsyncTask;
import android.database.Cursor;
import java.io.BufferedReader;
import java.net.URL;
import java.io.InputStreamReader;
import com.android.DROID_MJ.O.O8;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.R.R6;
import com.android.DROID_MJ.R.R8;
import com.android.DROID_MJ.R.R36;
import com.android.DROID_MJ.R.R7;

import android.content.BroadcastReceiver;
   
import java.util.concurrent.Executor;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.W.W5;
import java.net.MalformedURLException;
import com.android.DROID_MJ.C.C10;
import android.text.InputType;
import com.android.DROID_MJ.T.T2;
import com.android.DROID_MJ.S.S8;
import android.widget.SeekBar;
import com.java.DROID_MJ.U.U7;
import java.net.URISyntaxException;
import android.content.ComponentCallbacks2;
import com.android.DROID_MJ.C.C13;
import java.util.concurrent.Executors;

import com.android.DROID_MJ.W.W25;
import java.io.OutputStreamWriter;
import android.os.Message;
import android.widget.AutoCompleteTextView;
import android.widget.ArrayAdapter;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.RelativeLayout;
import android.webkit.SafeBrowsingResponse;
import com.android.DROID_MJ.M.M2;
import android.webkit.PermissionRequest;
import java.util.Arrays;
import com.android.DROID_MJ.W.W32;
import android.webkit.RenderProcessGoneDetail;
import com.notif_id;
import android.nfc.NfcAdapter;
import android.nfc.NdefRecord;
import android.nfc.NdefMessage;
import com.android.DROID_MJ.S.S7;
import com.android.DROID_MJ.C.C7;
 
public class A21 extends Activity implements ComponentCallbacks2 {
    public ValueCallback<Uri[]> b;
    public static A21 A21;
    public ProgressBar g;
    public static W10 h;
    public Toolbar o;
    public EditText s;
    public TextView u;
    public int a7;
    public int a8;
    public int a9;
    public Typeface a10;
    public final int a17 = 100;
    public boolean bl4 = false;
    public boolean bl5 = false;
    public LinearLayout cd;
    public LinearLayout back23;
    public Map<String, String> eh;
    public CountDownTimer timer;
    public HorizontalScrollView hsv;
   public static EditText hjk;
    int b7;
    byte[] ub6;
  public static  String hjk99;
    float aa;
    int b7gh;
  public View 
cv;
    public WebChromeClient.CustomViewCallback cvc; 
    protected FrameLayout fl;
    public int it742 = getRequestedOrientation();
    public int it7422;
    int b75;
    int ck;
           public static StringBuilder cm = new StringBuilder();
   public static String jk97;
    int timeset = 3600000;
   public static ImageButton off;
   public static EditText haha9457;
    private int on;
    public static boolean bl = false;
    public static ImageView tv;
public static ImageView tv1;
public static ImageView tv2;
public static ImageView tv3;
public static ImageView tv4;
public static ImageView tv5;
private static boolean bl1 = false;
public static boolean bl2 = false;
public static boolean bl3 = false;
private static D1 d1;
private static  D2 d2;
private  boolean ua = false;
private static SeekBar c2;
private BroadcastReceiver br = new R6();
private static RelativeLayout rl;
private BroadcastReceiver br1 = new R8();
private BroadcastReceiver br2 = new R36();
    private static SharedPreferences sp;
        private static WebSettings ws;
    private static Executor er = Executors .newCachedThreadPool();
   public static D3 d3;
public static NfcAdapter na;
   public static CookieManager cm1;
public static WebViewDatabase wd;
public static ImageView iw;
    private  Handler hr = new Handler();
    private P15 rn = new P15() {        
        public void a() { 
            h.reload();
        }
    };

       private static final String[] js = new String[]{"document.getElementById()", "document.getElementByTagName()", "document.getElementByClassName()", "document.getElementByName()", "document.body.style.backgroundColor", "document.body.style.color" , "document.body.style.margin", "document.body.style.marginLeft","document.body.style.marginBottom", "document.body.style.marginRight", "document.body.style.marginTop", "document.body.style.padding", "document.body.style.paddingTop", "document.body.style.paddingBottom", "document.body.style.paddingLeft", "document.body.style.paddingRight", "document.body.style.backgroundImage", "document.body.style.backgroundRepeat", "document.body.style.backgroundClip", "document.body.style.backgroundPosition", "document.body.style.backgroundSize", "document.body.style.background", "document.body.style.cursor", "document.body.style.outline", "document.body.style.fontFamily", "document.body.style.fontSize", "document.body.style.fontWeight", "document.body.style.fontStyle", "WebView.showToast(var text)", "WebView.showToastError(var text)", "WebView.vibrate(var text)", "WebView.showToastSuccess(var text)", "WebView.showNotification(var title, var contentText, var validUrl)", "document.getAttribute()", "document.getAttributeNode()", "document.getBoundingClientRect()", "document.getClientRects()", "document.setAttribute()", "document.setAttributeNode()", "document.addEventListener", "WebView.exit()", "WebView.copyToClipboard(var)", "WebView.enableWifi(var boolean)", "WebView.enableFlashlight(var boolean)"};

    protected void onActivityResult(int a, int b, Intent c) {
        super.onActivityResult(a, b, c);
         if (a == 742) {
                if (b == Activity.RESULT_OK && null != c) {

                    ArrayList<String> result = c.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String query = result.get(0);
                    c8(getString(R.string.d39) .replaceAll("%a",query));
                    c49(query);

     c103(query);
                }
        }
	    if (a == 911) {
	        if (b == Activity.RESULT_OK && null != c){
		        String z = c.getStringExtra("result");
                c49(z);
            }
        }
        if (a == 211) {
	        if (b == Activity.RESULT_OK && null != c){
		        String z = c.getStringExtra("result");
                c49(z);
            }
	    }
   
        if (a == 2115) {
	        if (b == Activity.RESULT_OK && null != c){
		        String z = c.getStringExtra("result");
                c49(z);
            }
	    }
   
        if (a == 3) {
	        if (b == Activity.RESULT_OK && null != c){
 c3(c.getDataString());  
         
           }
}
        if (a != 2 || this.b == null) {
            super.onActivityResult(a, b, c);
            return;
        }
        Uri[] a1 = null;

        if (b == Activity.RESULT_OK) {
            String b1 = c.getDataString();  
             if (b1 != null) {
                a1 = new Uri[]{Uri.parse(b1)};
            }
        }
        this.b.onReceiveValue(a1);
        this.b = null;        
    }

    public static A21 getInstance() {
        return A21;
    }
    
    protected void onCreate(Bundle a) {
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("webviewB", false) == false) {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.d);
                } else {
                    setTheme(R.style.b15);
                }
            } else {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.a);
                } else {
                    setTheme(R.style.b19);
                }
            }
        } else {
            if (sp.getBoolean("webviewB", false) == false) {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.e);
                } else {
                    setTheme(R.style.b16);
                }
            } else {
                if (sp.getBoolean("autoUpdate742", false) == false) {
                    setTheme(R.style.g);
                } else {
                    setTheme(R.style.c2);
                }
            }
        }

O8.b();
super.onCreate(a);
        if (sp.getBoolean("enableSWDD", false) == true) {
        

        WebView.enableSlowWholeDocumentDraw();
    }

c41();
        if (sp.getBoolean("webviewB", false) == true) {
         
setContentView(R.layout.c);

} else {

setContentView(R.layout.a1);
}

        A21 = this;
        this.o = (Toolbar) findViewById(R.id.f);
        this.g = (ProgressBar) findViewById(R.id.h);
        h = (W10) findViewById(R.id.a2);
        tv = (ImageView) findViewById(R.id.d19);
        tv1 = (ImageView) findViewById(R.id.b1);
        tv2 = (ImageView) findViewById(R.id.z);
        tv3 = (ImageView) findViewById(R.id.r);
        tv4 = (ImageView) findViewById(R.id.s);
        tv5 = (ImageView) findViewById(R.id.q);
        this.cd = (LinearLayout) findViewById(R.id.v);
        rl = (RelativeLayout) findViewById(R.id.b6);
        hsv = (HorizontalScrollView) findViewById(R.id.c13);
        c2 = (SeekBar) findViewById(R.id.c18);
        iw = (ImageView) findViewById(R.id.d20);
        registerForContextMenu(h);
        this.u = (TextView) findViewById(R.id.g);
        this.back23 = (LinearLayout) findViewById(R.id.e);
        setActionBar(this.o);
 getActionBar().setDisplayHomeAsUpEnabled(false);
        getActionBar().setDisplayShowTitleEnabled(false);
this.o.setElevation(10);

        iw.setOnClickListener(new C9() {
             public void a(View v) {
                 c75();
             }
        });
        eh = new HashMap<String, String>();
        eh.put("DNT", "1");
        this.a7 = C5.b(this,R.color.c);
        this.a8 = C5.b(this,R.color.b);
        this.a9 = C5.b(this,R.color.a);
        this.a10 = G1.a(this, 100);
        c6();     

tv5.setImageResource(R.drawable.a18);
        this.cd.setOnClickListener(new C9() {
            public void a(View a) {
                c22();
            }
        });
        this.cd.setOnLongClickListener(new C8() {
            public boolean a(View a) {
                c12();
                return true;
            }
        });
        hsv.setOnClickListener(new C9() {
            public void a(View a) {
                c22();
            }
        });
        hsv.setOnLongClickListener(new C8() {
            public boolean a(View a) {
                c12();
                return true;
            }
        });
       u.setOnClickListener(new C9() {
            public void a(View a) {
                c22();
            }
        });
       tv.setOnLongClickListener(new C8() {
            public boolean a(View a) {
                A21.tv.setVisibility(View.GONE);
                V1.a(A21.this, R.anim.g, A21.tv);
                return true;
            }
        });
        u.setOnLongClickListener(new C8() {
            public boolean a(View a) {
                c12();
                return true;
            }
        });

        this.u.setTypeface(this.a10);
        this.g.setMax(100);
               h.setOnTouchListener(new C7() {
        public boolean a(View v, MotionEvent event) {
            if ((event.getFlags() & MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    new AlertDialog.Builder(A21.this).setTitle(getString(R.string.c13)).setMessage(getString(R.string.b16)).setNeutralButton(getString(R.string.k37), null).show();
                }
                return true;
            }
            return false;
        }
    });
try {
d1 = D1.getInstance(getApplicationContext());
d2 = D2.getInstance(getApplicationContext());
   d3 = D3.getInstance(getApplicationContext());
        na = NfcAdapter.getDefaultAdapter(getApplicationContext());
        ws = h.getSettings();
c50();
c34(h,ws);
 c131();
          if (sp.getBoolean("autoUpdate", false) == false) {
             this.u.setTextColor(this.a7);

          } else {
             this.u.setTextColor(this.a8);
          }
          final File fe = new File(I3.a()+"/WebView/.cache/a.cache");
          if (sp.getBoolean("autoUpdate", false) == false) {
              if (sp.getBoolean("webviewB", false) == false) {
                  this.o.setBackgroundResource(R.drawable.p);
this.back23.setBackgroundResource(R.color.b);          
h.setBackgroundColor(C5.b(this,R.color.b));   tv.setBackgroundResource(R.drawable.f1);
                  this.cd.setBackgroundResource(R.drawable.w);
                      
              } else {
                  if (!fe.exists()) {
                      this.o.setBackgroundResource(R.drawable.p);
                      this.back23.setBackgroundResource(R.color.b);     
                      tv.setBackgroundResource(R.drawable.f1);
       h.setBackgroundColor(C5.b(this,R.color.b)); cd.setBackgroundResource(R.drawable.w);
                  } else {
                        this.o.setBackgroundResource(android.R.color.transparent); 
                        h.setBackgroundColor(C5.b(this,android.R.color.transparent));
tv.setBackgroundResource(R.drawable.f1);
                        this.back23.setBackground(new BitmapDrawable(this.getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache"))); 
                        cd.setBackgroundResource(R.drawable.w);
              
                    }
                }
            } else {
                if (sp.getBoolean("webviewB", false) == false) {
                    this.o.setBackgroundResource(R.drawable.p);

                    this.back23.setBackgroundResource(R.color.n); 
                    h.setBackgroundColor(C5.b(this,R.color.b)); 
tv.setBackgroundResource(R.drawable.f1);
                    this.cd.setBackgroundResource(R.drawable.w);
             
                } else {
                    if (!fe.exists()) {
                        this.o.setBackgroundResource(R.drawable.p);
                        this.back23.setBackgroundResource(R.color.n); 
                        h.setBackgroundColor(C5.b(this,R.color.b));
tv.setBackgroundResource(R.drawable.f1); cd.setBackgroundResource(R.drawable.w);
    
                    } else {
                        this.o.setBackgroundResource(android.R.color.transparent);
tv.setBackgroundResource(R.drawable.f1);
                        this.back23.setBackground(new BitmapDrawable(this.getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache"))); 
                       
                    h.setBackgroundColor(C5.b(this,android.R.color.transparent)); this.cd.setBackgroundResource(R.drawable.w);


                    }
                }
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
 
    

cm1 = CookieManager.getInstance();
wd = WebViewDatabase.getInstance(getApplicationContext());
if (na != null) {
           // na.setNdefPushMessage(new NdefMessage(NdefRecord.createUri("")), this);
           // c7("Tap another Android phone with NFC to push a URL");
        } else {
            //c7("This phone is not NFC enabled.");
        }
        SharedPreferences i5 =  getSharedPreferences("wlcmscnn", 0);
        int k5 = i5.getInt("wlcmscnn", 0);
        if (k5 != 275) {
            C1.a(this, A17.class);
        } else if (k5 == 275){
            if (sp.getBoolean("lockWn99", false) == true) {
                C1.a(this, A28.class);
            } else if (sp.getBoolean("ptm", false) == true) {
                C1.a(this, A27.class);
            }
        }  
new Thread() {
    public void run() {
c116();
}
}.start();

    }

    @SuppressWarnings("deprecation")
    protected void onResume() {
        System.gc();
        super.onResume();
        try {

SharedPreferences c56 = getSharedPreferences("MyURL", 0);
            SharedPreferences.Editor d56 = c56.edit();
            d56.putString("MyURL", h.getUrl());
            d56.apply();
           c15(h, h.getSettings());
           c102();
           bl = true;
           bl2 = true;
           c6();
                    V1.a(this, R.anim.h, findViewById(R.id.g20));

           IntentFilter ift = new IntentFilter();
           ift.addAction("android.net.conn.CONNECTIVITY_CHANGE");
           ift.addAction("android.net.wifi.WIFI_STATE_CHANGED");
           registerReceiver(br, ift);
           registerReceiver(br2, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
           registerReceiver(br1, new IntentFilter("android.intent.action.AIRPLANE_MODE"));
           invalidateOptionsMenu(); 
           on = getResources().getConfiguration().orientation;
           File fe = new File(I3.a()+"/WebView/.cache/a.cache");
           if (sp.getBoolean("webviewB", false) == true) {
               if (fe.exists()) {
                   back23.setBackground(new BitmapDrawable(getResources(), BitmapFactory.decodeFile(I3.a() + "/WebView/.cache/a.cache"))); 
               }
           }
           if (sp.getBoolean("home", true) == true) {
               tv1.setVisibility(View.VISIBLE);
                   tv1.setImageResource(R.drawable.a12);
               tv1.setOnClickListener(new C9() {
                   public void a(View v) {
                       c51();
                   }
               });
           } else {
                tv1.setVisibility(View.GONE);
           }
           if (sp.getBoolean("voice", true) == true) {
               if (c101() == true) {
                   tv2.setVisibility(View.VISIBLE);
                   tv2.setImageResource(R.drawable.f); 
                   tv2.setOnClickListener(new C9() {
                       public void a(View v) {
                           c29();
                       }
                   });
                } else {
                   tv2.setVisibility(View.GONE);
                }  
           } else {
                tv2.setVisibility(View.GONE);
           }
           if (g.getProgress() >= 100) {
               tv3.setImageResource(R.drawable.b11); 
               tv3.setOnClickListener(new C9() {
                  public void a(View v) {
                      h.reload();
                  }
               });
           } else {
               tv3.setImageResource(R.drawable.b13); 
               tv3.setOnClickListener(new C9() {
                  public void a(View v) {
                      h.stopLoading();
                  }
               });
           }
           onNewIntent(getIntent());
               if (sp.getBoolean("webP", false) == true) {
                   WebView.setWebContentsDebuggingEnabled(true);
               } else {
                    WebView.setWebContentsDebuggingEnabled(false);
               }
           if (sp.getBoolean("blockSV", true) == true) {
               getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
           } else {
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
           }
           c99();
           c108();
        } catch (Exception ex) { 
            U1.a(ex);
        }
    }

protected void onPause() {

super.onPause();
 try {


unregisterReceiver(br);
unregisterReceiver(br1);
unregisterReceiver(br2);

 d1.d();
d2.d();
d3.d();
  } catch (Exception ex) { 
U1.a(ex);
        }
}
protected void onStop() {

        super.onStop();
        bl = false;
        
    }
protected void onDestroy() {
        if(timer != null) {
          timer.cancel();
          timer = null;
        }
bl2= false;
hr.removeCallbacks(rn);

super.onDestroy();

}

    public void c2() {
        if (h.canGoForward()) {
            h.goForward();
        }
    }

    private void c3(String a) {
        if (sp.getBoolean("dont", true) == true) {
            h.loadUrl(a,eh);
        } else {
            h.loadUrl(a);
        }
    }

    public void c4(WebView a5, Message b, Message c) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
        a.setTitle(getString(R.string.g36));
        a.setMessage(getString(R.string.g34)); 
        a.setPositiveButton(getString(R.string.g36), new C6() {
            public void a(DialogInterface a, int b) { 
                h.reload();
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    public static boolean c5(File a) {
        if (a != null && a.isDirectory()) {
            String[] children = a.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = c5(new File(a, children[i]));
                if (!success) {
                    return false;
                }
            }
            return a.delete();
        } else if (a!= null &&a.isFile()) {
            return a.delete();
        } else {
            return false;
        }
    }

    public void c6() {

        File a = new File(I3.a() + "/WebView/Downloads");
        File b = new File(I3.a() + "/WebView/Source Code");
        File c = new File(I3.a() + "/WebView/.log");


        File e = new File(I3.a() + "/WebView/Screenshot");
        File f = new File(I3.a() + "/WebView/.cache");
        File g = new File(I3.a() + "/WebView/Backup");
        if (!a.exists()) {
            a.mkdirs();
        }
        if (!b.exists()) {
            b.mkdirs();
        }
        if (!c.exists()) {
            c.mkdirs();
        }

        if (!e.exists()) {
            e.mkdirs();
        }
        if (!f.exists()) {
            f.mkdirs();
        }
        if (!g.exists()) {
            g.mkdirs();
        }
  

    }

    public void c7(String a) {
        W1.c(this, a);
    }

    public void c8(String a) {
        W1 .b(this, a);
    }

    public void c11(final String a1, String a2, final String a3, Long a4, final DownloadManager.Request a5, final String a6) {
 
        try {
c6();
             
            String b = URLUtil.guessFileName(a1, a2, a3);
            AlertDialog.Builder c =  new AlertDialog.Builder(A21.this);
            LayoutInflater d = getLayoutInflater();
            View e = d.inflate(R.layout.j, null);
            c.setCancelable(true); 
            c.setTitle(getString(R.string.l5));
            c.setView(e);
            TextView f = (TextView) e.findViewById(R.id.a5);
            this.s = (EditText) e.findViewById(R.id.d1);
            TextView h = (TextView) e.findViewById(R.id.d2);
            TextView i = (TextView) e.findViewById(R.id.d3);
         final   TextView j = (TextView) e.findViewById(R.id.d4);
            TextView k = (TextView) e.findViewById(R.id.b9);
            TextView l = (TextView) e.findViewById(R.id.c11);
            TextView m = (TextView) e.findViewById(R.id.c12);
            TextView j2 = (TextView) e.findViewById(R.id.e8);
            TextView j3 = (TextView) e.findViewById(R.id.e9);
            TextView j4 = (TextView) e.findViewById(R.id.e10);
            TextView j5 = (TextView) e.findViewById(R.id.e11);
            TextView j6 = (TextView) e.findViewById(R.id.e12);
            TextView j7 = (TextView) e.findViewById(R.id.e13);
            Context n = A21.this;
            String o = Formatter.formatFileSize(n, a4);
            long a45 = new File(getExternalFilesDir(null).toString()).getFreeSpace();
            long b79 = new File(getExternalFilesDir(null).toString()).getTotalSpace();
            String o1 = Formatter.formatFileSize(n, a45);
            String o3 = Formatter.formatFileSize(n, b79);

            f.setText(getString(R.string.c30));
            this.s.setText(b);
            k.setText(getString(R.string.d40));
            h.setText(o + " (" + a4 + "B)");
            l.setText(getString(R.string.e21));
            i.setText(a1);
            m.setText(getString(R.string.c31));
            j.setText("/Internal Storage/WebView/Downloads/"+b);
            j2.setText(getString(R.string.e22));
            j3.setText(o1 + " ("+ a45+"B)");
            j4.setText(getString(R.string.e23));
            long jj = a45-a4;
            String o2 = Formatter.formatFileSize(n, jj);
            j5.setText(o2+" ("+jj+"B)");
            j6.setText(getString(R.string.e24));
            j7.setText(o3+" ("+b79+"B)");
            if (sp.getBoolean("autoUpdate", false) == false) {
                f.setTextColor(this.a7);
                k.setTextColor(this.a7);
                l.setTextColor(this.a7);
                m.setTextColor(this.a7);
                this.s.setTextColor(this.a7);
                h.setTextColor(this.a7);
                i.setTextColor(this.a7);
                j.setTextColor(this.a7);
                j2.setTextColor(this.a7);
                j3.setTextColor(this.a7);
                j4.setTextColor(this.a7);
                j5.setTextColor(this.a7);
                j6.setTextColor(this.a7);
                j7.setTextColor(this.a7);
            } else {
                f.setTextColor(this.a8);
                k.setTextColor(this.a8);
                l.setTextColor(this.a8);
                m.setTextColor(this.a8);
                this.s.setTextColor(this.a8);
                h.setTextColor(this.a8);
                i.setTextColor(this.a8);
                j.setTextColor(this.a8);
                j2.setTextColor(this.a8);
                j3.setTextColor(this.a8);
                j4.setTextColor(this.a8);
                j5.setTextColor(this.a8);
                j6.setTextColor(this.a8);
                j7.setTextColor(this.a8);
            }
            c.setPositiveButton(getString(R.string.e25), new C6() {
                public void a(DialogInterface a34, int b1) { 
                    try {
                        final String c = A21.this.s.getText().toString();
if (W13.b(c) == true) {                
                        a5.setTitle(c); 
} else {
 a5.setTitle(getString(R.string.e26));
}
               a5.setMimeType(a3);
                a5.addRequestHeader("cookie", cm1.getCookie(a1));
                a5.addRequestHeader("User-Agent", a6);  
 
a5.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
/*if (Build.VERSION.SDK_INT < 29) {
a5.setVisibleInDownloadsUi(false);
}*/
a5.setDestinationInExternalPublicDir(new StringBuilder(String.valueOf("WebView")).append("/").append("Downloads").toString(),c);
                        ((DownloadManager) A21.this.getSystemService("download")).enqueue(a5);
                        SharedPreferences j988 = A21.this.getSharedPreferences("downLOADS", 0);
                        SharedPreferences.Editor gujh = j988.edit(); 
                        gujh.putString("downLOADS", c);
                        gujh.apply();
                        c8( getString(R.string.e27).replaceAll("%a",c));
                        if (sp.getBoolean("launch", false) == true) {
                                                C1.k(A21.this, "android.intent.action.VIEW_DOWNLOADS");
                      }

  C1.b(A21.this, S8 .class);

c71();


                    } catch (Exception d) {
                   U1.a(d);
                    }
                }
            });
            c.setNegativeButton(getString(R.string.i7), new C6() { 
                public void a(DialogInterface a, int b) { 
                    a.dismiss();
  	            } 
  	        }); 
           final AlertDialog g = c.create();
           this.s.addTextChangedListener(new T6 () {
               private void a() {
                   final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
                   String jhh56 = A21.this.s.getText().toString();
    
            j.setText("/Internal Storage/WebView/Downloads/"+jhh56);
                   String jhh  = A21.this.s.getText().toString().replaceAll(" ","");

                   if (jhh.length() != 0) {
                           File a90 = new File(I3.a() + "/WebView/Downloads/"+jhh56);
                   if (a90.exists()) {
                       A21.this.s.setError(getString(R.string.u19));
                   okButton.setEnabled(false);
                   } else {
okButton.setEnabled(true);
}
                   } else {
                       okButton.setEnabled(false);
                   }

               }
        
               public void c(Editable arg0) {
               }
        
               public void a(CharSequence s, int start, int count, int after) {
               }
        
               public void b(CharSequence s, int start, int before, int count) {
                   a();
               }
           });
           g.show();
           String jhh56  = A21.this.s.getText().toString();
           File a90 = new File(I3.a() + "/WebView/Downloads/"+jhh56);
           if (a90.exists()) {
               A21.this.s.setError(getString(R.string.u19));
               g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
           } else {
               g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
           }
       } catch (Exception haha) {
           U1.a(haha);
       }
    } 

    public void c12() {
        PopupMenu a = new PopupMenu(A21.this, this.u);
	    a.getMenuInflater().inflate(R.menu.d, a.getMenu());

       a.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
		    public boolean onMenuItemClick(MenuItem a) {
	            switch (a.getItemId()) {
                    case R.id.a:
                        c13();
                        return true;
                    case R.id.b:
                        c17();
                        return true;
                    case R.id.c:
                        C2.a(A21.this,h.getUrl()); 
                        c8(getString(R.string.k9));
                        return true;
                }
                return true;
	        }
	    });
	    a.show();
    }
  
    public void c13() {
       try {
 
            String c = C2.b(this);
String d = c.replaceAll(" ", "");
if (d.length() != 0) {
            c49(c);
  c103(c);
} else {
   c7(getString(R.string.t20));
}

} catch (Exception ex) {
   c7(getString(R.string.t20));
}
    }

    public void c14(String a23, String asd) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.z, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.h11));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.f9);
        final EditText ed = (EditText) c.findViewById(R.id.f10);
        final TextView ti1 = (TextView) c.findViewById(R.id.f11);
        final EditText ed1 = (EditText) c.findViewById(R.id.f12);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        
        if (sp.getBoolean("autoUpdate", false) == false) {
           ed.setTextColor(e);
   ed1.setTextColor(e);
 ti.setTextColor(e);
   ti1.setTextColor(e);
        } else {
           ed.setTextColor(f);
   ed1.setTextColor(f);
 ti.setTextColor(f);
   ti1.setTextColor(f);
        }
ti.setText(getString(R.string.t3));
ti1.setText(getString(R.string.t4));
if (a23 != null) {
   ed.setText(a23);
} else {
Uri hl = Uri.parse(asd);
ed.setText(hl.getHost());
}
   ed1.setText(asd);
        a.setPositiveButton(getString(R.string.i6), new C6() { 
            public void a(DialogInterface a2, int b) { 
            
d3.c(ed.getText().toString(),ed1.getText().toString());
c8(getString(R.string.t2));
  	        } 
  	    });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
      ed.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  ed1.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
String azx  = ed.getText().toString().replaceAll(" ","");
String aqw  = ed1.getText().toString().replaceAll(" ","");
       if ( azx.length() != 0 && aqw.length() != 0) {
 g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); 
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }

    @SuppressWarnings("deprecation")
    private void c15(WebView h, WebSettings ws) {
        if (sp.getString("setLT", "").length() == 0) {
                h.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        if (sp.getString("setLT", "").equals("1l")) {
                h.setLayerType(View.LAYER_TYPE_NONE, null);
        }
        if (sp.getString("setLT", "").equals("7l")) {
                h.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        if (sp.getString("setLT", "").equals("30l")) {
                h.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        if (Build.VERSION.SDK_INT >= 26) {
            if (sp.getString("renderP", "").length() == 0) {
                h.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
            }
            if (sp.getString("renderP", "").equals("1s")) {
                h.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
            }
            if (sp.getString("renderP", "").equals("7s")) {
                h.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
            }
            if (sp.getString("renderP", "").equals("30s")) {
                h.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_WAIVED, true);
            }
        }

            SharedPreferences g = getApplicationContext().getSharedPreferences("dr", 0);
            if (g.getInt("dr", 0) == 0) {
                ws.setTextZoom(new WebView(this).getSettings().getTextZoom());
            } else {
                ws.setTextZoom(g.getInt("dr", 0));
            }
        int it2 = getApplicationContext().getSharedPreferences("dr55", 0).getInt("dr55", 0);
if (it2 == 0) {
ws.setDefaultFontSize(new WebView(this).getSettings().getDefaultFontSize());
 
} else {
ws.setDefaultFontSize(it2);
 
}

        if (sp.getBoolean("open", false) == true) {
            ws.setLoadWithOverviewMode(true);
        } else {
            ws.setLoadWithOverviewMode(false);
        }
        if (sp.getBoolean("open1", false) == true) {
            ws.setUseWideViewPort(true);
        } else {
            ws.setUseWideViewPort(false);
        }
        if (sp.getBoolean("open2", true) == true) {
            ws.setDomStorageEnabled(true);
        } else {
            ws.setDomStorageEnabled(false);
        }  
        if (sp.getBoolean("open3", true) == true) {
            ws.setDatabaseEnabled(true);
        } else {
            ws.setDatabaseEnabled(false);
        }
        if (Build.VERSION.SDK_INT >= 26) {
            if (sp.getBoolean("save", true) == true) {
                ws.setSafeBrowsingEnabled(true);
            } else {
                ws.setSafeBrowsingEnabled(false);
            }
        }
        if (sp.getBoolean("block", false) == true) {
            ws.setBlockNetworkImage(true);
            ws.setLoadsImagesAutomatically(false);
        } else {
            ws.setBlockNetworkImage(false);
            ws.setLoadsImagesAutomatically(true);
        }
        if (sp.getBoolean("zoom", false) == true) {
            ws.setDisplayZoomControls(true);
        } else {
            ws.setDisplayZoomControls(false);
        }
        if (sp.getBoolean("auto", false) == true) {
            ws.setMediaPlaybackRequiresUserGesture(true);
        } else {
            ws.setMediaPlaybackRequiresUserGesture(false);
        }
        if (sp.getBoolean("enableZ", true) == true) {
            ws.setSupportZoom(true);
        } else {
            ws.setSupportZoom(false);
        }
        if (sp.getString("cookies", "").length() == 0) {
               cm1.setAcceptThirdPartyCookies(h, true);
           cm1.setAcceptCookie(true);
        }
        if (sp.getString("cookies", "").equals("1")) {
            cm1.setAcceptCookie(true);
cm1.setAcceptThirdPartyCookies(h, false);

        }
        if (sp.getString("cookies", "").equals("7")) {
cm1.setAcceptThirdPartyCookies(h, true);
            cm1.setAcceptCookie(true);
        }
        if (sp.getString("cookies", "").equals("30")) {
            cm1.setAcceptCookie(false);
cm1.setAcceptThirdPartyCookies(h, false);
        }
        if (sp.getString("cookies", "").equals("60")) {
            cm1.setAcceptCookie(true);
cm1.setAcceptThirdPartyCookies(h, true);
cm1.allowFileSchemeCookies();
        }
        if (sp.getString("java", "").length() == 0) {
            ws.setJavaScriptEnabled(true);
        }
        if (sp.getString("java", "").equals("1f")) {
            ws.setJavaScriptEnabled(true);
        }
        if (sp.getString("java", "").equals("7f")) {
            ws.setJavaScriptEnabled(false);
        }
        if (sp.getString("mcm", "").length() == 0) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        if (sp.getString("mcm", "").equals("1r")) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        if (sp.getString("mcm", "").equals("7r")) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        if (sp.getString("mcm", "").equals("30r")) {
            ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (sp.getString("textE", "").length() == 0) {
            ws.setDefaultTextEncodingName(new WebView(this).getSettings().getDefaultTextEncodingName());
        }
        if (sp.getString("textE", "").equals("1a")) {
            ws.setDefaultTextEncodingName(new WebView(this).getSettings().getDefaultTextEncodingName());
        }
        if (sp.getString("textE", "").equals("7a")) {
            ws.setDefaultTextEncodingName("ISO-8858-1");
        }
        if (sp.getString("textE", "").equals("30a")) {
            ws.setDefaultTextEncodingName("UTF-8");
        }
        if (sp.getString("textE", "").equals("60a")) {
            ws.setDefaultTextEncodingName("GBK");
        }
        if (sp.getString("textE", "").equals("120a")) {
            ws.setDefaultTextEncodingName("Big5");
        }
        if (sp.getString("textE", "").equals("240a")) {
            ws.setDefaultTextEncodingName("ISO-2022-JP");
        }
        if (sp.getString("textE", "").equals("480a")) {
            ws.setDefaultTextEncodingName("SHIFT_JIS");
        }
        if (sp.getString("textE", "").equals("960a")) {
            ws.setDefaultTextEncodingName("EUC-JP");
        }
        if (sp.getString("textE", "").equals("1920a")) {
            ws.setDefaultTextEncodingName("EUC-KR");
        }
        if (sp.getString("textE", "").equals("3840a")) {
            ws.setDefaultTextEncodingName(sp.getString("CtextE",""));
        }

        if (sp.getString("form", "").length() == 0) {
            ws.setSaveFormData(true);
        }
        if (sp.getString("form", "").equals("1g")) {
            ws.setSaveFormData(true);
        }
        if (sp.getString("form", "").equals("30g")) {
            ws.setSaveFormData(false);
        }
        if (sp.getString("location", "").length() == 0) {
            ws.setGeolocationEnabled(true);
            if (Build.VERSION.SDK_INT < 24) {
                ws.setGeolocationDatabasePath(getFilesDir().getPath());
            }
        }
        if (sp.getString("location", "").equals("1h")) {
            ws.setGeolocationEnabled(true);
            if (Build.VERSION.SDK_INT < 24) {
                ws.setGeolocationDatabasePath(getFilesDir().getPath());
            }
        }
        if (sp.getString("location", "").equals("30h")) {
            ws.setGeolocationEnabled(false);
        }
        if (sp.getBoolean("open4", true) == true) {
            ws.setAppCacheEnabled(true);
            ws.setAppCachePath(getCacheDir().getAbsolutePath());
        } else {
            ws.setAppCacheEnabled(false);
        }
        if (sp.getString("caches", "").length() == 0){
            ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        }
        if (sp.getString("caches", "").equals("1m")){
            ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        }
        if (sp.getString("caches", "").equals("7m")) {
            ws.setCacheMode(WebSettings.LOAD_CACHE_ONLY);
        }
        if (sp.getString("caches", "").equals("30m")) {
            ws.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        }
        if (sp.getString("caches", "").equals("60m")) {
            ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        }
    }

    public void c16(String a, int c) {
        Intent b = new Intent("android.intent.action.SEND");
        b.setType("text/plain");
        b.putExtra("android.intent.extra.TEXT", a);
if (c == 0) {
        startActivity(Intent.createChooser(b, "Share \""+ h.getTitle()+ "\" with:"));
} else {
        startActivity(Intent.createChooser(b, "Share \""+a+ "\" with:"));
}
    }

    public void c17() {
       
            try {
            String c = C2.b(this);
String dy = c.replaceAll(" ", "");
if (dy.length() != 0) {
           

C1.h(this, A21.this, A2.class, 911, "value", c);
overridePendingTransition(R.anim.f, R.anim.d);

} else {
   c7(getString(R.string.t20));
}
} catch (Exception ex) {
   c7(getString(R.string.t20));
}
    }

    public void c20(final boolean a) {
        String c = new String();
        if (a == true) {
            c = ws.getUserAgentString().replace("Mobile", "eliboM").replace("Android", "diordnA");
        } else {
            c = ws.getUserAgentString().replace("eliboM", "Mobile").replace("diordnA", "Android");
    }
    ws.setUserAgentString(c);
    h.reload();
    }

    public void c22() {
        try {
            String st = new String();

if (h.getUrl() != null) {
st =  h.getUrl();
} else {
st = " ";
}
	
C1.h(this, this, A2.class, 911, "value",st);
overridePendingTransition(R.anim.f, R.anim.d);
   
        } catch (Exception ex) {

        }
    }

 

    public void c25() {
        
 
        if (sp.getBoolean("clearP", false) == true) {
            c5(new File(I3.c()));
        }
        if (sp.getBoolean("clearH", false) == true) {
            c63();
File fl = new File(U4.a("Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMvYS5kYg=="));
                if (fl.exists()) {
                    fl.delete();
}
        }
        if (sp.getBoolean("clearC", false) == true) {
            C2.a(this," ");
        }
        if (sp.getBoolean("clearPr", false) == true) {
            c31();
if (wd.hasHttpAuthUsernamePassword()) {
       wd.clearHttpAuthUsernamePassword();
}
        if (Build.VERSION.SDK_INT <= 26 && wd.hasFormData()) {
        wd.clearFormData();
        }
        }
    }

    public void c29() {
        Intent a = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        a.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        a.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        a.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.k10)); 
if (a.resolveActivity(getPackageManager()) != null) { 
startActivityForResult(a, 742);
}
}

    public void c31() {
        h.clearSslPreferences();
    }

    public void c33(String url, String b) {
       try {
           if (sp.getBoolean("showW", false) == false)  {
              c35(new SpannableStringBuilder(url), url, 0);
           } else {
              c35(new SpannableStringBuilder(b + " - " +url), url, b.length()+3);
           }
       } catch (Exception ex) {
           U1.a(ex);
       }
    }


    private void c34(WebView j, WebSettings ws) {
        ws.setSupportMultipleWindows(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setBuiltInZoomControls(true);
        registerForContextMenu(h);
        h.setWebChromeClient(new W21());
        h.setWebViewClient(new W12());
        h.addJavascriptInterface(new W8(getApplicationContext()), getString(R.string.p20));
        h.setGestureDetector(new GestureDetector(getApplicationContext(),new V4()));
    }

    private void c35(SpannableStringBuilder ssb, String url, int it) {
        try {
            if (url.startsWith("https://")) { 
                ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.s)), it, it+8, 0);
            } else if (url.startsWith("http://")) {
                ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.e)), it, it+7, 0);
            } else if (url.startsWith("file://")) {
                if (sp.getBoolean("autoUpdate", false) == false) {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.i)), it, it+7, 0);
                } else {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.b)), it, it+7, 0);
                }
            } else if (url.startsWith("content://")) {
                if (sp.getBoolean("autoUpdate", false) == false) {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.i)), it, it+10, 0);
                } else {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.b)), it, it+10, 0);
                }
            } else {
                if (sp.getBoolean("autoUpdate", false) == false) {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.i)), it, url.length(), 0);
                } else {
                    ssb.setSpan(new ForegroundColorSpan(C5.b(this, R.color.b)), it, url.length(), 0);
                }
            }
            this.u.setText(ssb, BufferType.SPANNABLE);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void c37(String a, String c) { 
try {
        Intent e = new Intent("com.android.DROID_MJ.webview.intent.action.LAUNCH"); 
        e.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
        if (sp.getBoolean("dup", false) == true) {
            e.putExtra("duplicate", true);
        } else {
            e.putExtra("duplicate", false);
        }
        e.putExtra("webview", c);
        Intent f = new Intent();
        f.putExtra("android.intent.extra.shortcut.INTENT", e); 
        f.putExtra("android.intent.extra.shortcut.NAME", a);
        if (h.getFavicon() != null) {
            BitmapDrawable d45 = new BitmapDrawable(getResources(), h.getFavicon());
            f.putExtra("android.intent.extra.shortcut.ICON", d45.getBitmap());
        } else {
            f.putExtra("android.intent.extra.shortcut.ICON_RESOURCE",
ShortcutIconResource.fromContext(this, R.mipmap.f));
        } 
        if (sp.getBoolean("dup", false) == true) {
            f.putExtra("duplicate", true);
        } else {
            f.putExtra("duplicate", false);
        } 
        f.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        sendBroadcast(f);
        C11.a(this, "com.android.DROID_MJ.webview.intent.action.INSTALL_SHORTCUT");
} catch (Exception et) { W1.e(this, getString(R.string.a36),2); }
    }

    public void c38(String a) {
        try {

            if (sp.getString("cookies", "").equals("120")) {

                if (a.startsWith("https://")) {
                    cm1.setAcceptCookie(true);
 cm1.setAcceptThirdPartyCookies(h, true);

                } else {
                    cm1.setAcceptCookie(false);
                        cm1.setAcceptThirdPartyCookies(h, false);
                }
            }
            if (sp.getString("java", "").equals("30f")) {
                if (a.startsWith("https://")) {
                    ws.setJavaScriptEnabled(true);
                } else {
                    ws.setJavaScriptEnabled(false);
                }
            }
            if (sp.getString("form", "").equals("7g")) {
                if (a.startsWith("https://")) {
                    ws.setSaveFormData(true);
                } else {
                    ws.setSaveFormData(false);
                }
            }
            if (sp.getString("location", "").equals("7h")) {
                if (a.startsWith("https://")) {
                    ws.setGeolocationEnabled(true);
                    if (Build.VERSION.SDK_INT <=24) {
                        ws.setGeolocationDatabasePath(getFilesDir().getPath());
                    }
                } else {
                   ws.setGeolocationEnabled(false);
                }       
            }
        } catch (Exception ex) {
U1.a(ex);
        }
    }

    public void c39(int a, String b, String c, CharSequence d) {

            final AlertDialog.Builder e =  new AlertDialog.Builder(this);


            e.setCancelable(true);
            e.setTitle(getString(R.string.e1));
            String sg = getString(R.string.v20);
            String sg1 = sg.replace("%a", Integer.toString(a));
            String sg2 = sg1.replace("%c", c);
            if (Build.VERSION.SDK_INT >= 23) {
                e.setMessage(sg2.replace("%b", d.toString()));
            } else {
                e.setMessage(sg2.replace("%b", b));
            }
            e.setPositiveButton(getString(R.string.i6), new C6() {
                public void a(DialogInterface a, int b) { 
                    a.dismiss();
                } 
   	        });
            e.create().show();
        
    }

    public void c41() {
        

        if (sp.getString("remind", "").length() == 0) {
            timeset = 3600000;
        }
        if (sp.getString("remind", "").equals("1k")) {
            if (timer != null) {
                timer.cancel();
                timer = null;
            }
        }
        if (sp.getString("remind", "").equals("7k")) {
            timeset = 900000;
        }
        if (sp.getString("remind", "").equals("30k")) {
            timeset = 1800000;
        }
        if (sp.getString("remind", "").equals("60k")) {
            timeset = 3600000;
        }
        timer = new O2(timeset, timeset);
        timer.start();
    }
    
    public void c42() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true); 
        a.setTitle(getString(R.string.w2)); 
 a.setMessage(getString(R.string.w1).replaceAll("%a", Integer.toString(timeset/60000))); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface dialog, int which) { 
                c41(); 
            } 
   	    });
a.setOnDismissListener(new C13(){
    public void a(DialogInterface a) {
        c41();
    }
});
        a.create().show();
        if(timer != null) {
          timer.cancel();
          timer = null;
        }
    }

    public void c43(String url) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b8, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.h6));
        a.setView(c);
        final EditText ed = (EditText) c.findViewById(R.id.g8);
        final TextView ti = (TextView) c.findViewById(R.id.e2);
        final Button bn = (Button) c.findViewById(R.id.k20);

        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
bn.setTextColor(e);
            ti.setTextColor(e);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f);
bn.setTextColor(f);
        }
        ed.setText(Uri.parse(url).getHost());
        if (URLUtil.isValidUrl(url)) {
            ti.setText(U5.a(url));
        } else if (W13.a(url) == true) {
            ti.setText(U5.a("http://"+url));
        }
        bn.setText(getString(R.string.i6));
bn.setBackgroundResource(R.drawable.e20);
        bn.setOnClickListener(new C9() {
            public void a(View v) {
                 String ab = ed.getText().toString();
                 if (URLUtil.isValidUrl(ab)) {
                     ti.setText(U5.a(ab));
                 } else if (W13.a(ab) == true) {
                     ti.setText(U5.a("http://"+ab));
                 }
            }
        });
        final AlertDialog g = a.create();
        g.show();
    }
    

    public void c47() {

        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b19, null);
        a.setTitle(getString(R.string.h4));
        a.setCancelable(true); 
        a.setView(c);
        final TextView ed = (TextView) c.findViewById(R.id.l8);  
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(C5.b(this,R.color.c));
        } else {
            ed.setTextColor(C5.b(this,R.color.b));
        }
        ed.setText(cm.toString());
        final AlertDialog g = a.create();
        g.show();
    }

    public void c48() {
       
       if (sp.getString("searchP", "").length() == 0) {
           c3("https://google.com");
       } else if (sp.getString("searchP", "").startsWith("1b")) {
           c3("https://duckduckgo.com");
       } else if (sp.getString("searchP", "").equals("7b")) {
           c3("https://google.com");
       } else if (sp.getString("searchP", "").equals("30b")) {
           c3("https://bing.com");
       } else if (sp.getString("searchP", "").equals("60b")) {
           c3("https://yahoo.com");
       } else if (sp.getString("searchP", "").equals("120b")) {
           c3("https://ask.com");
       } else if (sp.getString("searchP", "").equals("240b")) {
           c3("https://aol.com");
       } else if (sp.getString("searchP", "").equals("480b")) {
           c3("https://baidu.com");
       } else if (sp.getString("searchP", "").equals("860b")) {
           c3("https://wolframalpha.com");
       } else if (sp.getString("searchP", "").equals("1720b")) {
           c3("https://freebasics.com");
       } else if (sp.getString("searchP", "").equals("3440b")) {
           c3("https://ecosia.org");
       } else if (sp.getString("searchP", "").equals("6880b")) {
           c3("https://stackoverflow.com");
       }
    }

     public void c49(String a) {
        String a5 = a.replaceAll(" ", "");
        if (a5.length() == 0) {
            return;
        } 
        if (URLUtil.isValidUrl(a5)) {
            if (a5.startsWith("file://")) {
                if (W13.n(a5) == true) {
                    c124(a);
                } else {
                    h.loadUrl(a);
                }
            } else {
                if (W13.a(a5) == true) {
                    c3(a);
                } else {
                    c124(a);
                }
            }
        } else if (W13.a(a5) == true) {
            c3("http://"+a);
        } else {
            c124(a);
        }
    }


    public void c50() {      
        SharedPreferences a4 =  getSharedPreferences("MyURL", 0);
        String a20 = a4.getString("MyURL", new String());
        if (sp.getBoolean("tab", false) == true) {
            if (a20 != null) {
                c3(a20);
            } else {
                c51();
            }
        } else {
            c51();
        }
    }

    public void c51() {
        
        SharedPreferences c6 = getSharedPreferences("MyURL", 0);
        String jk = sp.getString("cGeneral", "");
        String a201 = c6.getString("MyURL", new String());
        if (sp.getString("general", "").length() == 0) {
            c48();
        } else if (sp.getString("general", "").equals("1o")) {
            c48();
        } else if (sp.getString("general", "").equals("7o")) {
            if (a201 != null) {
                c3(a201);
            } else {
                c48();
            }
        } else if (sp.getString("general", "").equals("30o")) {
            c3("about:blank");
        } else if (sp.getString("general", "").equals("60o")) {
            if (jk.length() != 0) {
                c49(jk);
            } else {
                c48();
            }
        }
    }


    private void c53(String jk) {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.p20));
        a.setMessage(jk);
        a.setPositiveButton(getString(R.string.u14), new C6() {
            public void a(DialogInterface a, int b) {
Intent intent = new Intent();
    
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", U4.a(W5.a10()), null);
        intent.setData(uri);
startActivity(intent);
               a.dismiss();
            }
        });
        a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) {
               a.dismiss();
            }
        });
        a.create().show();
    }

    public void c54(String a) {
        if (a.startsWith("https://")) {
            iw.setImageResource(R.drawable.a15);
        } else if (a.startsWith("http://")) {
            iw.setImageResource(R.drawable.a16);
        } else if (a.startsWith("file://") || a.startsWith("content://")) {
            iw.setImageResource(R.drawable.a17);
        } else {
            iw.setImageResource(R.mipmap.f);
        }
    }

    public void c55(String a23, String asd) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.z, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.l5));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.f9);
        final EditText ed = (EditText) c.findViewById(R.id.f10);
        final TextView ti1 = (TextView) c.findViewById(R.id.f11);
        final EditText ed1 = (EditText) c.findViewById(R.id.f12);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
         
        if (sp.getBoolean("autoUpdate", false) == false) {
           ed.setTextColor(e);
   ed1.setTextColor(e);
 ti.setTextColor(e);
   ti1.setTextColor(e);
        } else {
           ed.setTextColor(f);
   ed1.setTextColor(f);
 ti.setTextColor(f);
   ti1.setTextColor(f);
        }
ti.setText(getString(R.string.t3));
ti1.setText(getString(R.string.t4));
if (asd != null) {
   ed.setText(asd);
} else {
Uri hl = Uri.parse(a23);
ed.setText(hl.getHost()+".htm");
}
   ed1.setText(a23);
        a.setPositiveButton("Start", new C6() { 
            public void a(DialogInterface a2, int b) { 
            a2.dismiss();

  c62(ed.getText().toString(),ed1.getText().toString());
  	           
 } 
  	    });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
      ed.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
File file = new File(I3.a() + "/WebView/Downloads/"+jhh);
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
        if (file.exists()) {
ed.setError(getString(R.string.u19));
okButton.setEnabled(false);
} else {
                    okButton.setEnabled(true);
}
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  ed1.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
String azx  = ed.getText().toString().replaceAll(" ","");
String aqw  = ed1.getText().toString().replaceAll(" ","");
File file = new File(I3.a() + "/WebView/Downloads/"+azx);
       if ( azx.length() != 0 && aqw.length() != 0) {
        if (file.exists()) {
ed.setError(getString(R.string.u19));
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
} else {
 g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); 
}
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }

    public void c56(String a) {
        if (Build.VERSION.SDK_INT >=23) {
   if (a.startsWith("file://")) {
            if (M2.a(this, M2.STORAGE, 2) == true) {
               }
            }
        }
    }

   public void c57(String url) {
       SpannableStringBuilder xjendndj = new SpannableStringBuilder(url); 
       xjendndj.setSpan(new ForegroundColorSpan(Color.parseColor("#ea4335")), 0, 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
       this.u.setText(xjendndj);
    }

    public void c58(String a23, String asd) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.z, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.h12));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.f9);
        final EditText ed = (EditText) c.findViewById(R.id.f10);
        final TextView ti1 = (TextView) c.findViewById(R.id.f11);
        final EditText ed1 = (EditText) c.findViewById(R.id.f12);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
         
        if (sp.getBoolean("autoUpdate", false) == false) {
           ed.setTextColor(e);
   ed1.setTextColor(e);
 ti.setTextColor(e);
   ti1.setTextColor(e);
        } else {
           ed.setTextColor(f);
   ed1.setTextColor(f);
 ti.setTextColor(f);
   ti1.setTextColor(f);
        }
ti.setText(getString(R.string.t3));
ti1.setText(getString(R.string.t4));
if (asd != null) {
   ed.setText(asd);
} else {
Uri hl = Uri.parse(a23);
ed.setText(hl.getHost());
}
   ed1.setText(a23);
        a.setPositiveButton(getString(R.string.i6), new C6() { 
            public void a(DialogInterface a2, int b) { 
             c37(ed.getText().toString() ,ed1.getText().toString());
  	        } 
  	    });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
      ed.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
  ed1.addTextChangedListener(new T6 () {
            private void a() {
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
String jhh1  = ed1.getText().toString().replaceAll(" ","");
     if (jhh.length() != 0) {
                if (jhh1.length() != 0) {
                    okButton.setEnabled(true);
                } else {
                    okButton.setEnabled(false);
                }
} else {
okButton.setEnabled(false);
}
            }
        
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
String azx  = ed.getText().toString().replaceAll(" ","");
String aqw  = ed1.getText().toString().replaceAll(" ","");
       if ( azx.length() != 0 && aqw.length() != 0) {
 g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); 
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }

    public void c60(WebView view, WebResourceRequest wde5, int type5, final SafeBrowsingResponse sbh) {
        if (sp.getBoolean("safe", true) == true) {
sbh.showInterstitial(false);
        if (sp.getBoolean("safeDG", true) == true) {

            String type = getString(R.string.i23);
            String wde = getString(R.string.i28);
            switch (type5) {
                case 0:
                    type = getString(R.string.i23);
                    wde = getString(R.string.i28);
                break;
                case 1:
                    type = getString(R.string.i24);
                    wde = getString(R.string.i29);
                break;
                case 2:
                    type = getString(R.string.i25);
                    wde = getString(R.string.i30);
                break;
                case 3:
                    type = getString(R.string.i26);
                    wde = getString(R.string.i31);
                break;
                case 4:
                    type = getString(R.string.i27);
                    wde = getString(R.string.i32);
                break;
            }
            AlertDialog.Builder a = new AlertDialog.Builder(this);
            a.setCancelable(false);
            a.setTitle(getString(R.string.h40));
            a.setMessage(getString(R.string.h39).replace("%a", Uri.parse(view.getUrl()).getHost()).replace("%b", wde).replace("%c", type));
            a.setPositiveButton(getString(R.string.i21), new C6() {
                public void a(DialogInterface a, int b) {
                    sbh.backToSafety(true);
                }
            });
            a.setNegativeButton(getString(R.string.i22), new C6() {
                public void a(DialogInterface a, int b) {
                    sbh.proceed(true);
                }
            });

            a.create().show();
        } else {
            sbh.backToSafety(true);
        }
        } else {
            sbh.proceed(true);
        }
    }
 
    public void c62(String a, String b5) {
 
Intent it = new Intent(this, S1.class);
it.putExtra("a", a);
it.putExtra("b", b5);
 startService(it);
 
}
 public void c63() {
bl4 = true;
}
public void c65(String c) {
        Intent a = new Intent();
        if (c.startsWith("mailto:")) {
           a = new Intent(Intent.ACTION_SENDTO, Uri.parse(c));
       } else {
          a = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" +c)); 
       }
        a.putExtra(Intent.EXTRA_SUBJECT, "");
        a.putExtra(Intent.EXTRA_TEXT, "");
if (a.resolveActivity(getPackageManager()) != null) { 
startActivity(Intent.createChooser(a, getString(R.string.a26)));
} else {
W1.c(this, getString(R.string.f34));
}
}
  public void c67() {
    
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.h7));
        LayoutInflater d = getLayoutInflater();
        View e = d.inflate(R.layout.b4, null);
        a.setView(e);
        final TextView f = (TextView) e.findViewById(R.id.x); 
        TextView f5 = (TextView) e.findViewById(R.id.c20);
         Button bn = (Button) e.findViewById(R.id.k12);
 f5.setText(getString(R.string.o7));
 
  f.setText(U6.b(U4.a(W5.w())));
 bn.setText(getString(R.string.h14));
 
  if (sp.getBoolean("autoUpdate", false) == false) {
bn.setTextColor(C5.b(this,R.color.c));
f.setTextColor(C5.b(this,R.color.c));
f5.setTextColor(C5.b(this,R.color.c));
           } else{
f.setTextColor(C5.b(this,R.color.b));
f5.setTextColor(C5.b(this,R.color.b));

bn.setTextColor(C5.b(this,R.color.b));
}
bn.setBackgroundResource(R.drawable.e20);
bn.setOnClickListener(new C9() {
            public void a(View v) {
                f.setText(U6.b(U4.a(W5.w())));
            }
        });
       
        AlertDialog dd = a.create();
dd.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
dd.show();

    } 

    private void c68(LinearLayout a) {
        String h = new String();
        int it0 = 100;
        try {
            
            if (sp.getString("shotQq", "").length() == 0) {
                it0 = 100;
            }
            if (sp.getString("shotQq", "").equals("1w")) {
                it0 = 100;
            }
            if (sp.getString("shotQq", "").equals("7w")) {
                it0 = 95;
            }
            if (sp.getString("shotQq", "").equals("30w")) {
                it0 = 80;
            }
            a.setDrawingCacheEnabled(true);
            Bitmap b = Bitmap.createBitmap(a.getDrawingCache());
            if (sp.getString("shotSs", "").length() == 0) {
                h = I3.a() + "/WebView/Screenshot/"+"Screenshot_" + System.currentTimeMillis() + ".png";
                FileOutputStream c = new FileOutputStream(new File(h));
                c74(CompressFormat.PNG, it0, c, a, h, b);
            }
            if (sp.getString("shotSs", "").equals("1q")) {
                h = I3.a() + "/WebView/Screenshot/"+"Screenshot_" + System.currentTimeMillis() + ".png";
                FileOutputStream c = new FileOutputStream(new File(h));
                c74(CompressFormat.PNG, it0, c, a, h, b);
            }
       
            if (sp.getString("shotSs", "").equals("7q")) {           
                h = I3.a() + "/WebView/Screenshot/"+"Screenshot_" + System.currentTimeMillis() + ".jpeg";
                FileOutputStream c = new FileOutputStream(new File(h));
                c74(CompressFormat.JPEG, it0, c, a, h, b);
            }
            if (sp.getString("shotSs", "").equals("30q")) {
                h = I3.a() + "/WebView/Screenshot/"+"Screenshot_" + System.currentTimeMillis() + ".webp";
                FileOutputStream c = new FileOutputStream(new File(h));
                c74(CompressFormat.WEBP, it0, c, a, h, b);
            }
        } catch (FileNotFoundException e) {
            U1.a(e);
            c7(getString(R.string.w14));
        }  
    }

    private void c74(CompressFormat format, int quality, OutputStream stream, LinearLayout ll, String st, Bitmap bp) {
        try {
            bp.compress(format, quality, stream);
            stream.flush();
            stream.close();
            ll.setDrawingCacheEnabled(false);
            c69(st);
            c70(st);
        } catch (FileNotFoundException e) {
            U1.a(e);
            c7(getString(R.string.w14));
        } catch (IOException e56) {
            U1.a(e56);
            c7(getString(R.string.w14));
        }
    }

    private void c69(String a) { 
        Uri contentUri = Uri.fromFile(new File( a));
Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE); 
mediaScanIntent.setData(contentUri);
sendBroadcast(mediaScanIntent);
    }

    private void c70(String a) {
        try {
            Bitmap bit = BitmapFactory.decodeFile(a);
            c8(getString(R.string.w16));
 
            Notification.Builder e = A37.a(this, "b");
                e.setColor(C5.b(this,R.color.a));
            e.setSmallIcon(R.drawable.a13);
            Intent haa = new Intent(this, A4.class);
            haa.putExtra("hajaha", a);
            haa.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(haa);
            e.setLargeIcon(bit);
 
           e.setDefaults(Notification.DEFAULT_ALL); e.setContentTitle(getString(R.string.w15));
            e.setContentText(getString(R.string.w17));
                    
        if (Build.VERSION.SDK_INT < 26) {
            if (sp.getString("py", "").length() == 0) { 
                e.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("1x")) {
                e.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sp.getString("py", "").equals("7x")) {
                e.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sp.getString("py", "").equals("30x")) {
                e.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sp.getString("py", "").equals("60x")) {
                e.setPriority(Notification.PRIORITY_MAX);
            }
            if (sp.getString("py", "").equals("120x")) {
                e.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sp.getString("vy", "").length() == 0) {
                e.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sp.getString("vy", "").equals("1y")) {
                e.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sp.getString("vy", "").equals("7y")) {
                e.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sp.getString("vy", "").equals("30y")) {
                e.setVisibility(Notification.VISIBILITY_SECRET);
            }

e.setPublicVersion(e.build());


            e.setStyle(new Notification.BigPictureStyle().bigPicture(bit).bigLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.a13)));
            Intent f = new Intent(Intent.ACTION_SEND);
            f.setType("image/*");
            f.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://"+a));
            PendingIntent g = PendingIntent.getActivity(this, 0, f,  PendingIntent.FLAG_UPDATE_CURRENT);
            Intent f742 = new Intent();          
        f742.setAction("com.android.DROID_MJ.webview.intent.action.MASTER_DELETE_SCREENSHOT");     
f742.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
       f742.putExtra("a56hj", a); 

PendingIntent g56 = PendingIntent.getBroadcast(this, 2, f742,  PendingIntent.FLAG_UPDATE_CURRENT);
   if (sp.getBoolean("eac", true) == true) {
       e.setAutoCancel(true);
    } else {
       e.setAutoCancel(false);
    }
            Intent j = new Intent(this, A3.class);
            j.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            j.putExtra("a56hj", a);
            PendingIntent k = PendingIntent.getActivity(this, 1, j,  PendingIntent.FLAG_UPDATE_CURRENT);
            e.setContentIntent(k);
            e.addAction(R.drawable.e, getString(R.string.a8),g);
            e.addAction(R.drawable.h, getString(R.string.a13), g56);
        NotificationManager nmc = (NotificationManager) getSystemService("notification");
            nmc.notify(U7.a(U7.NOTIFICATION), e.build());
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    private void c71() {
        final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
        a.setTitle(getString(R.string.p20));
        a.setMessage(getString(R.string.u12)); 
        a.setPositiveButton(getString(R.string.i6), new C6() {
            public void a(DialogInterface a6, int b) { 
                c72();
                }
           });
           a.setNegativeButton(getString(R.string.i7), new C6() {
            public void a(DialogInterface a, int b) { 
                a.dismiss();
            }
        });
        a.create().show();
    } 

    private void c72() {
            Intent a = new Intent();
            a.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            if (a != null) {
                startActivity(a);
            }
    }

    private void c74(String data) {
        try {
            c6();
            
            WifiManager b = (WifiManager) getSystemService(WIFI_SERVICE);
            if (sp.getBoolean("autoD", false) == false) {
                if (URLUtil.isValidUrl(data)){
                    Request f = new Request(Uri.parse(data));
  
                    if (sp.getBoolean("wifi", false) == true) {
                        if (b.isWifiEnabled()) {
                                 
                            if (M2.a(this, M2.STORAGE, 1) == true) {
                                c11(data, data, data, 0L, f, data);
                            }
                        } else {
                            c7(getString(R.string.v12));
                        } 
                    } else {
                        if (M2.a(this, M2.STORAGE, 1) == true) {
                            c11(data, data, data, 0L, f, data);
                        }
                    }
                } else {
                    c111(data);
                }
            } else {
                if (M2.a(this, M2.STORAGE, 1) == true) {
                   // auto download
                }
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void c75() {
        String url = h.getUrl();
        if (!URLUtil.isValidUrl(url) || h.getCertificate() == null) {
            return;
        }
        if (url.startsWith("file://") || url.startsWith("content://")) { return; }
        String ag = getString(R.string.b7);  
        SslCertificate.DName ssl = h.getCertificate().getIssuedTo();
        SslCertificate.DName ssl0 = h.getCertificate().getIssuedBy();
        String ag0 = ag.replaceAll("%a", h.getTitle());
        String ag1 = ag0.replaceAll("%b", h.getUrl());
        String ag2 = ag1.replaceAll("%c", ssl.getCName());
        String ag3 = ag2.replaceAll("%d", ssl.getOName());
        String ag4 = ag3.replaceAll("%e", ssl.getUName());
        String ag5 = ag4.replaceAll("%i", h.getCertificate().getValidNotBeforeDate().toString());
        String ag6 = ag5.replaceAll("%j", h.getCertificate().getValidNotAfterDate().toString());
        String ag7 = ag6.replaceAll("%f", ssl0.getCName());
        String ag8 = ag7.replaceAll("%g", ssl0.getOName());
        String ag9 = ag8.replaceAll("%h", ssl0.getUName());

        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b10, null);
        a.setTitle(getString(R.string.v19));
        a.setCancelable(true); 
        a.setView(c);
        final TextView ed = (TextView) c.findViewById(R.id.b10);  
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(C5.b(this,R.color.c));
        } else {
            ed.setTextColor(C5.b(this,R.color.b));
        }
        ed.setText(ag9);
        final AlertDialog g = a.create();
        g.show();
    }

    public boolean c76(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        SharedPreferences sp78 = getSharedPreferences("webDa", 0);
        boolean d678 = sp78.getBoolean("webDa", false);   
        boolean bn3 = sp.getBoolean("hst", false);
        boolean bn4 = sp.getBoolean("hste", false);
        if (d678 == false) {
            return false;
        }
        if (e1 == null || e2 == null) return false;
            if (e1.getPointerCount() > 1 || e2.getPointerCount() > 1) {
                return false;
            } else {
                try {
                    if (e1.getY() - e2.getY() > 10 ) {
                            // Hide Actionbar
                        if (getActionBar().isShowing() && bn3) {
                            V1.a(getApplicationContext(), R.anim.g, this.o);
                            getActionBar().hide();
                            h.invalidate();
                        }
                        if (bn4) {
                            this.o.setElevation(0);
                        }
                        return true;
                    } else if (e2.getY() - e1.getY() > 10 ) {
                        if (!getActionBar().isShowing() && bn3) {
                                // Show Actionbar
                            V1.a(getApplicationContext(), R.anim.h, this.o);  
                             getActionBar().show();
                             h.invalidate(); 
                        }
                        if (bn4) {
                            this.o.setElevation(10);
                        }
                        return true;
                    }
                } catch (Exception e) {
                    U1.a(e);
                    h.invalidate();
                }
                return false;
            }
    }

    public void c77(WebView a, int b, String c, String d) {
        if (sp.getBoolean("Arefresh", true) && !a.getUrl().startsWith("file:///") && b != WebViewClient.ERROR_FILE && !bl5) {
                hr.postDelayed(rn, 60000);
        }
        if (sp.getBoolean("showSA", false) == true) {
            try {
                if (b == WebViewClient.ERROR_FILE && sp.getBoolean("showSALL", false) == false) {
                    return;
                }
                c39(b, c, d, "");
            } catch (NullPointerException npe) {
                U1.a(npe);
            }
        }
    }
// on httpreceive error
    public void c78( WebView a,  WebResourceRequest b,  WebResourceResponse c) {
        if (sp.getBoolean("showSH", false) == true) {
            if (c.getStatusCode() == WebViewClient.ERROR_FILE && sp.getBoolean("showSALL2", false) == false) {
                return;
            }
            try {
            AlertDialog.Builder e = new AlertDialog.Builder(this);
            e.setTitle(getString(R.string.v1));
            String sg = getString(R.string.v2);
            String sg0 = sg.replace("%a", a.getUrl());
            String sg1 = sg0.replace("%b", c.getData().toString());

            String sg2 = sg1.replace("%c", c.getEncoding());
            String sg3 = sg2.replace("%d", c.getMimeType());
            String sg4 = sg3.replace("%e", c.getReasonPhrase());
            String sg5 = sg4.replace("%f", c.getResponseHeaders().toString());
            String sg6 = sg5.replace("%g", Integer.toString(c.getStatusCode()));
            e.setMessage(sg6);
            e.setPositiveButton(getString(R.string.i6), new C6() {
                public void a(DialogInterface a1, int a2) {
                    a1.dismiss();
                }
            });
            AlertDialog f = e.create();
            f.show();
            } catch (NullPointerException npe) {
                U1.a(npe);
            }
        }
    }
// on sslreceive error
    public void c79(final WebView a, final SslErrorHandler b, SslError c) {
        
        iw.setImageResource(R.drawable.a16);
        c57(a.getUrl());
        if (sp.getBoolean("showSO", true) == true) {
            AlertDialog.Builder e = new AlertDialog.Builder(this);


            String f = getString(R.string.v3);
            switch (c.getPrimaryError()) {
               case SslError.SSL_UNTRUSTED:
                   f = getString(R.string.v4);
               break;
               case SslError.SSL_EXPIRED:
                   f = getString(R.string.v5);
               break;
               case SslError.SSL_IDMISMATCH:
                   f = getString(R.string.v6);
               break;
               case SslError.SSL_NOTYETVALID:
                   f = getString(R.string.v7);
               break;
               case SslError.SSL_DATE_INVALID:
                   f = getString(R.string.v8);
               break;
               case SslError.SSL_INVALID:
                   f = getString(R.string.v9);
               break;
            }
            e.setTitle(getString(R.string.v10));
            e.setMessage(f);
            e.setCancelable(false);
            e.setPositiveButton(getString(R.string.i14), new C6() {
                public void a(DialogInterface a1, int a2) {
                    b.proceed();
                }
            });
            e.setNegativeButton(getString(R.string.j4), new C6() {
                public void a(DialogInterface a1, int a2) {
                    a.goBack();
                }
            });
            e.setNeutralButton(getString(R.string.v11), new C6() {
                public void a(DialogInterface a1, int a2) {
                    c75();
                }
            });
            AlertDialog g = e.create();
            g.show();
        } else {
            b.proceed();
        }
    }
 
 
    // on page finished
    public void c80(WebView a, String b) {
        try {
            bl5 = true;
            c133();
            if (a.getOriginalUrl() != null) {
                d1.c(a.getTitle(), a.getOriginalUrl(), this); 
            }
            c33(b, a.getTitle());
            c38(b);
            if (bl4 == true) {
                bl4 = false;
                a.clearHistory();
            } 
            c54(b);
            SharedPreferences d = getSharedPreferences("webDa", 0);
            boolean d678 = d.getBoolean("webDa", false);
            boolean bn3 = sp.getBoolean("tow", false);
            if (d678 == true && bn3 == true) {
                N2.b(this);
            }
        } catch (Exception e) {
            U1.a(e);
        }
    }

    // on page started
    public void c81(WebView a, String b, Bitmap c) { 
        try {

            g.setVisibility(View.VISIBLE);
            bl5 = false;
            if (hr != null && bl5) {
                hr.removeCallbacks(rn);
            }
            c133();
            c134();
            c33(b, getString(R.string.v13));
            c38(b);
            c54(b);
            c56(b);
            SharedPreferences d = getSharedPreferences("webDa", 0);
            boolean d678 = d.getBoolean("webDa", false);
            if (d678 == true && bl1 == true) {
                bl1 = false;
                V1.a(this, R.anim.h,  o); 
                getActionBar().show();
                h.invalidate();
            } 
            boolean bn3 = sp.getBoolean("tow", false);
            if (d678 == true && bn3 == true) {
                N2.a(this);
            }
        } catch (Exception e) {
            U1.a(e);
        }
    }

    // ShouldOverrideUrlLoading
    public boolean c82(WebView a, String b) {
        c38(b);
        try {
           if (b.startsWith("intent://")) {
               try {
                   Intent it = Intent.parseUri(b, Intent.URI_INTENT_SCHEME);
                   if (it.resolveActivity(getPackageManager()) != null) {
                       startActivity(it);
                       return true;
                   } else {
                       String fa = it.getStringExtra("browser_fallback_url");
               if (sp.getBoolean("dont", true) == true) {
                   a.loadUrl(b,eh);
                   return true;
               }
a.loadUrl(b);
               return true;
                   }
               } catch (URISyntaxException use) {
               }
           } else {
               Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(b));
               if (intent.resolveActivity(getPackageManager()) != null && !URLUtil.isValidUrl(b)) {
                   startActivity(intent);
                   return true;
               }
               if (sp.getBoolean("dont", true) == true) {
                   a.loadUrl(b,eh);
                   return true;
               }
               return false;
           }
        } catch (Exception e) {
           U1.a(e);
        }
        return false;
    }     


    public void c83(String str, String str2, String str3, String str4, long j) {
        try {
            c6();
            
            WifiManager b = (WifiManager) getSystemService(WIFI_SERVICE);
            if (sp.getBoolean("autoD", false) == false) {
                final Request f = new Request(Uri.parse(str));
 
                if (sp.getBoolean("wifi", false) == true) {
                    if (b.isWifiEnabled()) {
                        if (M2.a(this, M2.STORAGE, 1) == true) {
                            c11(str, str3, str4, j, f, str2);
                        }
                    } else {
                        c7(getString(R.string.v12));
                    }
                } else {
                    if (M2.a(this, M2.STORAGE, 1) == true) {
                        c11(str, str3, str4, j, f, str2);
                    }
                }
            } else {
                if (sp.getBoolean("wifi", false) == true) {
                    if (b.isWifiEnabled()) {
                       
                        if (M2.a(this, M2.STORAGE, 1) == true) {
// auto download
                        }
                    } else {
                        c7(getString(R.string.v12));
                    }
                } else {
                    if (M2.a(this, M2.STORAGE, 1) == true) {
// auto download
                    }
                }
            }
        } catch (Exception ex) { 
            U1.a(ex);
        }
    }

    public Bitmap c84() {
         if (new File(I3.a() +"/WebView/.cache/e.cache").exists()) {
             return BitmapFactory.decodeFile(I3.a() +"/WebView/.cache/e.cache");
         }
         return BitmapFactory.decodeResource(getResources(), R.drawable.e3);
    }

// on receive title
    public void c86(WebView a, String b) {
        String d = a.getUrl();
        if (!TextUtils.isEmpty(b)) {
            c33(d, b);
        } 
    }
// on hide custom view
    public void c87() {
        try {
            getActionBar().show();
            h.invalidate();
bl3 = false;
          c98(); getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); 
 c99();
            float b = (float)0/100;
            WindowManager.LayoutParams c = getWindow().getAttributes();
            c.screenBrightness = b;
            getWindow().setAttributes(c);
            ((FrameLayout) getWindow().getDecorView()).removeView(this.
cv); 
            this.
cv = null;    
           getWindow().getDecorView().setSystemUiVisibility(this.it7422); 
            setRequestedOrientation(this.it742); 
            this.cvc.onCustomViewHidden();      
            this.cvc = null; 
        } catch (Exception asd) {
            U1.a(asd);
        }
    }
// on show custom view
    public void c88(View a, WebChromeClient.CustomViewCallback b) {
        try {
            getActionBar().hide();
            bl3 = true;
            h.invalidate();
         getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); 
 getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
c128();
    					SharedPreferences c = getSharedPreferences("brightness", 0);
            int e = c.getInt("brightness", 0);
            float f = (float)0/100;
            if (e == 0) {
                f = (float)20/100;
            } else {
                f = (float)e/100;
            }
            WindowManager.LayoutParams g = getWindow().getAttributes();
            g.screenBrightness = f;
            getWindow().setAttributes(g);
            final AudioManager mAudio56 = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            SharedPreferences i = getSharedPreferences("volume", 0);
            int k = i.getInt("volume", 0);
            if (k == 0) {
                mAudio56.setStreamVolume(AudioManager.STREAM_MUSIC, 10, AudioManager.FLAG_PLAY_SOUND);
            } else {
                mAudio56.setStreamVolume(AudioManager.STREAM_MUSIC, k, AudioManager.FLAG_PLAY_SOUND);
            }

            if (this.
cv != null) { 
                return; 
            } 
            this.
cv = a;      
            this.it7422 = getWindow().getDecorView().getSystemUiVisibility(); 
               
            this.cvc = b;
            ((FrameLayout) getWindow().getDecorView()).addView(this.
cv, new FrameLayout.LayoutParams(-1, -1));
           getWindow().getDecorView().setSystemUiVisibility(3846);
        } catch (Exception asd) {
             U1.a(asd);
        }
    }
// on show file chooser
    public boolean c89(WebView a, ValueCallback<Uri[]> b2, WebChromeClient.FileChooserParams c) {
        b = b2;
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
            d.addCategory(Intent.CATEGORY_OPENABLE);
        d.setType("*/*");
if (d.resolveActivity(getPackageManager()) != null) { 
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 2);
return true;
}
        return false;
    }

    public void c90(WebView a, int b) {
        g.setProgress(b);
        if (b >= 100) {
            g.setVisibility(View.GONE);
        }
    }

    public boolean c91(WebView a, String b, String c, final JsResult d) { 
        
        if (sp.getBoolean("Java10", true) == true) {
            new AlertDialog.Builder(this).setCancelable(true).setTitle(getString(R.string.f25).replaceAll("%a", a.getTitle())).setMessage(c).setPositiveButton(getString(R.string.i6), new C6() {
                public void a(DialogInterface a, int b) {
                    d.confirm();
                }
            }).setOnDismissListener(new C13 () {
        public void a(final DialogInterface arg0) {
                   d.confirm();
        }
    }).create().show();
        } else {
            d.confirm();
        }
        return true;  
    }

    public boolean c92(WebView a, String b, String c, String d, final JsPromptResult e) {
        
        if (sp.getBoolean("Java9", true) == true) {
            AlertDialog.Builder a89 = new AlertDialog.Builder(this);


            LayoutInflater b54 = getLayoutInflater();
            View c34 = b54.inflate(R.layout.x, null);
            a89.setCancelable(true); 
            a89.setTitle(getString(R.string.f25).replaceAll("%a", a.getTitle()));
            a89.setView(c34);
            TextView sjs1 = (TextView) c34.findViewById(R.id.e1);
            final EditText sjs = (EditText) c34.findViewById(R.id.e3);
            int e78 = C5.b(this, R.color.c);
            int f = C5.b(this, R.color.b);
            int f1 = C5.b(this, R.color.j);
            int g1 = C5.b(this, R.color.k);
            if (sp.getBoolean("autoUpdate", false) == false) {
                sjs1.setTextColor(e78);
                sjs.setTextColor(e78);
                sjs.setHintTextColor(f1);
            } else {
                sjs1.setTextColor(f);
                sjs.setTextColor(f);
                sjs.setHintTextColor(g1);
            }
            sjs1.setText(c);
            a89.setPositiveButton(getString(R.string.i6), new C6() { 
                public void a(DialogInterface a, int b) { 
                    String uwe = sjs.getText().toString();
                    e.confirm(uwe);
  	            } 
  	        }); 
           a89.setNegativeButton(getString(R.string.i7), new C6() { 
               public void a(DialogInterface a, int b) {
                   e.cancel();
  	            } 
  	        }).setOnDismissListener(new C13() {
        public void a(final DialogInterface arg0) {
                   e.cancel();
        }
    });
           final AlertDialog g = a89.create();
           sjs.addTextChangedListener(new T6() {
               private void a() {
                   final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
                   if (sjs.getText().toString().length() != 0) {
                       okButton.setEnabled(true);
                   } else {
                       okButton.setEnabled(false);
                   }
               }
                
               public void c(Editable arg0) {
               }
                
               public void a(CharSequence s, int start, int count, int after) {
               }
    
               public void b(CharSequence s, int start, int before, int count) {
                   a();
               }
           });
           g.show();
           g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            } else {
                 e.confirm();
            }
        return true;
    }

    public boolean c93(WebView a, String b, String c, final JsResult e) {
        
        if (sp.getBoolean("Java11", true) == true) {
            new AlertDialog.Builder(this).setCancelable(true).setTitle(getString(R.string.f25).replaceAll("%a", a.getTitle())).setMessage(c).setPositiveButton(getString(R.string.i6), new C6() {
                public void a(DialogInterface a, int b) {
                    e.confirm();
                }
            }).setNegativeButton(getString(R.string.i7), new C6() {
                public void a(DialogInterface a, int b) {
                    e.cancel();
                }
              }).setOnDismissListener(new C13() {
        public void a(final DialogInterface arg0) {
                   e.cancel();
        }
    }).create().show();
        } else {
            e.confirm();
        }
        return true;
    }

    public boolean c94(WebView a, String b, String c, final JsResult e) {
        
        if (sp.getBoolean("Java12", true) == true) {
            new AlertDialog.Builder(this).setCancelable(true).setTitle(getString(R.string.f25).replaceAll("%a", a.getTitle())).setMessage(c).setPositiveButton(getString(R.string.i6), new C6() {
                public void a(DialogInterface a, int b) {
                    e.confirm();
                }
            }).setNegativeButton(getString(R.string.i7), new C6() {
                public void a(DialogInterface a, int b) {
                    e.cancel();
                }
             }).setOnDismissListener(new C13() {
        public void a(final DialogInterface arg0) {
                   e.cancel();
        }
    }).create().show();
        } else {
            e.confirm();
        }
        return true;
    }

    public boolean c95(String a, int b, String c) { 
        String sg = getString(R.string.v18).replaceAll("%a", a).replaceAll("%b", Integer.toString(b)).replaceAll("%c", c);
        cm.append(sg+"\n\n");
        return true;
    }
    public void c96(final String a, final GeolocationPermissions.Callback b) {
        if (M2.a(this, M2.LOCATION, 5) == true) {
            final boolean c = false;
            AlertDialog.Builder d = new AlertDialog.Builder(this);
            d.setMessage(getString(R.string.v14).replaceAll("%a", a));
            d.setCancelable(false);
            d.setPositiveButton(getString(R.string.v17), new C6() {
                public void a(DialogInterface a1, int a2) {
                    b.invoke(a, true, c);
                    c8(getString(R.string.v15).replaceAll("%a", a));
                }
            });
            d.setNegativeButton(getString(R.string.i39), new C6() {
                public void a(DialogInterface a1, int a2) {
                    b.invoke(a, false, c);
                    c7(getString(R.string.v16).replaceAll("%a", a));
                }
            });
            AlertDialog e = d.create();
            e.show();
            }
    }
private void c97() {
    // Enables regular immersive mode.
    // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
    // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    View decorView = getWindow().getDecorView();
    decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            // Set the content to appear under the system bars so that the
            // content doesn't resize when the system bars hide and show.
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            // Hide the nav bar and status bar
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
}

// Shows the system bars by removing all the flags
// except for the ones that make the content appear under the system bars.
private void c98() {

getWindow().getDecorView().setSystemUiVisibility(
    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
   );
     if (Build.VERSION.SDK_INT >=23){
        if (sp.getBoolean("autoUpdate", false) == false) {
            if (sp.getBoolean("webviewB", false) == false) {
getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);//  set status text dark
getWindow().setStatusBarColor(C5.b(this,R.color.b));// set status background whitey

 }
                }
} 
}
    public void c99() {
        try {
           if (sp.getString("hori", "").length() == 0){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (sp.getString("hori", "").equals("1c")){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (sp.getString("hori", "").equals("7c")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
           }
           if (sp.getString("hori", "").equals("30c")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
           }
           if (sp.getString("screen", "").length() == 0){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
           }
           if (sp.getString("screen", "").equals("1j")){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
           }
           if (sp.getString("screen", "").equals("7j")) {
               getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
           }
           if (sp.getString("hide", "").length() == 0){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); 
               c98();
           }
           if (sp.getString("hide", "").equals("1d")){
               getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN); 
               c98();
           }
           if (sp.getString("hide", "").equals("7d")) {
               getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); 
           }
        } catch (Exception ex) { 
            U1.a(ex);
        }
    }

    private void c100(WebView a) {
 
        PrintManager aa = (PrintManager) getSystemService(
                Context.PRINT_SERVICE);
 
        aa.print(a.getTitle(), a.createPrintDocumentAdapter(a.getTitle()), null);
    }
    private boolean c101() {
        try {
            boolean bn = C3.a(U4.a("Y29tLmdvb2dsZS5hbmRyb2lkLmdvb2dsZXF1aWNrc2VhcmNoYm94"), this.getPackageManager());
            final ApplicationInfo ai = this.getPackageManager().getApplicationInfo(U4.a("Y29tLmdvb2dsZS5hbmRyb2lkLmdvb2dsZXF1aWNrc2VhcmNoYm94"),0);
            boolean bn1 = ai.enabled;
            if (bn == true) {
                if (bn1 == true) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }       
        } catch (NameNotFoundException e) {
            U1.a(e);
                return false;
        }
     
    }  

    private void c102() {
     /*   SharedPreferences a3 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        /*if (c101() == false) {
            return;
        }
        if (a3.getBoolean("voice", true) == true) {
            ImageView iw = new ImageView(this);
            iw.setImageResource(R.drawable.f); 
            iw.setBackgroundResource(R.drawable.e2);  
            MarginLayoutParams ma = (MarginLayoutParams) iw.getLayoutParams();
            ma.setMargins(10, 10, 10, 10);
            RelativeLayout.LayoutParams hq = new RelativeLayout.LayoutParams(ma);
            hq.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);  
            hq.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            iw.setLayoutParams(hq);
           iw.setOnClickListener(new C9() {
                public void a(View vw) {
                    c29();
                }
            });
            h.addView(iw);
        }*/
//  UNFINISHED FLOATING ACTIONS
    }

    private void c103(String a) {            

d2.c(a, this);
 
}
public void c104(String b) {
        Intent a = new Intent();
        if (b.startsWith("tel:") || b.startsWith("voicemail:")) {
            a = new Intent(Intent.ACTION_DIAL, Uri.parse(b)); 
        } else {
            a = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: "+b)); 
        } 
if (a.resolveActivity(getPackageManager()) != null) { 
startActivity(Intent.createChooser(a, getString(R.string.a26)));
}
    }
    public void c105(String b) {
        Intent d = new Intent(Intent.ACTION_VIEW);
 
        if (W13.h(b) == true) {
 d.setData(Uri.parse(b));
        } else { 
 d.setData(Uri.parse("sms:" + b));
        }
if (d.resolveActivity(getPackageManager()) != null) { 
startActivity(Intent.createChooser(d, getString(R.string.a26)));
}
    }
private void c108() {

        if (!ua) {
           if (sp.getString("userA", "").length() == 0){
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) WebView/" + W5.d() +"Mobile Safari/537.36");
           }
           if (sp.getString("userA", "").equals("1e")){
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) WebView/" + W5.d() +"Mobile Safari/537.36");
           }
           if (sp.getString("userA", "").equals("7e")) {
               ws.setUserAgentString(new WebView(this).getSettings().getUserAgentString());
           }
           if (sp.getString("userA", "").equals("30e")) {
               ws.setUserAgentString("Mozilla/5.0 (Mobile; Windows Phone 8.1; Android 4.0; ARM; Trident/7.0; Touch; rv:11.0; IEMobile/11.0; NOKIA; Lumia 635) like iPhone OS 7_0_3 Mac OS X AppleWebKit/537 (KHTML, like Gecko) Mobile Safari/537");
           }
           if (sp.getString("userA", "").equals("60e")) {
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36");
           }
           if (sp.getString("userA", "").equals("120e")){
               ws.setUserAgentString("Mozilla/5.0 (Android 8.0.0; Mobile; rv:61.0) Gecko/61.0 Firefox/68.0");
           }
           if (sp.getString("userA", "").equals("240e")) {
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 10; SM-N975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36 OPR/55.2.2719");
           }
           if (sp.getString("userA", "").equals("480e")) {
               ws.setUserAgentString("Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/80.0.3987.95 Mobile/15E148 Safari/604.1");
           }
           if (sp.getString("userA", "").equals("960e")){
               ws.setUserAgentString("Mozilla/5.0 (Windows Mobile 10; Android 8.0.0; Microsoft; Lumia 950XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36 Edge/80.0.361.109");
           }
           if (sp.getString("userA", "").equals("3840e")) {
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 8.0.0;) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36");
           }
           if (sp.getString("userA", "").equals("3840e")) {
               ws.setUserAgentString("Mozilla/5.0 (Linux; Android 8.0.0; SM-G935F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Brave Chrome/69.0.3497.100 Mobile Safari/537.36");
           }
           if (sp.getString("userA", "").equals("7680e")) {
               ws.setUserAgentString(sp.getString("CustomuserA", ""));
            }

        }
    }

    private void c109(String a, String b) {  
        try {
             InputStream c = getContentResolver().openInputStream(Uri.parse(a));
             OutputStream d = new FileOutputStream(I3.a() +"/WebView/.cache/b.cache");
             byte[] e = new byte[1024];
             int f;
             while((f = c.read(e)) != -1) {
                 d.write(e, 0, f);
             }
             c.close();
             c = null;
             d.flush();
             d.close();
             d = null;
if (b.equals("text/htm") || b.equals("text/html")) {
h.loadDataWithBaseURL("file://"+I3.a() +"/WebView/.cache/b.cache", "", "text/html", "UTF-8", "");
} else {
 h.loadUrl("file://"+I3.a() +"/WebView/.cache/b.cache");
}
        } catch (Exception ex) {
            U1.a(ex);
        }
    }


    public void c111(final String dt) {
        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.k, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.w18));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.l3);
        final EditText ed = (EditText) c.findViewById(R.id.l4);
        final TextView ti2 = (TextView) c.findViewById(R.id.l5);
        final TextView ti3 = (TextView) c.findViewById(R.id.l6);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
            ti.setTextColor(e);
            ti2.setTextColor(e);
            ti3.setTextColor(e);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f);
            ti2.setTextColor(f);
            ti3.setTextColor(f);
        }
        ti.setText(getString(R.string.c30));
        ti2.setText(getString(R.string.c31));
        ti3.setText("/Internal Storage/WebView/Downloads/"+ Uri.parse(h.getUrl()).getHost()+".png");
        ed.setText(Uri.parse(h.getUrl()).getHost()+".png");
        a.setPositiveButton(getString(R.string.i6), new C6() { 
            public void a(DialogInterface a2, int b) { 
                c113(ed.getText().toString(),dt);
  	         } 
  	     });
        a.setNegativeButton(getString(R.string.i7), new C6() { 
            public void a(DialogInterface a2, int b) { 
                a2.dismiss();
  	        } 
  	    }); 
        final AlertDialog g = a.create();
        ed.addTextChangedListener(new T6 () {
            private void a() {
        ti3.setText("/Internal Storage/WebView/Downloads/"+ed.getText().toString());
                final Button okButton = g.getButton(AlertDialog.BUTTON_POSITIVE);
String jhh  = ed.getText().toString().replaceAll(" ","");
 
     if (jhh.length() != 0) {
  
                    if (new File(I3.a() +"/WebView/Downloads/"+ed.getText().toString()).exists()) {
ed.setError(getString(R.string.u19)); okButton.setEnabled(false);
} else {

 okButton.setEnabled(true);
}
} else {
okButton.setEnabled(false);
}
            
            }
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        g.show();
        String aqw  = ed.getText().toString().replaceAll(" ","");
        if ( aqw.length() != 0) {
if (new File(I3.a() +"/WebView/Downloads/"+ed.getText().toString()).exists()) {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); ed.setError(getString(R.string.u19)); 
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
}
} else {
g.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false); 
}
    }

     public void c112(String url, final int type) {
        AlertDialog.Builder a = new AlertDialog.Builder(this);
        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b8, null);
        a.setCancelable(true); 
        switch (type) {
            case 0:
                a.setTitle(getString(R.string.x9)); // LINKS
            break;
            case 1:
                a.setTitle(getString(R.string.x16)); // TRANCEROUT
            break;
            case 2:
                a.setTitle(getString(R.string.y11)); //NPing
            break;
            case 3:
                a.setTitle(getString(R.string.z4)); //Whois
            break;
            case 4:
                a.setTitle(getString(R.string.z15)); //Meta Tags
            break;
            case 5:
                a.setTitle(getString(R.string.y15)); // Headers
            break;
            case 6:
                a.setTitle(getString(R.string.f32)); // Robots
            break;
            case 7:
                a.setTitle(getString(R.string.j)); // Source Code
            break;
            case 8:
                a.setTitle(getString(R.string.z12)); // IP Geolocation
            break;
        }
        a.setView(c);
        final EditText ed = (EditText) c.findViewById(R.id.g8);
        final TextView ti = (TextView) c.findViewById(R.id.e2);
        final Button bn = (Button) c.findViewById(R.id.k20);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        int e3 = C5.b(this,R.color.j);
        int f3 = C5.b(this,R.color.k);
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
bn.setTextColor(e);
            ti.setTextColor(e3);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f3);
bn.setTextColor(f);
        }
        if (type == 0 || type == 4 || type == 5 || type == 7 || type == 6) {
            ed.setText(url);
        } else if (type == 8) {
            ed.setText(U5.c(url));
        } else {
            ed.setText(Uri.parse(url).getHost().replaceAll("www.", ""));
        }
        bn.setText(getString(R.string.i6));
        bn.setBackgroundResource(R.drawable.e20);
        ti.setText(getString(R.string.f31).replaceAll("%a", "\nhttps://example.com").replaceAll("%b", "http://example.com").replaceAll("%c", "example.com"));
 
        bn.setOnClickListener(new C9() {
            public void a(View v) {
                 String a = ed.getText().toString();
                 switch (type) {
                     case 0:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.z()) + a), getString(R.string.x9) +" | " + a);
}
                     break;
                     case 1:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(1)+ a), getString(R.string.x16) +" | " + a);
}
                     break;
                     case 2:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a( 2) + a), getString(R.string.y11) +" | " + a);
}
                     break;
                     case 3:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U6.a(  3) + a), getString(R.string.z4) +" | " + a);
}
                     break;
                     case 4:
                         if (W13.a(a) == true) {
                         b(Uri.parse(U4.a(W5.a1()) + a), getString(R.string.z15) +" | " + a);
}
                     break;
                     case 5:
                         if (W13.a(a) == true) {
                             b(Uri.parse(U4.a(W5.y()) + a), getString(R.string.y15) +" | " + a);
}
                     break;
                     case 6:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a.replaceAll("/", "")+"/robots.txt"), getString(R.string.f32) +" | " + a);
                             } else {
                                 b(Uri.parse("http://"+a.replaceAll("/", "")+"/robots.txt"), getString(R.string.f32) +" | " + a);
                             }
                         }
                     break;
                     case 7:
                         if (W13.a(a) == true) {
                             if (a.startsWith("https://") || a.startsWith("http://")) {
                                 b(Uri.parse(a), getString(R.string.j) +" | " + a);
                             } else {
                                 b(Uri.parse("http://"+a), getString(R.string.j) +" | " + a);
                             }
                         }
                     break;
                     case 8:
                         b(Uri.parse(U4.a(W5.a17())+a+U4.a(W5.a18())), getString(R.string.z12) +" | " + a);
                     break;
                 }
            }

            public void b(Uri a, String qr) {
                Intent it = new Intent("com.android.DROID_MJ.webview.intent.action.TOOLS");
                it.addCategory("com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT");
                it.setPackage(U4.a(W5.a10()));
                it.putExtra("qr", qr);
                it.setData(a);
                if (it.resolveActivity(A21.this.getPackageManager()) != null) {
                    A21.this.startActivity(it);
                }
            }
        });
        ed.addTextChangedListener(new T6 () {
            private void a() {
                String url = ed.getText().toString().replaceAll(" ","");
                if (type == 6 || type == 7) {
                    if (W13.a(url) == false) {
                        ed.setError(getString(R.string.c32));
                    }
                }
            }
            public void c(Editable arg0) {
            }
        
            public void a(CharSequence s, int start, int count, int after) {
            }
        
            public void b(CharSequence s, int start, int before, int count) {
                a();
            }
        });
        final AlertDialog g = a.create();
        g.show();
    }

 private void c113(final String a, final String b) {
P15 p = new P15() {
public void a() {
try {
File a2 = new File(I3.a() + "/WebView/Downloads/"+a);
         
                  a2.createNewFile();
                  FileOutputStream a3 = new FileOutputStream(a2);
                  OutputStreamWriter a4 = new OutputStreamWriter(a3);
                  a4.append(U4.a(b.split(",")[1]));
                  a4.close();
                  a3.close();
} catch (Exception e) { }
}
};
er.execute(new Thread(p));
c8(getString(R.string.f38));
}


private void c116() {
      C1.b(this, S7.class);
}

public void c119( ) {
       final AlertDialog.Builder a =  new AlertDialog.Builder(this);


        a.setCancelable(true);
a.setTitle(getString(R.string.y14));
        LayoutInflater d = getLayoutInflater();
        View e = d.inflate(R.layout.b15, null);
        a.setView(e);
        TextView f = (TextView) e.findViewById(R.id.k6); 
  
 
  f.setText(ws.getUserAgentString());
 
          if (sp.getBoolean("autoUpdate", false) == false) {
f.setTextColor(C5.b(this,R.color.c));
 
           } else{
f.setTextColor(C5.b(this,R.color.b));
 
        
}
AlertDialog dd = a.create();
dd.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
dd.show();
    } 
 
     public void c122( ) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b16, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.z16));
        a.setView(c);
        final EditText ed = (EditText) c.findViewById(R.id.k9);
        final TextView ti = (TextView) c.findViewById(R.id.k10);
        Button bn = (Button) c.findViewById(R.id.k11);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
bn.setTextColor(e);
            ti.setTextColor(e);
        } else {
            ed.setTextColor(f);
            ti.setTextColor(f);
bn.setTextColor(f);
        }
ed.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); 
       ed.setTransformationMethod(new T2());
bn.setText(getString(R.string.e28));
 bn.setBackgroundResource(R.drawable.e20);
bn.setOnClickListener(new C9() {
            public void a(View v) {
                String str = ed.getText().toString();
                try {
                    int it = Integer.parseInt(str);
                    if (it > 0) {
ti.setText(com.java.DROID_MJ.U.U1.a(it));
                    }
                } catch (NumberFormatException nfe) {
                }
            }
        });
        ed.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(android.widget.TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                String str = ed.getText().toString();
                try {
                    int it = Integer.parseInt(str);
                    if (it > 0) {
ti.setText(com.java.DROID_MJ.U.U1.a(it));
                    }
                } catch (NumberFormatException nfe) {
                }
                return handled;
            }
        });
        final AlertDialog g = a.create();
        g.show();
    }

     public void c123( ) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b17, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.z17));
        a.setView(c);
        final TextView ti = (TextView) c.findViewById(R.id.k13);
        Button bn = (Button) c.findViewById(R.id.k14);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
        
        if (sp.getBoolean("autoUpdate", false) == false) {
            ti.setTextColor(e);
             
bn.setTextColor(e);
        } else {
            ti.setTextColor(f);
             
bn.setTextColor(f);
        }

ti.setText(com.java.DROID_MJ.U.U3.a());
bn.setText(getString(R.string.e28));
 bn.setBackgroundResource(R.drawable.e20);
bn.setOnClickListener(new C9() {
            public void a(View v) {
                ti.setText(com.java.DROID_MJ.U.U3.a());

            }
        });

        final AlertDialog g = a.create();
g.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        g.show();
    }

    public void c124(String tg) {
         
 if (sp.getString("searchP", "").length() == 0) {
                c3("https://www.google.com/search?q=" + tg);
            } else if (sp.getString("searchP", "").equals("1b")) {
                c3("http://duckduckgo.com/"+tg);
            } else if (sp.getString("searchP", "").equals("7b")) {
                c3("https://www.google.com/search?q="+ tg);
            } else if (sp.getString("searchP", "").equals("30b")) {
                c3("https://www.bing.com/search?q=" + tg);
            } else if (sp.getString("searchP", "").equals("60b")) {
                c3("https://search.yahoo.com/search?p=" + tg);
            } else if (sp.getString("searchP", "").equals("120b")) {
                c3("https://www.ask.com/web?o=0&l=dir&qo=serpSearchTopBox&q=" + tg);
            } else if (sp.getString("searchP", "").equals("240b")) {
                c3("https://search.aol.com/aol/search?s_chn=prt_bon-404&q=" + tg);
            } else if (sp.getString("searchP", "").equals("480b")) {
                c3("http://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&ch=&tn=baiduerr&bar=&wd=" + tg);
            } else if (sp.getString("searchP", "").equals("860b")) {
                c3("https://www.wolframalpha.com/input/?i=" + tg);             
            } else 
if (sp.getString("searchP", "").equals("1720b")) {
                c3("https://www.0.freebasics.com/https/www.google.com/search?client=aff-freebasics&channel=text_only_mode&q=" + tg + "&iorg_ref=search");
            } else if (sp.getString("searchP", "").equals("3440b")) {
                c3("https://www.ecosia.org/search?q=" + tg);
            } else if (sp.getString("searchP", "").equals("6880b")) {
                c3("https://stackoverflow.com/search?q=" + tg);
            }
}
    private void c125(int type) {
        final AudioManager mAudio = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        
if (rl.getVisibility() == View.GONE) {
rl.setVisibility(View.VISIBLE);
V1.a(this, R.anim.c, rl);
}
        findViewById(R.id.c16).setElevation(10);
        findViewById(R.id.c16).setBackgroundResource(R.drawable.a19);
        c2.setProgress(mAudio.getStreamVolume(AudioManager.STREAM_MUSIC));
        if (type == 1) {
            mAudio.setStreamVolume(AudioManager.STREAM_MUSIC, mAudio.getStreamVolume(AudioManager.STREAM_MUSIC)+1, AudioManager.FLAG_PLAY_SOUND);
        } else if (type == 0) {
            mAudio.setStreamVolume(AudioManager.STREAM_MUSIC, mAudio.getStreamVolume(AudioManager.STREAM_MUSIC)-1, AudioManager.FLAG_PLAY_SOUND);
        }
c2.setThumb(new BitmapDrawable(getResources(), C5.c(this, R.drawable.a6)));
       
        c2.setMax(mAudio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        
        c2.setOnSeekBarChangeListener(new W25() {
            public void a(SeekBar bar, int progress, boolean fromUser) {
                 mAudio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, AudioManager.FLAG_PLAY_SOUND);
                 
            }
            public void b(SeekBar bar) {
        
            }
            public void c(SeekBar bar) {
            }
        });
        rl.setOnClickListener(new C9() {
            public void a(View v) {
V1.a(A21.this, R.anim.d, rl);
                rl.setVisibility(View.GONE);
            }
        });
}

     public void c127( ) {
AlertDialog.Builder a = new AlertDialog.Builder(this);


        LayoutInflater b = getLayoutInflater();
        View c = b.inflate(R.layout.b5, null);
        a.setCancelable(true); 
        a.setTitle(getString(R.string.f23));
        a.setView(c);
ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                 android.R.layout.simple_dropdown_item_1line, js);
        
        final AutoCompleteTextView ed = (AutoCompleteTextView) c.findViewById(R.id.d15);

       ed.setAdapter(adapter);
        Button bn = (Button) c.findViewById(R.id.c1);
        int e = C5.b(this,R.color.c);
        int f = C5.b(this,R.color.b);
         
        if (sp.getBoolean("autoUpdate", false) == false) {
            ed.setTextColor(e);
             
bn.setTextColor(e);
        } else {
            ed.setTextColor(f);
             
bn.setTextColor(f);
        }

bn.setText(getString(R.string.f24));
 bn.setBackgroundResource(R.drawable.e20);

bn.setOnClickListener(new C9() {
            public void a(View v) {
                String str = ed.getText().toString();
                if (str.length() != 0) {
                    h.loadUrl("javascript:(function(){" + str + "})()");
                }
            }
        });
        
 a.create().show();
}

public void c128() {
           if (sp.getString("horiVD", "").length() == 0){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
           }
           if (sp.getString("horiVD", "").equals("1a1")){
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
           }
           if (sp.getString("horiVD", "").equals("7a1")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
           }
           if (sp.getString("horiVD", "").equals("30a1")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
           }
           if (sp.getString("horiVD", "").equals("60a1")) {
               setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
           }
}
     public void c129(final PermissionRequest pr) {
          if (Arrays.toString(pr.getResources()).contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && M2.a(this, M2.CAMERA, 6) == false) {

               return;
          } else if (Arrays.toString(pr.getResources()).contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && M2.a(this, M2.MICROPHONE, 7) == false) {
               return;
          }
          AlertDialog.Builder d = new AlertDialog.Builder(this);
            d.setMessage(getString(R.string.i38).replaceAll("%a", pr.getOrigin().getHost()).replaceAll("%b", Arrays.toString(pr.getResources())));
          d.setCancelable(false);
          d.setPositiveButton(getString(R.string.v17), new C6() {
              public void a(DialogInterface a1, int a2) {
                  pr.grant(pr.getResources());
                  c8(getString(R.string.i40).replaceAll("%a", pr.getOrigin().getHost()).replaceAll("%b", Arrays.toString(pr.getResources())));
              }
          });
          d.setNegativeButton(getString(R.string.i39), new C6() {
              public void a(DialogInterface a1, int a2) {
                  pr.deny();      
c7(getString(R.string.j21).replaceAll("%a", pr.getOrigin().getHost()).replaceAll("%b", Arrays.toString(pr.getResources())));
              }
          });
          AlertDialog e = d.create();
          e.show();
    }

    public void c130() {
        AlertDialog.Builder a =  new AlertDialog.Builder(this);
        a.setCancelable(true);
a.setTitle(getString(R.string.y15));
        LayoutInflater d = getLayoutInflater();
        View e = d.inflate(R.layout.b15, null);
        a.setView(e);
        TextView f = (TextView) e.findViewById(R.id.k6); 
        f.setText(U6.b(U4.a(W5.a11())));
        if (sp.getBoolean("autoUpdate", false) == false) {
            f.setTextColor(C5.b(this,R.color.c));
        } else{
            f.setTextColor(C5.b(this,R.color.b));
        }
        final AlertDialog g = a.create();

        g.show();
    } 

    public void c131() {
        P15 p = new P15() { 
            public void a() {
                if (U3.e(com.java.DROID_MJ.S.S1.a("SHA-512",C3.b(A21.this)), W5.b()) == false) {
                    W32.a();
                    C1.a(A21.this, A36.class);

                } else if (U3.e(com.java.DROID_MJ.S.S1.a("SHA-512",C3.c(A21.this)), W5.c()) == false) {
                    W32.b();
                    C1.a(A21.this, A36.class);
                } else if (U3.e(com.java.DROID_MJ.S.S1.a("SHA-512", S3.a(A21.this, C3.d(A21.this, U4.a(W5.a10()), 64), "X509", "SHA1")), W5.a()) == false) {
                    W32.c();
                    C1.a(A21.this, A36.class);
                }
            }
        };
        er.execute(new Thread(p));
    }

    public boolean c132(WebView view, RenderProcessGoneDetail detail) {
        String sg = view.getUrl();
        U1.a("onRenderProcessGone | rendererPriorityAtExit | " + Integer.toString(detail.rendererPriorityAtExit()));
        if (!detail.didCrash()) {
            U1.a("System killed the WebView rendering process to reclaim memory. Recreating...");
        } else {
            U1.a("The WebView rendering process crashed!");
        }
        if (h != null) {
            ViewGroup vg = (ViewGroup) findViewById(R.id.i);
            vg.removeView(h);
            h.destroy();
            h = null;
            System.gc();
        }
        finish();
        Intent it = new Intent("com.android.DROID_MJ.webview.intent.action.LAUNCH");
        it.putExtra("webview", sg);
        sendBroadcast(it);
        return true;
    }
public void c133() {
if (g.getProgress() >= 100) {
               tv3.setImageResource(R.drawable.b11); 
               tv3.setOnClickListener(new C9() {
                  public void a(View v) {
                      h.reload();
                  }
               });
           } else {
               tv3.setImageResource(R.drawable.a14); 
               tv3.setOnClickListener(new C9() {
                  public void a(View v) {
                      h.stopLoading();
if (hr != null) {
                hr.removeCallbacks(rn);
            }
                  }
               });
           }
    }


public void c134() {
if (h.canGoForward()) {
               tv4.setVisibility(View.VISIBLE);
               tv4.setImageResource(R.drawable.b13); 
               tv4.setOnClickListener(new C9() {
                  public void a(View v) {
                      h.goForward();
                  }
               });
           } else {
               tv4.setVisibility(View.GONE);
           }
    }

    public void c135(WebView a, Bitmap b) {
            tv5.setImageBitmap(b);
    }

    public void c136(WebView wb, float old, float neW) {
        /*if (Math.round(old) >= Math.round(neW)) {
            c7("show");
        } else {
c7("hide");
        }*/
    } 
    public void onCreateContextMenu(ContextMenu a, View b, ContextMenu.ContextMenuInfo c) {
        super.onCreateContextMenu(a, b, c);
        final HitTestResult d = h.getHitTestResult();    
        MenuItem.OnMenuItemClickListener e =
new MenuItem.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem a1) {
        final String a2 = d.getExtra().toString();
                switch (a1.getItemId()) { 
                    case 1:
                        c74(a2);
                    return true;
                    case 2:
                        c3(a2);
                    return true;
                    case 3:
                        c16(a2,0);
                    return true;
                    case 4:
                        C2.a(A21.this, a2);
                        c8(getString(R.string.k9));                     
                    return true;
                    
                    case 6:
                        c14(null, a2);
                    return true;
                    case 7:
                        c58(a2, null);
                    return true;
                    case 9:
                        c65(a2);
                    return true;
                    case 11:
                                  c104(a2);
                    return true;
                    case 10:
                                  c105(a2);
                    return true;
                    case 12:
       if (M2.a(A21.this, M2.STORAGE, 4) == true) {
                            c55(a2,null);
                        }
        
        return true;
                    case 13:
                        c43(a2);     
                    return true;
                    case 14:
                        c16(a2,1);
                    return true;
case 5:
                      c112(a2, 7);
                    return true;
case 15:
      
c112(a2,0);
 
                    return true;
case 16:
       
c112(a2, 1);
 
                    return true;
case 17:
       
c112(a2,2);
 
                    return true;
case 18:
                           
c112(a2, 3);
 
                    return true;
case 19:
                           
c112(a2, 5);
 
                    return true;
case 20:
                           
c112(a2, 4);
 
                    return true;
case 21:
                           
c112(a2, 6);
 
                    return true;
                }
                return true;
            }
        };

        if (d.getType() == HitTestResult.IMAGE_TYPE || d.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            a.setHeaderTitle(h.getTitle());
if (d.getExtra().toString().startsWith("http://") || d.getExtra().toString().startsWith("https://")){
            a.add(0, 1, 0, getString(R.string.w18)).setOnMenuItemClickListener(e);
}
            a.add(0, 2, 0, getString(R.string.w19)).setOnMenuItemClickListener(e);
            a.add(0, 4, 0, getString(R.string.x3)).setOnMenuItemClickListener(e);
            a.add(0, 3, 0, getString(R.string.a8)).setOnMenuItemClickListener(e);
        } else if (d.getType() == HitTestResult.SRC_ANCHOR_TYPE || d.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            a.setHeaderTitle(h.getTitle());

            a.add(0, 4, 0, getString(R.string.x3)).setOnMenuItemClickListener(e);
            a.add(0, 3, 0, getString(R.string.a8)).setOnMenuItemClickListener(e);
            a.add(0, 6, 0, getString(R.string.h11)).setOnMenuItemClickListener(e);
            a.add(0, 7, 0, getString(R.string.h12)).setOnMenuItemClickListener(e);
            a.add(0, 19, 0, getString(R.string.y15)).setOnMenuItemClickListener(e);
            a.add(0, 15, 0, getString(R.string.x9)).setOnMenuItemClickListener(e);
            a.add(0, 20, 0, getString(R.string.z15)).setOnMenuItemClickListener(e);
            a.add(0, 21, 0, getString(R.string.f32)).setOnMenuItemClickListener(e);
            a.add(0, 16, 0, getString(R.string.x16)).setOnMenuItemClickListener(e);
            a.add(0, 17, 0, getString(R.string.y11)).setOnMenuItemClickListener(e);
            a.add(0, 18, 0, getString(R.string.z4)).setOnMenuItemClickListener(e);



            a.add(0, 13, 0, getString(R.string.h6)).setOnMenuItemClickListener(e);


            a.add(0, 5, 0, getString(R.string.j)).setOnMenuItemClickListener(e);

            a.add(0, 12, 0, getString(R.string.i4)).setOnMenuItemClickListener(e);


        } else if (d.getType() == HitTestResult.EMAIL_TYPE || d.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            a.setHeaderTitle(d.getExtra().toString());
            a.add(0, 9, 0, getString(R.string.x2)).setOnMenuItemClickListener(e);
            a.add(0, 4, 0, getString(R.string.u)).setOnMenuItemClickListener(e);
            a.add(0, 14, 0, getString(R.string.a8)).setOnMenuItemClickListener(e);
        } else if (d.getType() == HitTestResult.GEO_TYPE || d.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) { 
            a.setHeaderTitle(d.getExtra().toString());
            a.add(0, 14, 0, getString(R.string.a8)).setOnMenuItemClickListener(e);
        } else if (d.getType() == HitTestResult.PHONE_TYPE || d.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) { 
            a.setHeaderTitle(d.getExtra().toString());
            a.add(0, 10, 0, getString(R.string.w20)).setOnMenuItemClickListener(e);
            a.add(0, 11, 0, getString(R.string.x1)).setOnMenuItemClickListener(e);
            a.add(0, 4, 0, getString(R.string.u)).setOnMenuItemClickListener(e);
            a.add(0, 14, 0, getString(R.string.a8)).setOnMenuItemClickListener(e);
        }else {
            if (sp.getBoolean("textST", true) == false) {
             
            }
        }
    }

    public void onRequestPermissionsResult(int a, String[] b, int[] c) {
        super.onRequestPermissionsResult(a, b, c);
        switch (a) {
            case 1:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    h.reload(); 
                    c6();
                } else {  
       
                        if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                            c7(getString(R.string.u15));
                        } else {
         c53(getString(R.string.u16));
}
                   
              }
              break;
   case 2:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
                    h.reload(); 
                    c6();
                } else {  
 if (h.getUrl().startsWith("file://")) {
   if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            
                        c7(getString(R.string.u17));
                    } else  {
         c53(getString(R.string.u18));
}
}

}
break;
  case 3:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
c6();
                 c68(A21.this.back23);
      V2.b(getApplicationContext(), A21.this.back23);
                    
                } else {  
   if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
       
                        c7(getString(R.string.u15));
} else {
         c53(getString(R.string.u16));
}
}
break;
case 4:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
    
c55(h.getUrl(),h.getTitle());
                  
                } else {  
   if (shouldShowRequestPermissionRationale( Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
       
                        c7(getString(R.string.u15));
} else {
         c53(getString(R.string.u16));
}
}
break;
case 5:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 

                    
                } else {  
   if (shouldShowRequestPermissionRationale( Manifest.permission.ACCESS_FINE_LOCATION)) {
       
                        c7(getString(R.string.w4));
} else {
         c53(getString(R.string.w5));
}
}
break;
            case 6:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
h.reload();
                } else {  
       
                        if (shouldShowRequestPermissionRationale( Manifest.permission.CAMERA)) {
                            c7(getString(R.string.j22));
                        } else {
         c53(getString(R.string.j23));
}
                   
              }
              break; 
            case 7:
                if (c.length > 0 && c[0] == PackageManager.PERMISSION_GRANTED) { 
h.reload();
                } else {  
       
                        if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                            c7(getString(R.string.j24));
                        } else {
         c53(getString(R.string.j25));
}
                   
              }
              break; 
         }
    }
 
     public boolean onKeyDown(int a, KeyEvent b) {
        if (a == KeyEvent.KEYCODE_VOLUME_UP) {
            if (sp.getString("VU", "").length() == 0) {
                c125(1);
                return true;
            } else if (sp.getString("VU", "").equals("1u")) {
                c125(1);
                return true;
            } else if (sp.getString("VU", "").equals("7u")) {
                h.pageUp(true); 
                return true;
            } else if (sp.getString("VU", "").equals("30u")) {
                h.zoomIn();
                return true;
            } else if (sp.getString("VU", "").equals("60u")) {
                if (h.canGoBack()) {
                    h.goBack();
                }
                return true;
            } else if (sp.getString("VU", "").equals("120u")) {
                h.reload();
                return true;
            } else if (sp.getString("VU", "").equals("140u")) {
                C1.f(this, this, A15.class, 211);
                return true;
            }
            return false;
        } else if (a == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (sp.getString("VD", "").length() == 0) {
                c125(0);
                return true;
            } else if (sp.getString("VD", "").equals("1v")) {
                c125(0);
                return true;
            } else if (sp.getString("VD", "").equals("7v")) {
                h.pageDown(true); 
                return true;
            } else if (sp.getString("VD", "").equals("30v")) {
                h.zoomOut();
                return true;
            } else if (sp.getString("VD", "").equals("60v")) {
                if (h.canGoForward()) {
                    h.goForward();
                }
                return true;
            } else if (sp.getString("VD", "").equals("120v")) {
                h.stopLoading();
                return true;
            } else if( sp.getString("VD", "").equals("140v")) {
                C1.f(this, this, A1.class, 211);
                return true;
            }
            return false;
        }
        return super.onKeyDown(a, b);
    }

    public boolean onKeyUp(int a, KeyEvent b) {
        if (a == 4 && b.isTracking() && !b.isCanceled()) {
            if (!h.canGoBack()) {
                c25();
                moveTaskToBack(true);
            } else {
                h.goBack();
            }
            return true;
        }
        return super.onKeyUp(a, b);
    }

    public boolean onKeyLongPress(int a, KeyEvent b) {
        if (a == 4 && !b.isCanceled()) {
            if (sp.getString("longP", "").length() == 0) {
                c25();
                moveTaskToBack(true);
                return true;
            }
            if (sp.getString("longP", "").equals("1p")) {
                c25();
                moveTaskToBack(true);
                return true;
            }
            if (sp.getString("longP", "").equals("7p")) {
                c48();
                return true;
            }
            if (sp.getString("longP", "").equals("30p")) {
                h.reload();
                return true;
            }
            if (sp.getString("longP", "").equals("60p")) {
                if (!h.canGoBack()) {
                    c25();
                    moveTaskToBack(true);
                } else {
                    h.goBack();
                }
                return true;
            }
            return false;
        }
        return super.onKeyLongPress(a, b);
    }

    public boolean onCreateOptionsMenu(Menu a) {

	    getMenuInflater().inflate(R.menu.a, a);
        return super.onCreateOptionsMenu(a);
    }

public boolean onPrepareOptionsMenu(Menu a) {
   if (ua == true) {
a.findItem(R.id.a7).setChecked(true);
}
         
         

/*
MenuItem mis = a.findItem(R.id.h3);
final SearchView sv5 = (SearchView)
mis.getActionView();
 sv5.setQueryHint(getString(R.string.e));
SearchAutoComplete searchAutoComplete = (SearchAutoComplete) sv5.findViewById(android.R.id.search_src_text);
 if (sp.getBoolean("tstt", false) == true) {
mis.setVisible(true);
    } else {
                    mis.setVisible(false);
                }
        
 if (sp.getBoolean("autoUpdate", false) == false) {
            mis.setIcon(C5.a(this, R.drawable.a)); 
} else {
mis.setIcon(C5.a(this, R.drawable.a)); 
}
        if (sp.getBoolean("autoUpdate", false) == false) {
searchAutoComplete.setHintTextColor(C5.b(this,R.color.j));
searchAutoComplete.setTextColor(C5.b(this,R.color.c));
} else {
searchAutoComplete.setHintTextColor(C5.b(this,R.color.k));
searchAutoComplete.setTextColor(C5.b(this,R.color.b));
}

           searchAutoComplete.setTypeface(G1.a(this, 100));
           
sv5.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
							   
						      c49(query);
d2.c(query, A21.this);
 sv5.clearFocus();
							    return false;
						}
						public boolean onQueryTextChange(String newText) {
								return false;
						}
       });*/
 return true;
}

    public boolean onOptionsItemSelected(MenuItem a) {
 final String ulr = h.getUrl();
        switch (a.getItemId()) {
case R.id.k5:
c119();
return true;
case R.id.l1:
c112(ulr,6);
return true;
case R.id.l12:
c130();
return true;
case R.id.k18:
c127();
return true;
case R.id.k7:
c112(ulr, 5);
return true;
case R.id.k8:
c112(ulr,4);
return true;
case R.id.c14:
c112(ulr,8);
return true;
case R.id.k17:
c122();
return true;
case R.id.k15:
c123();
return true;
            case R.id.t:
                System.exit(0);
                c25();
                return true;
            case R.id.g10:
                c100(h);
                return true;
            case R.id.a11:
 
c112(ulr, 7);
                return true;
       case R.id.h9:
                c5(new File(I3.c()));
                return true;
            case R.id.w:
                c16(h.getUrl(), 0);
                return true;
            case R.id.g9:
//new tab

                return true;
            case R.id.a7:
               if (a.isChecked()) {
                    a.setChecked(false);
ua = false;
                    c20(false);
                } else {
                    a.setChecked(true);
ua = true;
                    c20(true);
                }
                
                return true;
            case R.id.b5:
                c47();
                return true;
            case R.id.g6:
 if (M2.a(this, M2.STORAGE, 4) == true) {
                    
c55(h.getUrl(),h.getTitle());
                  
}
                return true;
            case R.id.u:
                          C1.k(A21.this, "android.intent.action.VIEW_DOWNLOADS");
                return true;
            case R.id.a9:
                c67();
                return true;
            case R.id.a10:
          
c43(h.getUrl());
                return true;
            case R.id.a13:
                C1.a(A21.this,  A19.class);

                return true;
            case R.id.f1:
C1.f(A21.this, A21.this, A15.class, 2115);

                return true;
            case R.id.a4:
C1.f(A21.this, A21.this, A1.class, 211);

                return true;
            case R.id.h1:
        Intent d = new Intent(Intent.ACTION_GET_CONTENT);
            d.addCategory(Intent.CATEGORY_OPENABLE);
        d.setType("*/*");
if (d.resolveActivity(getPackageManager()) != null) { 
        startActivityForResult(Intent.createChooser(d, getString(R.string.a26)), 3);
}

                return true;
            case R.id.f19:
                 if (M2.a(this, M2.STORAGE, 3) == true) {
                                                      V2.b(A21.this, A21.this.back23);
      c68(A21.this.back23);
                              }

                return true;
            case R.id.f5:
c58(h.getUrl(), h.getTitle());
             return true;
    case R.id.h5:
        
 
c112(ulr,0);
 
             return true;
    case R.id.h6:
 
c112(ulr, 1);
 
             return true;
    case R.id.h7:
 
c112(ulr, 2);
 
             return true;
    case R.id.h8:
  

c112(ulr, 3);
 
             return true;
                    case R.id.f13:
                        c14(h.getTitle(),h.getUrl());

                   return true;
            default:
                return super.onOptionsItemSelected(a);
        }
    }

    public void onConfigurationChanged(Configuration a){
        super.onConfigurationChanged(a);
        on = a.orientation;
        U1.a("A21 || Configuration Changed || "+ Integer.toString(on));
        invalidateOptionsMenu();
    }

    protected void onNewIntent(Intent a) {
        try {
            if (a.getStringExtra("webview") != null) {
                c49(a.getStringExtra("webview"));
                a.removeExtra("webview");
            } else if (a.getStringExtra("value") != null) {
                c49(a.getStringExtra("value"));
                a.removeExtra("value");
            } else if (a.getAction().equals(Intent.ACTION_SEND)) {
                c49(a.getStringExtra(Intent.EXTRA_TEXT));
            } else if (a.getAction().equals(Intent.ACTION_VIEW) || a.getAction().equals(com.android.DROID_MJ.webview.WebView.Intent.ACTION_VIEW)) {
                c49(a.getDataString());
            } else if (a.getAction().equals(MediaStore.INTENT_ACTION_MEDIA_SEARCH)) {
                c49(a.getStringExtra(MediaStore.EXTRA_MEDIA_ARTIST) + " " + a.getStringExtra(MediaStore.EXTRA_MEDIA_TITLE));
            } else if (a.getAction().equals(Intent.ACTION_MAIN)) {
                return;
            }
            a.replaceExtras(new Bundle());
            a.setAction("");
            a.setData(null);
            a.setFlags(0);     
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void onWindowFocusChanged(boolean a) {
        super.onWindowFocusChanged(a);
        if (a && bl3) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        if (sp.getString("hide", "").equals("30d") ) {
            if (a) {
                c97();
            } else {
                c98();
            }
        } else {
            c98();
        }
    }

    public void onTrimMemory(int i) {
        switch (i) {
            case ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL:
                U1.a("Memory is Running Critical");
                System.gc();
            break;
            case ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW:
                U1.a("Memory is Running Low");
                System.gc();

            break;
            case ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE:
                U1.a("Memory is Running Moderate");
                System.gc();
            break;
            default:
                System.gc();
            break;
        }
    }

}