package com.android.DROID_MJ.A;

// ASSISTANT ACTIVITY


import android.content.SharedPreferences;
import android.app.Activity;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.EditText;
import com.android.DROID_MJ.C.C5;
import android.widget.ImageView;
import android.view.KeyEvent;
import android.view.View;  
import com.android.DROID_MJ.C.C9;
import android.widget.TextView.OnEditorActionListener;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.C.C1;
import android.view.inputmethod.EditorInfo;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import com.android.DROID_MJ.V.V2;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.widget.TextView;
import com.android.DROID_MJ.D.D2;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;


public class A9 extends Activity  {
    private static RelativeLayout gjj;
    private static EditText ljg1;
        
        
    
    
    protected void onCreate(Bundle a) {
        final SharedPreferences b = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (b.getBoolean("autoUpdate", false) == false) {
            setTheme(R.style.m);
        } else {
            setTheme(R.style.n);
        }
        

O8.b();
super.onCreate(a);
        
setContentView(R.layout.a2);
        
        
        
        
        gjj = (RelativeLayout) findViewById(R.id.f18);
        ljg1 = (EditText) findViewById(R.id.g2);
        LinearLayout f20 = (LinearLayout) findViewById(R.id.f20);
        ImageView ljg2 = (ImageView) findViewById(R.id.g3);
  
        int d = C5.b(this,R.color.c);
   
int f = C5.b(this,R.color.j);

        ljg1.setHint(getString(R.string.e));
        ljg2.setImageResource(R.mipmap.b);

           ljg1.setTextColor(d);
           ljg1.setHintTextColor(f);

f20.setBackgroundResource(R.drawable.b22);

        Typeface tf2 = G1.a(this, 100);
ljg1.setTypeface(tf2);
        f20.setOnClickListener(new C9() {
            public void a(View a) {
                V2.a(A9.this, ljg1);
            }
        });

        gjj.setBackgroundResource(R.drawable.b23);
        gjj.setOnClickListener(new C9() {
            public void a(View a) {
                V2.b(A9.this, gjj);
            }
        });
        ljg1.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(android.widget.TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    V2.b(A9.this, gjj);
                    String query = ljg1.getText().toString();
                    String querkj = query.replaceAll(" ", "");
                    if (querkj.length() !=0) {
 C1.e(A9.this, "value", query, A21.class);
    D2 d2 = D2.getInstance(A9.this);
d2.c(query, A9.this);

                       finish();

                    }
                    handled = true;
              }
              return handled;
            }

        });

    }

    protected void onStop() {
        super.onStop();
        V2.b(this, gjj);
    }
protected void onResume() {
super.onResume();
if (PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getBoolean("qwe73", false) == true) {
System.gc();
}
}
 
}
