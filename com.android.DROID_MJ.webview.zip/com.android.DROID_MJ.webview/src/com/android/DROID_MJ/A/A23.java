package com.android.DROID_MJ.A;
import android.app.Application;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O8;
public class A23 extends Application {
    public void onCreate() {
 
O8.b();

super.onCreate();
        a();

    }

    public void a() {
      
    }
 
}