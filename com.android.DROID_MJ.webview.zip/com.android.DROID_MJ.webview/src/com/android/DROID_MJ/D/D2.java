package com.android.DROID_MJ.D;

 // SEARCH DATABASE

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.android.DROID_MJ.W.W14;
import android.database.Cursor;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.U.U1;
import android.content.ContentValues;
import android.content.SharedPreferences;
import com.android.DROID_MJ.U.U3;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.W.W13;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.W.W5;
public class D2 extends SQLiteOpenHelper {

private static D2 d2 = null;
private static Executor er = Executors.newCachedThreadPool();
 private static SharedPreferences sp;
    public static D2 getInstance(Context ctx) {
        if (d2 == null) {
            d2 = new D2(ctx.getApplicationContext());
            sp =  PreferenceManager.getDefaultSharedPreferences(ctx.getApplicationContext());
        }
        return d2;
    }
 
    public D2(Context context) {
        super(context, W14.j()+".db", null, W5.h());
        U1.a("D2 Created");
    }
    
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + W14.d() + " (" +
   W14._ID + " INTEGER PRIMARY KEY," +
    W14.e() + " TEXT)");
    }
    
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " +W14.d());
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       onUpgrade(db, oldVersion, newVersion);
    }

     public Cursor a() {
        Cursor res = getReadableDatabase().rawQuery("SELECT * FROM "+W14.d() +" ORDER BY " + W14._ID +" DESC",null);
        return res;
    }

    public void b(String a) {
        getWritableDatabase().delete(W14.d(), W14.e() +"=?", new String[]{a});

    }

    public void c(final String a,final Context ct) {
final SQLiteDatabase sld = getWritableDatabase();
        
 P15 p = new P15() {
    public void a() {

        if (U3.b(a, 0) == true) {
            
            if (sp.getBoolean("pSearch", false) == false) {
                if (W13.b(a.toLowerCase()) == true) {
                    
                            ContentValues vlues = new ContentValues();
                            vlues.put(W14.e(), a);
                            sld.insert(W14.d(), null, vlues);
        
                    
                }
            }
        }

}
};
er.execute(new Thread(p));

    }


    public void d() {
    SQLiteDatabase db = getReadableDatabase();
    if (db != null && db.isOpen())
        db.close();
}


public void e() {
    SQLiteDatabase db = getWritableDatabase();
        db.delete(W14.d(), null, null);
}
}

