package com.android.DROID_MJ.D;

// HISTORY DATABASE
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.android.DROID_MJ.W.W14;
import android.database.Cursor;
 
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.U.U1;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U3;
import com.android.DROID_MJ.W.W13;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.P.P15;
import com.android.DROID_MJ.W.W5;
public class D1 extends SQLiteOpenHelper {

    private static D1 d1 = null;
private static Executor er = Executors.newCachedThreadPool();
        private static SharedPreferences sp;
    public static D1 getInstance(Context ctx) {
        if (d1 == null) {
            d1 = new D1(ctx.getApplicationContext());
            sp =  PreferenceManager.getDefaultSharedPreferences(ctx.getApplicationContext());
 
        }
        return d1;
    }
 
    public D1(Context context) {
        super(context, W14.i()+".db", null, W5.h());
        U1.a("D1 Created");
    }


    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + W14.a() + " (" + W14._ID + " INTEGER PRIMARY KEY," + W14.b() + " TEXT," +  W14.c() + " TEXT)");
    }
    
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " +W14.a());
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       onUpgrade(db, oldVersion, newVersion);
    }

    public Cursor a() {
        Cursor res = getReadableDatabase().rawQuery("SELECT * FROM "+W14.a() +" ORDER BY " + W14._ID +" DESC",null);
        return res;
    }

    public void b(String a, String b) {
        getWritableDatabase().delete(W14.a(), W14.b() +"=? and " + W14.c() +"=? " , new String[]{b, a});
    }

    public void c(final String a, final String b, final Context ct) {
final SQLiteDatabase sld = getWritableDatabase();
        
 P15 p = new P15() {
    public void a() {

        if (sp.getBoolean("pHistory", false) == false ){
            if (W13.b(a.toLowerCase()) == true) {
                if (W13.b(b.toLowerCase()) == true) {
                    if (U3.b(a, 0) == true ) {
                        if (U3.b(b, 0) == true) {
        
                            ContentValues values = new ContentValues();
                            values.put(W14.b(), a);
                            values.put(W14.c(), b);
                            sld.insert(W14.a(), null, values);
                        }
                    }
                }
            }
        }

}
};
er.execute(new Thread(p));

    }


    public void d() {
    SQLiteDatabase db = getReadableDatabase();
    if (db != null && db.isOpen())
        db.close();
}


public void e() {
    SQLiteDatabase db = getWritableDatabase();
        db.delete(W14.a(), null, null);
}
}