package com.android.DROID_MJ.D;

  // BOOKMARK DATABASE

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.android.DROID_MJ.W.W14;
import android.database.Cursor;
import com.android.DROID_MJ.U.U4;
import android.content.ContentValues;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.U.U3;
import com.android.DROID_MJ.P.P15;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.W.W5;
public class D3 extends SQLiteOpenHelper {
 
private static D3 d3 = null;
private static Executor er = Executors.newCachedThreadPool();

    public static D3 getInstance(Context ctx) {
        if (d3 == null) {
            d3 = new D3(ctx.getApplicationContext());
        }
        return d3;
    }
 

    public D3(Context context) {
        super(context, W14.k()+".db", null, W5.h());
        U1.a("D3 Created");
    }
    
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + W14.f() + " (" +
   W14._ID + " INTEGER PRIMARY KEY," +
    W14.g() + " TEXT," +
    W14.h() + " TEXT)");
    }
    
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " +W14.f());
       onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       onUpgrade(db, oldVersion, newVersion);
    }

     public Cursor a() {
 
        Cursor res = getReadableDatabase().rawQuery("SELECT * FROM "+W14.f() +" ORDER BY " + W14._ID +" DESC",null);
        return res;
    }

    public void b(String a, String b) {

        getWritableDatabase().delete(W14.f(), W14.g() +"=? and " + W14.h() +"=? " , new String[]{b, a});

    }

    public void c(final String a, final String b) {
final SQLiteDatabase sld = getWritableDatabase();  
        
P15 p = new P15() {
    public void a() {

        if (U3.b(b, 0) == true) {
        
            ContentValues values = new ContentValues();
            values.put(W14.g(), a);
            values.put(W14.h(), b);
            sld.insert(W14.f(), null, values);
        }
}

};
er.execute(new Thread(p));
}
    public void d() {
    SQLiteDatabase db = getReadableDatabase();
    if (db != null && db.isOpen())
        db.close();
}


public void e() {
    SQLiteDatabase db = getWritableDatabase();
        db.delete(W14.f(), null, null);
}
    }
