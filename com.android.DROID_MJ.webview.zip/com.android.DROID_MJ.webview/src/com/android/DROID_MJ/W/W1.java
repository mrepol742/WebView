package com.android.DROID_MJ.W;

import android.content.Context;
import android.widget.Toast;
import android.app.Activity;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;
import android.view.ViewGroup;
import com.android.DROID_MJ.webview.R;
import android.view.Gravity;
import android.graphics.Typeface;
public class W1 {
   
    public static void a(Context a, String b, int c) {
        Toast.makeText(a.getApplicationContext(), b, c).show();
    }

    public static void a(Context a, String b) {
        Toast.makeText(a.getApplicationContext(), b, 0).show();
    }
// success
    public static void b(Activity a, String b55) {
        View b = a.getLayoutInflater().inflate(R.layout.h, (ViewGroup) a.findViewById(R.id.b13));
        Typeface c = G1.a(a, 100);
        ((TextView) b.findViewById(R.id.b14)).setText(b55);
        ((TextView) b.findViewById(R.id.b14)).setTypeface(c);
        Toast d = new Toast(a.getApplicationContext());
        d.setDuration(0);
        d.setView(b);
        d.show();
    }
// failed
    public static void c(Activity a, String bgg) {
        View b = a.getLayoutInflater().inflate(R.layout.g, (ViewGroup) a.findViewById(R.id.b11));
        Typeface c = G1.a(a, 100);
        ((TextView) b.findViewById(R.id.b12)).setText(bgg);
        ((TextView ) b.findViewById(R.id.b12)).setTypeface(c);
        Toast d = new Toast(a.getApplicationContext());
        d.setDuration(0);
        d.setView(b);
        d.show();
    }

    public static void d(Activity a, String b55) {
        View b = a.getLayoutInflater().inflate(R.layout.h, (ViewGroup) a.findViewById(R.id.b13));
        Typeface c = G1.a(a, 100);
        ((TextView) b.findViewById(R.id.b14)).setText(b55);
        ((TextView) b.findViewById(R.id.b14)).setTypeface(c);
        Toast d = new Toast(a.getApplicationContext());
        d.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        d.setDuration(Toast.LENGTH_LONG);
        d.setView(b);
        d.show();
    }

// failed
    public static void e(Activity a, String bgg, int bb) {
        View b = a.getLayoutInflater().inflate(R.layout.g, (ViewGroup) a.findViewById(R.id.b11));
        Typeface c = G1.a(a, 100);
        ((TextView) b.findViewById(R.id.b12)).setText(bgg);
        ((TextView ) b.findViewById(R.id.b12)).setTypeface(c);
        Toast d = new Toast(a.getApplicationContext());
        d.setDuration(bb);
        d.setView(b);
        d.show();
    }
// success
    public static void f(Activity a, String b55, int bb) {
        View b = a.getLayoutInflater().inflate(R.layout.h, (ViewGroup) a.findViewById(R.id.b13));
        Typeface c = G1.a(a, 100);
        ((TextView) b.findViewById(R.id.b14)).setText(b55);
        ((TextView) b.findViewById(R.id.b14)).setTypeface(c);
        Toast d = new Toast(a.getApplicationContext());
        d.setDuration(bb);
        d.setView(b);
        d.show();
    }
}