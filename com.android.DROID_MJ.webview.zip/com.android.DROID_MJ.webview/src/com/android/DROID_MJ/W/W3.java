package com.android.DROID_MJ.W;

import android.webkit.WebView;
import com.android.DROID_MJ.A.A6;
import android.graphics.Bitmap;

public class W3 extends W22 {

    public boolean f(WebView a, String b) {
        return A6.getInstance().a(a, b);
    }
}
