package com.android.DROID_MJ.W;

import android.content.Context;
import android.webkit.JavascriptInterface;



public class W8 {
    public static Context a;

    public W8(Context c) {
       a = c;
    }

    @JavascriptInterface
    public void showToast(String c) {
        W9.a(a, c, 0, 0);
    }

    @JavascriptInterface
    public void showToastError(String c) {
        W9.a(a, c, 1, 0);
    }

    @JavascriptInterface
    public void showToastSuccess(String c) {
        W9.a(a, c, 2, 0);
    }

    @JavascriptInterface
    public void showToast(String c, int b) {
        W9.a(a, c, 0, b);
    }

    @JavascriptInterface
    public void showToastError(String c, int b) {
        W9.a(a, c, 1, b);
    }

    @JavascriptInterface
    public void showToastSuccess(String c, int b) {
        W9.a(a, c, 2, b);
    }

    @JavascriptInterface
    public void copyToClipboard(String c) {
        W9.b(a, c);
    }
 
    @JavascriptInterface
    public void vibrate(int c) {
        W9.c(a, c);
    }

    @JavascriptInterface
    public void enableWifi(boolean c) {
        W9.d(a, c);
    }
 
    @JavascriptInterface
    public void exit() {
       W6.a();
    }

    @JavascriptInterface
    public void showNotification(String b, String c, String d) {
        W9.f(a, b, c, d);
    }

    @JavascriptInterface
    public void enableFlashlight(boolean c) {
        W9.g(a, c);
    }
}