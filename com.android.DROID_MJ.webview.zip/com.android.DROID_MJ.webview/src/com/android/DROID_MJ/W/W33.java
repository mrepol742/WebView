package com.android.DROID_MJ.W;
import android.webkit.WebView;
import com.android.DROID_MJ.A.A16;

public class W33 extends W23 {
    private static A16 a16;

    public W33() {
        a16 = A16.getInstance();
    }
    public void g(WebView a, int b) {
        a16.k(a, b);
    }
}


