package com.android.DROID_MJ.W;
import android.graphics.Bitmap;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import com.android.DROID_MJ.A.A21;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.os.Build;
import android.os.Message;

public class W21 extends W23 {

    private static A21 a21;

    public W21() {
        a21 = A21.getInstance();
    }

    public Bitmap a() {
        return a21.c84();
    }
 
// on receive title
    public void c(WebView a, String b) {
        a21.c86(a, b);
    }
// on hide custom view
    public void d() {
        a21.c87();
    }
// on show custom view
    public void e(View a, WebChromeClient.CustomViewCallback b) {
        a21.c88(a, b);
    }
// on show file chooser
    public boolean f(WebView a, ValueCallback<Uri[]> b, WebChromeClient.FileChooserParams c) {
        return a21.c89(a, b, c);
    }

    public void g(WebView a, int b) {
        a21.c90(a, b);
    }

    public boolean h(WebView a, String b, String c, final JsResult d) { 
        return a21.c91(a, b, c, d);  
    }

    public boolean i(WebView a, String b, String c, String d, final JsPromptResult e) {
        return a21.c92(a, b, c, d, e);  
    }

    public boolean j(WebView a, String b, String c, final JsResult e) {
        return a21.c93(a, b, c, e);  
    }

    public boolean k(WebView a, String b, String c, final JsResult e) {
        return a21.c94(a, b, c, e); 
    }

    public boolean l(String a, int b, String c) { 
        return a21.c95(a, b, c); 
    }

    public void m( String a,  GeolocationPermissions.Callback b) {
        a21.c96(a, b); 
    }

    public void p(WebView a, Message b, Message c) {
        a21.c4(a, b, c);
    }

    public void q(PermissionRequest pr) {
        a21.c129(pr);
    }

    public void r(WebView a, Bitmap b) {
        a21.c135(a, b);
    }
}


