package com.android.DROID_MJ.W;
import com.android.DROID_MJ.A.A27;

public class W27 extends W23 {
    public boolean l(String a, int b, String c) { 
        return A27.getInstance().b(a);
    }
}