package com.android.DROID_MJ.W;
import android.widget.TextView;

public class W20 {
    TextView a;
TextView b;
}