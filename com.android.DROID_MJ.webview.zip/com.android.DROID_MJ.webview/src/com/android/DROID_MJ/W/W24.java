package com.android.DROID_MJ.W;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import java.io.InputStream;
import android.view.View;
import android.util.AttributeSet;
import android.annotation.TargetApi;

public class W24 extends View {
    private static InputStream is;
    private static Movie me;
    private static long lg;
    private static long lg1;
    private static int it;
    private static int it1;

    public W24(Context ct) {
        super(ct);

    }
    public W24(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public W24(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
  
    @TargetApi(21)
    public W24(Context context, AttributeSet attrs, int defStyle, int b) {
        super(context, attrs, defStyle, b);
    }

    public void a(Context ct, int it) {
        setFocusable(true);
        is = ct.getResources().openRawResource(it);
        me = Movie.decodeStream(is);
        lg = me.duration();
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(it, it1);
    }


    protected void onDraw(Canvas cv) {
        long a = android.os.SystemClock.uptimeMillis();
        if (lg1 == 0) {
            lg1 = a;
        }
        if (me != null) {
            int i = me.duration();
            if (i == 0) {
                i = 1000;
            }
            int rt = (int)((a - lg1) % i);
            me.setTime(rt);
            me.draw(cv, 0, 0);
            invalidate();
        }


    }
} 