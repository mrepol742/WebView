package com.android.DROID_MJ.W;

import android.webkit.WebView;

public class W7 extends W22 {

    public boolean f(WebView webView, String str) {
        return false;
    }
}
