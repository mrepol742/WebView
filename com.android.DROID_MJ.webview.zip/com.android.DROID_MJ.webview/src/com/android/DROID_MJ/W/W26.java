package com.android.DROID_MJ.W;

import android.webkit.WebView;
import android.graphics.Bitmap;
import com.android.DROID_MJ.A.A27;

public class W26 extends W22 {

    public void a(WebView a, int b, String c, String d) {
        A27.getInstance().a();
    }

    public boolean f(WebView a, String b) {
        return false;
    }
}
