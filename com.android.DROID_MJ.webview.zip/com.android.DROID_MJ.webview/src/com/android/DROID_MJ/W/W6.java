package com.android.DROID_MJ.W;

public class W6 {
    public static void a() {
        System.exit(0);
    }
}