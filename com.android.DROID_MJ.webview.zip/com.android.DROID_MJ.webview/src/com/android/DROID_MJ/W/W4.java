package com.android.DROID_MJ.W;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebView;
import android.annotation.TargetApi;

public class W4 extends WebView {

    public W4(Context context) {
        super(context);
    }
    public W4(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public W4(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @TargetApi(21)
    public W4(Context context, AttributeSet attrs, int defStyle, int b) {
        super(context, attrs, defStyle, b);
    }
}