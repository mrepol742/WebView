package com.android.DROID_MJ.W;

import android.content.Context;
import com.android.DROID_MJ.N.N1;
import com.android.DROID_MJ.V.V1;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.webview.R;
import android.view.View; 
import com.android.DROID_MJ.U.U1;

public class W11 {
    private static A21 a21;
    public W11() {
        a21 = A21.getInstance();
    }

    public static void a(Context a) {
        try {
            if (a21.bl2 == false) {
                return;
            }
            if (N1.a(a) == false) {
                if (N1.b(a) == false) {
                    a21.tv.setImageResource(R.drawable.a3);
                    a21.tv.setVisibility(View.VISIBLE);
                    a21.h.setNetworkAvailable(false);
                } else {
                    a21.tv.setImageResource(R.drawable.a4);
                    a21.tv.setVisibility(View.VISIBLE);
                    a21.h.setNetworkAvailable(false);
                }
            } else {
                a21.tv.setVisibility(View.GONE);
                a21.h.setNetworkAvailable(true);
            } 
        } catch (Exception rx) {
            U1.a(rx);
        }
    }
}