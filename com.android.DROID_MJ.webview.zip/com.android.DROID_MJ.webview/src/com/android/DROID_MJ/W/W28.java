package com.android.DROID_MJ.W;

public class W28 {

public int a;
public CharSequence b;
public CharSequence c;

    public W28(int start, CharSequence before, CharSequence after) {
        a = start;
        b = before;
        c = after;
    }
}