package com.android.DROID_MJ.W;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.android.DROID_MJ.U.U1;

public class W30 {
       private static PackageInfo b;
    public static String a(Context a) {
        return a.getApplicationContext().getPackageName();
    }

    public static String b(Context a) {
        return a.getApplicationInfo().loadLabel(a.getPackageManager()).toString();
    }

    public static PackageInfo c(Context a) {
  
        try {

 b = a.getPackageManager().getPackageInfo(a.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            U1.a(e);
        }
        return b;
    }


     public static PackageInfo d(Context a) {
  
        try {

 b = a.getPackageManager().getPackageInfo("com.google.android.webview", 0);
        } catch (PackageManager.NameNotFoundException e) {
            U1.a(e);
        }
        return b;
    }
}