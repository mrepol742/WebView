package com.android.DROID_MJ.W;
import com.id;

public final class W5 {
private static String mrepol_security_api() {
    return "327e95ed63f34e98ad77febc45e2ea4b9af276c6ce1ade2f98039c577cbbe89807ad21e042e284f21cedw4900b0c0229843edd035301209fcc2d6d17e0dc9e34";
}
private static String package_signature() {
return "3edfc7d3a787e93c0df30955741b1838625bbf9e5fbed4b1bc337156a6eba6e3bec4b75ff1bcc3cafad0201eedb2842450b64fa31fe1d9f71a3848563b8bd8fd";
}
private static String app_authentication_api() {
return "7146621129cdbd8347cb1afbff0s9890b0e755d4d18fc9f5a6b87529544952666e6bb002f5bddb8aaf07616320720b5b1e41fbeafd2f146a3b383fdc4b0fd01e";
}
private static String synchronization_sec_351() {
 return "9edc68aa1db4ab07b018b77631e28877d2c27cd1b441d599c181170d22e6932263c347d5be29057b80d4d63c5y5aabd2199947d1175eb064d65390787e979976";
}
// cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e

// 1e6c9ed007fbea23611c72950a561312e3a25bdd
public static String a() {
return "cc8d7e1a218801c3fbd0ffda3ecd7b27867d6a6a283c2bb2928b92b877d805e3727723f7e79ef9c5b3451f5d55bdf971f8566b50779bc8ec5b2abd56f7abe599";
}
// com.android.DROID_MJ.webview
public static String b() {
return "4ec1b627fb243da13ec3a142f069af3a2fbd18510bda4e22caab29f5731de4674a633835819ee059008e8853875535f6ca4f8e5436b45c77f183474bcecab7fd";
}
// WebView 
public static String c() {
return "ce7f9e22781b5563da1247f85e82e2003ca11fdf18705fce7d314337a348b7d7777f08b099f4b2aa820e6b7ec0daa3b69491d0ab6d314a416b9f8af5e2222c14";
}

public static String d() {
return "5.2.0";
}

// app current version
public static int e() {
return id.b;
}
// 
public static String f() {
return "";
}
//https://raw.githubusercontent.com/mrepol742/WebView/master/Services/push_notification/notification.txt
public static String g() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9wdXNoX25vdGlmaWNhdGlvbi9ub3RpZmljYXRpb24udHh0";
}
// 1
public static int h() {
return 1;
}
// https://mrepol.000webhostapp.com/webview/app_name/RvhjMhoRZrKMFc.droidmj.php
public static String i() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9hcHBfbmFtZS9SdmhqTWhvUlpyS01GYy5kcm9pZG1qLnBocA==";
}
// https://mrepol.000webhostapp.com/webview/package_key/NFPcgJmAPSRGr.droidmj.php
public static String j() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9wYWNrYWdlX2tleS9ORlBjZ0ptQVBTUkdyLmRyb2lkbWoucGhw";
}
// https://mrepol.000webhostapp.com/webview/package_name/SXrGYfTpJb.droidmj.php
public static String k() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9wYWNrYWdlX25hbWUvU1hyR1lmVHBKYi5kcm9pZG1qLnBocA==";
}
//  https://mrepol.000webhostapp.com/webview/user_agree_to&terms=true&privacy=true/RDkhAlOzobixB.droidmj.php
public static String l() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy91c2VyX2FncmVlX3RvJnRlcm1zPXRydWUmcHJpdmFjeT10cnVlL1JEa2hBbE96b2JpeEIuZHJvaWRtai5waHA=";
}

//https://raw.githubusercontent.com/mrepol742/WebView/master/Services/auto_update/version_name_int.droidmj.txt
public static String m() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9hdXRvX3VwZGF0ZS92ZXJzaW9uX25hbWVfaW50LmRyb2lkbWoudHh0";
}

// title
// https://raw.githubusercontent.com/mrepol742/WebView/master/Services/push_notification/content_title.droidmj.txt
public static String n() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9wdXNoX25vdGlmaWNhdGlvbi9jb250ZW50X3RpdGxlLmRyb2lkbWoudHh0";
}

// content
// https://raw.githubusercontent.com/mrepol742/WebView/master/Services/push_notification/content_text.droidmj.txt
public static String o() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9wdXNoX25vdGlmaWNhdGlvbi9jb250ZW50X3RleHQuZHJvaWRtai50eHQ=";
}

// action
// https://raw.githubusercontent.com/mrepol742/WebView/master/Services/push_notification/content_intent_extra.droidmj.txt
public static String p() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9wdXNoX25vdGlmaWNhdGlvbi9jb250ZW50X2ludGVudF9leHRyYS5kcm9pZG1qLnR4dA==";
}

// notif enable/disabled
// https://raw.githubusercontent.com/mrepol742/WebView/master/Services/push_notification/status.droidmj.txt
public static String q() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9wdXNoX25vdGlmaWNhdGlvbi9zdGF0dXMuZHJvaWRtai50eHQ=";
}

// update dl link
// https://raw.githubusercontent.com/mrepol742/WebView/master/Services/auto_update/download_url.droidmj.txt
public static String r() {
return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy9hdXRvX3VwZGF0ZS9kb3dubG9hZF91cmwuZHJvaWRtai50eHQ=";
}
 // app data dir
public static String s() {
return "L2RhdGEvZGF0YS9jb20uYW5kcm9pZC5EUk9JRF9NSi53ZWJ2aWV3Lw==";
}
// build number
public static String t() {
return "05012020";

}

//https://droidmj.000webhostapp.com/terms/
public static String u() {
 return "aHR0cHM6Ly9kcm9pZG1qLjAwMHdlYmhvc3RhcHAuY29tL3Rlcm1zLw==";
}
//https://droidmj.000webhostapp.com/privacy/
public static String v() {
 return "aHR0cHM6Ly9kcm9pZG1qLjAwMHdlYmhvc3RhcHAuY29tL3ByaXZhY3kv";
}

// https://mrepol.000webhostapp.com/webview/view_ip/ftyDpfQredtLfg.droidmj.php
public static String w() {
 return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy92aWV3X2lwL2Z0eURwZlFyZWR0TGZnLmRyb2lkbWoucGhw";
}
//https://raw.githubusercontent.com/mrepol742/WebView/master/Services/unauthorized/hello_world.droidmj.txt

public static String x() {
 return "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21yZXBvbDc0Mi9XZWJWaWV3L21hc3Rlci9TZXJ2aWNlcy91bmF1dGhvcml6ZWQvaGVsbG9fd29ybGQuZHJvaWRtai50eHQ=";
}

// https://mrepol.000webhostapp.com/webview/headers/WlNdIDUeHzRl.droidmj.php?url=
public static String y() {
 return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9oZWFkZXJzL1dsTmRJRFVlSHpSbC5kcm9pZG1qLnBocD91cmw9";
}

// https://mrepol.000webhostapp.com/webview/links/RjcbPpGcCoZDO.droidmj.php?url=
public static String z() {
 return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9saW5rcy9SamNiUHBHY0NvWkRPLmRyb2lkbWoucGhwP3VybD0=";
}

// https://mrepol.000webhostapp.com/webview/meta_tag/XsbuSMQOehYiW.droidmj.php?url=
public static String a1() {
 return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9tZXRhX3RhZy9Yc2J1U01RT2VoWWlXLmRyb2lkbWoucGhwP3VybD0=";
}

// https://mrepol.000webhostapp.com/webview/report/NkzzdAqWTDtVCJ.droidmj.php?a=
public static String a2() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9yZXBvcnQvTmt6emRBcVdURHRWQ0ouZHJvaWRtai5waHA/YT0=";
}

public static String a3() {

return id.c;
}
//https://droidmj.000webhostapp.com/webview
public static String a4() {

return "aHR0cHM6Ly9kcm9pZG1qLjAwMHdlYmhvc3RhcHAuY29tL3dlYnZpZXc=";
}
//https://fb.me/mrepol742
public static String a5() {

return "aHR0cHM6Ly9mYi5tZS9tcmVwb2w3NDI=";
}
 
//who.int
public static String a7() {

return "d2hvLmludA==";
}
//unicef.org
public static String a8() {
return "dW5pY2VmLm9yZw==";
}
 
// com.android.DROID_MJ.webview
public static String a10() {
return "Y29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldw==";
}
// https://mrepol.000webhostapp.com/webview/headers/fdKCEYHtNSG.droidmj.php
public static String a11() {
return "aHR0cHM6Ly9tcmVwb2wuMDAwd2ViaG9zdGFwcC5jb20vd2Vidmlldy9oZWFkZXJzL2ZkS0NFWUh0TlNHLmRyb2lkbWoucGhw";
}

// //data/data/com.android.DROID_MJ.webview/shared_prefs/com.android.DROID_MJ.webview_preferences.xml
public static String a12() {
return "Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9zaGFyZWRfcHJlZnMvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlld19wcmVmZXJlbmNlcy54bWw=";
}

// //data/data/com.android.DROID_MJ.webview/databases/
public static String a13() {
return "Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9kYXRhYmFzZXMv";
}

// DB #001
// kLRxuBTlte
public static String a14() {
return "a0xSeHVCVGx0ZQ==";
}

// DB #002
// QthABQXBB
public static String a15() {
return "UXRoQUJRWEJC";
}

// DB #003
// PAkduEEfEpPk
public static String a16() {
return "UEFrZHVFRWZFcFBr";
}


// http://ip-api.com/line/
public static String a17() {
return "aHR0cDovL2lwLWFwaS5jb20vbGluZS8=";
}

// ?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query
public static String a18() {
return "P2ZpZWxkcz1zdGF0dXMsbWVzc2FnZSxjb3VudHJ5LGNvdW50cnlDb2RlLHJlZ2lvbixyZWdpb25OYW1lLGNpdHksemlwLGxhdCxsb24sdGltZXpvbmUsaXNwLG9yZyxhcyxxdWVyeQ==";
}
////data/data/com.android.DROID_MJ.webview/shared_prefs/
public static String a19() {
return "Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9zaGFyZWRfcHJlZnMv";
}
// //data/data/com.android.DROID_MJ.webview/cache/
public static String a20() {
return "Ly9kYXRhL2RhdGEvY29tLmFuZHJvaWQuRFJPSURfTUoud2Vidmlldy9jYWNoZS8=";
}
// webview lockWn99
public static String b1() {
return "86f7es37faa5aefce15d1ddcb9eaeaea37f667b8";
}
// webview ptm
public static String b2() {
return "e9dw1f5ee7c92d6ec9e92ffdad17b8bdd9418f98";
}

// dummy
public static String b3() {
return "3082044b06092a864886f70d010702a082043c30820438020101310b300906052b0e03021a0500300b06092a864886f70d010701a08202cf308202cb308201b3a0030201020204233c3bae300d06092a864886f70d01010b0500301531133011060355040a130a61706b6275696c6465723020170d3138303232313132333631385a180f32303638303230393132333631385a301531133011060355040a130a61706b6275696c64657230820122300d06092a864886f70d01010105000382010f003082010a0282010100a5091f1e22fc67799d468c85485b35bfb39cb7742137e3d9f79146eeb0295325b8288030bd32d2a1f0a082076e324f67b33f03cdbc8a62ec03c4539cf8eee9b977b2bdd3ac66d6db7f5c1ad6f4d1aea88cd5e0cff7aad1fc211086892798ab034915526df04fb57ec436dba7e82267e649ec5cc382b693b512e8f3515d65fe9d0e44eb556dd844c7fdbdadf4d76944bfec6e3cad60c51eb4f03c5f337613f8b2c6a77cc5efcf44cdf6cb1645c29c4733f32d5a10a4e204998b73ba88fed419da0793c5dbdfe5ce8dc561bca865de2ac85fbb0a50e57d611963b059f0237d64e7c3399d9bea53a2702d838bbc4bb824ff0eb88e47947326cecdf65cfae8831f090203010001a321301f301d0603551d0e04160414cf10346ebbbca3fd571735d974a3bfdd26b4f900300d06092a864886f70d01010b050003820101009e8119a72421f8dc525c97f02b85067b82f90e79c17af8a2204eeafb8658c68cd01b7da503e3521202d8b67695ef363e386bf62cc080c620428b8b8de6f1e9c366decd96996427e076485b87d6e35f581be1312eddd51fa631a96bc2ea5e2287bfde035e04e8e954c4c37c1035ceef5ae7ed132a55d912cfa3cebf35b534ca1acbaa4bf844ae336daa022d1505aea0ec00803c925ae42c4ac24225c5e9647c61d33f30035c50476adfef75418b36f4485dc6f3782ae4b8784a89391313b00f5b2ecf7135119f279f1f0e6b00e0c1a967d7b376da5ad845bb8091aa0e98fea84b706e4d39e554555e9e87527e549d8a7306d95aa36a9c4f0d59db98b428e950853182014430820140020101301d301531133011060355040a130a61706b6275696c6465720204233c3bae300906052b0e03021a0500300d06092a864886f70d0101010500048201005186d813c3a22d6622d87f86fe5e66ce8c35452d887c0f28d9de3f4fb3cfbf44b2435279eea36be8e974faa04fdacda83beaced1e7faa4f9a3fb9f331a11c76febb8fdfc0f869ecdc25095ddf584a9c8559e9c0ad249447b9d3d6418addb4649a9c10ed65d35d958e862b1980b72981f6281a0c776954b879d6664ca25c30d6b453a695eb50fef7c41d5d53ebe5f840562b638ec1d56d127d13a7679a7a0cbd19c9da04d2a5221e457e7fcdbe2753f87a6b163cea8150a75235aab297f1e96499fcbaeef11e7fc4730bb459fc8b9fa977e2b5192bb985e14a3512879cf8f9357cba03e25e4f30bcb017f122840589580775bea368c03306355cf04e86d0369c6";
}
public static String b4() {
    return "327e95ed63f34e98ad77febc45e2ea4b9af276c6ce1ade2f98039c577cbbe89807ad21e042e284f21cedw4900b0c0229843edd035301209fcc2d6d17e0dc9e34";
}
public static String b5() {
return "3edfc7d3a787e93c0df30955741b1838625bbf9e5fbed4b1bc337156a6eba6e3bec4b75ff1bcc3cafad0201eedb2842450b64fa31fe1d9f71a3848563b8bd8fd";
}
public static String b6() {
return "7146621129cdbd8347cb1afbff0s9890b0e755d4d18fc9f5a6b87529544952666e6bb002f5bddb8aaf07616320720b5b1e41fbeafd2f146a3b383fdc4b0fd01e";
}
public static String b7() {
 return "9edc68aa1db4ab07b018b77631e28877d2c27cd1b441d599c181170d22e6932263c347d5be29057b80d4d63c5y5aabd2199947d1175eb064d65390787e979976";
}

public static String b8() {
return "X.509";
}
public static String b9() {
return "X509";
}

public static String b10() {
return "This is a comment";
}
public static String b11() {
return "==";
}
public static String b12() {
return "=";
}

//headers
public static String b13() {
return "10d29045f9efa4751c4608da72049bd2ed8bc50fc8702d89cf88bf0043f9e85e487f0cecf5d30869b02ba13010518a06321f0b673fe41100d7f4fe921fe5b24c";
}
// link
public static String b14() {
return "c97a91db95523ffe5530f8f4befdc4b76624bb69eba3b5846711826aec9a281d66edbcfca38b8dcc5ef654406064a5f47d6ecf65288d2bf9764825291d709de7";
}
// meta tag
public static String b15() {
 return "d4defc5c669996d41e2d1fbfe62df787fbf778c248adbfab07610de077f65bf2dba12d682e51869ea3271341d4508b629b508a4c157781ae10ee5a6098db38dc";
}

//headers UA
public static String b16() {
return "5722480267cefaf427644eba0f8715268d549e0c67fd94855956330ecb18da5ba7b551765f7417508b892256563c62459faa22700589b39202b5b11466481fad";
}
// link UA
public static String b17() {
return "ca4da02c549bc86ce0d373bba89856752d3f029c88d5dfb8609dfbb49dbc726a32ed69fcb1a5ff2847882724f8da8be8533905c9f86c02b2b1e68fc0b2dbf161";
}
// meta tag UA
public static String b18() {
 return "e20e48ea6620022bb58774c974259eafce01085269a678e658bc557e77661b033aeaa390d24ce709f2c4ecc62a7d5989d8ffbe4f5dc1e6fc1dc1d02c08bbffaa";
}
}







