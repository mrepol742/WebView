package com.android.DROID_MJ.W;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import java.util.List;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import java.util.ArrayList;


public class W19 extends BaseAdapter {
    private static Context a;
    private static List<String> b = new ArrayList<>(10000);
    private static List<String> d = new ArrayList<>(10000);

    public W19(Context ct, List<String> al, List<String> al2) {
        a = ct;
        b = al;
        d = al2;
    }

    public void a(List<String> a1, List<String> a2) {
            b.clear();
                d.clear();
        b.addAll(a1);
        d.addAll(a2);
    }

    public int getCount() {
            return b.size();
    }

    public Object getItem(int it) {
            return it;
    }

    public long getItemId(int it) {
        return it;
    }

    public View getView(int it, View e, ViewGroup vg) {
try {
       W20 w20;
       if (e == null) {
           LayoutInflater li = (LayoutInflater) a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           e = li.inflate(R.layout.b7, vg, false);
       w20 = new W20();
       w20.a = (TextView) e.findViewById(R.id.g7);
       w20.b = (TextView) e.findViewById(R.id.g8);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(a);
       if (sp.getBoolean("autoUpdate", false) == false) {
           w20.a.setTextColor(C5.b(a,R.color.c));
w20.b.setTextColor(C5.b(a,R.color.c));
       } else {
w20.a.setTextColor(C5.b(a,R.color.b));
w20.b.setTextColor(C5.b(a,R.color.b));
       }
w20.a.setTypeface(G1.a(a, 200));
w20.b.setTypeface(G1.a(a, 100));
       e.setTag(w20);
      } else {
         w20 = (W20) e.getTag();
     }
       w20.a.setText(b.get(it));
       w20.b.setText(d.get(it));

       } catch (ArrayIndexOutOfBoundsException ex) { 
   
       }catch (IndexOutOfBoundsException iobe) {
}
       return e;
    }

}



