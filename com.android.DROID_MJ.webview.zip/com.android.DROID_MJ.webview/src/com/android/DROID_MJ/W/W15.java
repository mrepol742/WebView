package com.android.DROID_MJ.W;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import java.util.List;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import android.widget.Filter;

public class W15 extends BaseAdapter {
    private static Context a;
    private List<String> b = new ArrayList<>(10000);
    private static int[] c;
    private List<String> d = new ArrayList<>(10000);
    private static int ite;
    private  List<String> e = new ArrayList<>(10000);
    private  List<String> f = new ArrayList<>(10000);
private static int id1;

    public W15(Context ct,int[] it, List<String> al, List<String> al2, int e55, int id) {
        a = ct;
        b = al;
        c = it;
        d = al2;
        ite =e55;
        e = al;
       d = al2;
id1 = id;
    }

    public void a(List<String> a1, List<String> a2) {
        synchronized (b) {
            b.clear();
            synchronized (d) {
                d.clear();
            }
        }
        b.addAll(a1);
        d.addAll(a2);
    }

    public int getCount() {
        synchronized (b) {
            return b.size();
        }
    }

    public Object getItem(int it) {
        synchronized (b) {
            return it;
        }
    } 

    public long getItemId(int it) {
        return it;
    }

    public Filter getFilter() {
        Filter filter = new Filter() {
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence constraint, android.widget.Filter.FilterResults results) {
synchronized (d) {
 
            d = (List<String>) results.values;
   notifyDataSetChanged();

}
         
        }

        protected android.widget.Filter.FilterResults performFiltering(CharSequence cs) {
            android.widget.Filter.FilterResults fr = new FilterResults();
 if (cs == null) {
 List<String> ls55 = new ArrayList<String>(b);  
     fr.count = ls55.size();
             fr.values = ls55;
} else {
            List<String> ls = new ArrayList<>();  
            for (String sg: e) {
                 if (sg.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg);

                 }
             }
             fr.count = ls.size();
             fr.values = ls;
}
             return fr;
         }
     };
     return filter;
    }

    public View getView(int it, View e, ViewGroup vg) {
try {
       W17 w17;
       if (e == null) {
           LayoutInflater li = (LayoutInflater) a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           e = li.inflate(ite, vg, false);
       w17 = new W17();
       w17.a = (TextView) e.findViewById(R.id.e19);
       w17.b = (TextView) e.findViewById(R.id.e20);
       w17.c = (ImageView) e.findViewById(R.id.e18);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(a);
       if (sp.getBoolean("autoUpdate", false) == false) {
           w17.a.setTextColor(C5.b(a,R.color.c));
w17.b.setTextColor(C5.b(a,R.color.c));
w17.c.setBackgroundResource(R.drawable.v);
if (id1 == 0) {
w17.c.setImageResource(R.drawable.u);
} else if (id1 == 1) {
w17.c.setImageResource(R.drawable.x);
}
       } else {
w17.a.setTextColor(C5.b(a,R.color.b));
w17.b.setTextColor(C5.b(a,R.color.b));
w17.c.setBackgroundResource(R.drawable.y);
if (id1 == 0) {
w17.c.setImageResource(R.drawable.a8);
} else if (id1 == 1) {
w17.c.setImageResource(R.drawable.a9);
}
       }
w17.a.setTypeface(G1.a(a, 200));
w17.b.setTypeface(G1.a(a, 100));

       e.setTag(w17);
      } else {
         w17 = (W17) e.getTag();
     }
       w17.a.setText((CharSequence)b.get(it));
       w17.b.setText((CharSequence)d.get(it));
if (id1 == 2) {
       w17.c.setImageResource(c[it]);
}
       } catch (ArrayIndexOutOfBoundsException ex) {
            
       } catch (IndexOutOfBoundsException iobe) {
       }
       return e;
    }

}




