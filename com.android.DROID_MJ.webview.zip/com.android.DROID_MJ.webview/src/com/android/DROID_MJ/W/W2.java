package com.android.DROID_MJ.W;

// UNUSED

import java.net.MalformedURLException;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.net.URL;
import java.util.Set;
import java.util.HashSet;
import com.android.DROID_MJ.U.U3;
public class W2 {

private static final Set<String> A77 = new HashSet<>();

public static boolean a(String a) {
     try {
        return b(d(a));
    } catch (MalformedURLException e) {

        return false;
    }
}

private static boolean b(String a) {
if (U3.b(a, 0) == false) {

        return false;
    }
    int b = a.indexOf(".");
    return b >= 0 && (A77.contains(a) ||
            b + 1 < a.length() && b(a.substring(b + 1)));
}

public static WebResourceResponse c() {
    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream("".getBytes()));
}

public static String d(String a) throws MalformedURLException {
    return new URL (a).getHost();
}

}