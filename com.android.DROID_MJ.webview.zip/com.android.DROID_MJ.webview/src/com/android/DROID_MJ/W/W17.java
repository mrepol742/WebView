package com.android.DROID_MJ.W;
import android.widget.ImageView;
import android.widget.TextView;

 public class W17 {
    TextView a;
    TextView b;
    ImageView c;
}