package com.android.DROID_MJ.W;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.webkit.WebView;
import android.annotation.TargetApi;

public class W10 extends WebView {

    private static GestureDetector a;
    public W10(Context context) {
        super(context);
    }
    public W10(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public W10(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
  
    public W10(Context context, AttributeSet attrs, int defStyle, int b) {
        super(context, attrs, defStyle, b);
    }

    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
    }

    public void setGestureDetector(GestureDetector at) {
      a = at;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        return a.onTouchEvent(ev) || super.onTouchEvent(ev);
    }
}