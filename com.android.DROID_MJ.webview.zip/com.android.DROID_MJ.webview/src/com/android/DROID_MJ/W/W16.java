package com.android.DROID_MJ.W;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.android.DROID_MJ.C.C5;
import com.android.DROID_MJ.webview.R;
import java.util.List;
import java.util.ArrayList;
import android.content.SharedPreferences;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.widget.Filter;
import android.widget.TextView;
 

public class W16 extends BaseAdapter {
    private static Context a;
    private   List<String> b = new ArrayList<>(10000);
    private   List<String> c = new ArrayList<>(10000);

    private   List<String> d = new ArrayList<>(10000);
    private   List<String> e = new ArrayList<>(10000);

    private   List<String> f = new ArrayList<>(10000);
    private   List<String> g = new ArrayList<>(10000);

    public W16(Context ct, List<String> al, List<String> ls1, List<String> ls12, List<String> ls2, List<String> ls22) {
        a = ct;
        b = al;
        c = al;
        d = ls1;
        e = ls12;
        f = ls2;
        g = ls22;
    }

    public void a(List<String> a1) {
        b.clear(); 
        c.clear();
        b.addAll(a1);
        c.addAll(a1);
    }

    public int getCount() {
        return b.size();
    }

    public Object getItem(int it) {
            return b.get(it);
    }

    public long getItemId(int it) {
        return it;
    }

    public Filter getFilter() {
        Filter filter = new Filter() {
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence constraint, android.widget.Filter.FilterResults results) {
            b = (List<String>) results.values;
   notifyDataSetChanged();
         
        }

        protected android.widget.Filter.FilterResults performFiltering(CharSequence cs) {
            android.widget.Filter.FilterResults fr = new FilterResults();
 if (cs == null) {
 List<String> ls55 = new ArrayList<String>(b);  
     fr.count = ls55.size();
             fr.values = ls55;
} else {
            List<String> ls = new ArrayList<>();  
            for (String sg: c) {
                 if (sg.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg);

                 }
             }
for (String sg1: d) {
if (sg1.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg1);

                 }
}
for (String sg12: e) {
if (sg12.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg12);

                 }
}


for (String sg122: f) {
if (sg122.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg122);

                 }
}

for (String sg1222: g) {
if (sg1222.toLowerCase().contains(cs.toString().toLowerCase())) {
                      ls.add(sg1222);

                 }
}






             fr.count = ls.size();
             fr.values = ls;
             }
             return fr;
         }
     };
     return filter;
    }

    public View getView(int it, View vw, ViewGroup vg) {
try {
       W18 w18;
       if (vw == null) {
           LayoutInflater li = (LayoutInflater) a.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           vw = li.inflate(R.layout.b6, vg, false); 
      w18 = new W18();
       
       w18.a = (TextView) vw.findViewById(R.id.d16);
       SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(a);
       if (sp.getBoolean("autoUpdate", false) == false)  {
 w18.a.setTextColor(C5.b(a,R.color.c));

       } else {
w18.a.setTextColor(C5.b(a,R.color.b));
       }
w18.a.setTypeface(G1.a(a, 100));
  vw.setTag(w18);
      } else {
         w18 = (W18) vw.getTag();
}

      w18.a.setText((CharSequence)b.get(it));

       } catch (ArrayIndexOutOfBoundsException ex) {
      
     }  catch (IndexOutOfBoundsException iobe) {
}
       return vw;
    }
}
 