package com.android.DROID_MJ.W;

import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.O.O1;
import com.android.DROID_MJ.C.C2;
import com.android.DROID_MJ.N.N2;
 
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.webview.R;
import android.content.Context;
import com.android.DROID_MJ.C.C5;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.app.Notification;
import android.content.Intent;
import com.android.DROID_MJ.C.C1;
import android.os.Build;
import android.graphics.BitmapFactory;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.java.DROID_MJ.U.U7;
import android.net.Uri;
import com.android.DROID_MJ.P.P15;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.camera2.CameraManager;
import com.android.DROID_MJ.A.A27;

public class W9 {

    private static CameraManager cm;
    private static Camera ca;

    public static void a(Context a, String b, int c, int d) {
        try {
            if (c == 0) {
                W1.a(a, b, d);
            } else if (c == 1) {
                A21.getInstance().c7(b);
            } else if (c == 2) {
                A21.getInstance().c8(b);
            }
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public static void b(Context a, String b) {
        C2.a(a, b);
    }

    public static void c(Context a, int b) {
        O1.a(a, b);
    }

    public static void d(Context a, boolean b) {
        if (b == true) {
            N2.a(a);
        } else {
            N2.b(a);
        }
    }

    public static void f(Context a, String b, String c, String d) {
         Notification.Builder m = new Notification.Builder(a, "e");
         m.setSmallIcon(R.drawable.c);
Notification.BigTextStyle bigText = new Notification.BigTextStyle();
if (d.length() != 0) {
bigText.setSummaryText(Uri.parse(d).getHost());
} else {
bigText.setSummaryText(a.getResources().getString(R.string.g31));
}
        if (W13.b(c) == true) {
            m.setContentText(c);
           bigText.bigText(c);
        } else {
            m.setContentText(a.getResources().getString(R.string.g29));
bigText.bigText(a.getResources().getString(R.string.g29));
        }
        if (W13.b(b) == true) {
            m.setContentTitle(b);
            bigText.setBigContentTitle(b);
        } else {
            m.setContentTitle(a.getResources().getString(R.string.g30));
            bigText.setBigContentTitle(a.getResources().getString(R.string.g30));
        }
m.setStyle(bigText);

            m.setColor(C5.b(a,R.color.a));
        
SharedPreferences sq = PreferenceManager.getDefaultSharedPreferences(a);

   if (sq.getBoolean("eac", true) == true) {
        m.setAutoCancel(true);
    } else {
       m.setAutoCancel(false);
    }
m.setDefaults(Notification.DEFAULT_ALL);
        if (Build.VERSION.SDK_INT < 26) {
            if (sq.getString("py", "").length() == 0) { 
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("1x")) {
                m.setPriority(Notification.PRIORITY_DEFAULT);
            }
            if (sq.getString("py", "").equals("7x")) {
                m.setPriority(Notification.PRIORITY_HIGH);
            }
            if (sq.getString("py", "").equals("30x")) {
                m.setPriority(Notification.PRIORITY_LOW); 
            }
            if (sq.getString("py", "").equals("60x")) {
                m.setPriority(Notification.PRIORITY_MAX);
            }
            if (sq.getString("py", "").equals("120x")) {
                m.setPriority(Notification.PRIORITY_MIN);
            }
        }
            if (sq.getString("vy", "").length() == 0) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("1y")) {
                
m.setVisibility(Notification.VISIBILITY_PRIVATE);
            }
            if (sq.getString("vy", "").equals("7y")) {
                m.setVisibility(Notification.VISIBILITY_PUBLIC);
            }
            if (sq.getString("vy", "").equals("30y")) {
                m.setVisibility(Notification.VISIBILITY_SECRET);
            }
        
  m.setLargeIcon(BitmapFactory.decodeResource(a.getResources(),R.drawable.c));
if (d.length() != 0) {

         Intent it = new Intent(a, A21.class);
         it.putExtra("value", d);
         PendingIntent contentIntent = PendingIntent.getActivity(a, 0, it,PendingIntent.FLAG_UPDATE_CURRENT);
        m.setContentIntent(contentIntent);
Intent j = new Intent(a, A21.class);
j.putExtra("webview", d);
PendingIntent pi23 = PendingIntent.getActivity(a, 1, j,  PendingIntent.FLAG_UPDATE_CURRENT);
        m.addAction(R.drawable.q,a.getResources().getString(R.string.g28).replaceAll("%a", Uri.parse(d).getHost()),pi23);
}

        NotificationManager nmc = (NotificationManager) a.getSystemService("notification");
        nmc.notify(U7.a(U7.NOTIFICATION), m.build());
    }

   public static void g(Context a, boolean b) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (cm == null) {
                cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            }
            try {
                cm.setTorchMode(cm.getCameraIdList()[0], b);
            } catch (Exception e) {
            }
            return;
        }

        try {
            if (a.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
                if (b == true) {
                    ca = Camera.open();
                    Camera.Parameters p = ca.getParameters();
                    p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                    ca.setParameters(p);
                    ca.startPreview();
                } else {
                    ca.stopPreview();
                    ca.release();
                    ca = null;
                }
            }
        } catch (Exception e) {
            
        }
    }

}