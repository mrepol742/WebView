package com.android.DROID_MJ.W;

import android.webkit.WebView;
import android.graphics.Bitmap;
import com.android.DROID_MJ.A.A16;
import com.android.DROID_MJ.A.A24;

public class W34 extends W22 {

    public void e(WebView a, String b, Bitmap c) {
        A24.getInstance().c(a, b, c);
    }

    public boolean f(WebView a, String b) {
        return false;
    }
}
