package com.android.DROID_MJ.W;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.android.DROID_MJ.A.A21;
import android.webkit.SafeBrowsingResponse;
import android.webkit.RenderProcessGoneDetail;

public class W12 extends W22 {
    private static A21 a21;

    public W12() {
        a21 = A21.getInstance();
    }
// on receive error
    public void a(WebView a, int b, String c, String d) {
        a21.c77(a, b, c, d);
    }
// on httpreceive error
    public void b(final WebView a, final WebResourceRequest b, final WebResourceResponse c) {
        a21.c78(a, b, c);
    }
// on sslreceive error
    public void c(final WebView a, final SslErrorHandler b, SslError c) {
        a21.c79(a, b, c);
    }
// on page finished
    public void d(WebView a, String b) {

        a21.c80(a, b);
    }
// on page started
    public void e(WebView a, String b, Bitmap c) {
          a.setDownloadListener(this);
        a21.c81(a, b, c);
    }
//on page load
    public boolean f(WebView a, String b) {
       a.setDownloadListener(this);
        return a21.c82(a, b);
    }     

    public void g(String str, String str2, String str3, String str4, long j) {
        a21.c83(str, str2, str3, str4, j);
    }

    public void h(WebView view, WebResourceRequest wde, int type, SafeBrowsingResponse sbh) {
        a21.c60(view, wde, type, sbh);
    }

    public boolean i(WebView a, RenderProcessGoneDetail b) {
        return a21.c132(a, b);
    }

    public void j(WebView wb, float old, float neW) {
        a21.c136(wb, old, neW);
    }
}
