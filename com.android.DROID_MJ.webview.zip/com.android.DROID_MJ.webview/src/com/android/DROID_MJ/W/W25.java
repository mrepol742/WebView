package com.android.DROID_MJ.W;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class W25 implements OnSeekBarChangeListener {
    
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
a(seekBar,progress, fromUser);
    }
    public void onStartTrackingTouch(SeekBar seekBar) {
b(seekBar);
    }
    public void onStopTrackingTouch(SeekBar seekBar) {
c(seekBar);
    }

    public void a(SeekBar seekBar, int progress, boolean fromUser) {

    }
    public void b(SeekBar seekBar) {
    }
    public void c(SeekBar seekBar) {
    }
   
}

