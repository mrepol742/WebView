package com.android.DROID_MJ.W;
import android.widget.RadioGroup;

public class W31 implements RadioGroup.OnCheckedChangeListener {
    public void onCheckedChanged(RadioGroup rg, int i) {
        a(rg, i);
    }

    public void a(RadioGroup rg, int i) {
     

    }

}