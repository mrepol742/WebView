package com.android.DROID_MJ.W;
import android.webkit.WebView;
import com.android.DROID_MJ.A.A16;
import com.android.DROID_MJ.A.A24;

public class W35 extends W23 {
    private static A24 a24;

    public W35() {
        a24 = A24.getInstance();
    }
    public void g(WebView a, int b) {
        a24.b(a, b);
    }
}


