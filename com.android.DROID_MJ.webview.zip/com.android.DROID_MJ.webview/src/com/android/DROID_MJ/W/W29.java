package com.android.DROID_MJ.W;

import android.webkit.WebView;
import android.graphics.Bitmap;
import com.android.DROID_MJ.A.A16;

public class W29 extends W22 {

    public void e(WebView a, String b, Bitmap c) {
        A16.getInstance().l(a, b, c);
    }

    public boolean f(WebView a, String b) {
        return false;
    }
}
