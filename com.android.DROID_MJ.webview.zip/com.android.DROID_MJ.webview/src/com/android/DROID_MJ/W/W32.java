package com.android.DROID_MJ.W;

import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.U.U6;

public class W32 {
 
// app name
  public static void a() {
U6.a(U4.a(W5.i()));
    }
// package name
  public static void b() {
U6.a(U4.a(W5.k()));
    }
// package key
  public static void c() {
U6.a(U4.a(W5.j()));
    }
//user agrred
    public static void d() {
U6.a(U4.a(W5.l()));
    }
}