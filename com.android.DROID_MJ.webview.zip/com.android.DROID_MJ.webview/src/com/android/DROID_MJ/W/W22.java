package com.android.DROID_MJ.W;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.DownloadListener;
import android.annotation.TargetApi;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SafeBrowsingResponse;
import com.android.DROID_MJ.U.U1;

public class W22 extends WebViewClient implements DownloadListener {

    public W22() {
    }

    @SuppressWarnings("deprecation")
    public void onReceivedError(WebView a, int b, String c, String d) {
        //super.onReceivedError(a, b, c, d);
        a(a, b, c, d);
    }

    @TargetApi(23)
    public void onReceivedError(WebView a, WebResourceRequest b, WebResourceError c) {
        //super.onReceivedError(a, b, c);
        a(a, c.getErrorCode(), a.getUrl(), 
c.getDescription().toString());
    }

    @TargetApi(23)
    public void onReceivedHttpError(WebView a, WebResourceRequest b, WebResourceResponse c) {
        b(a, b, c);
    }

    public void onReceivedSslError(WebView a, SslErrorHandler b, SslError c) {
        c(a, b, c);
    }
  
    public void onPageFinished(WebView a, String b) {
        //super.onPageFinished(a, b);
        d(a, b);
    }

    public void onPageStarted(WebView a, String b, Bitmap c) {
        //super.onPageStarted(a, b, c);

        e(a, b, c);
    }

    public boolean shouldOverrideUrlLoading(WebView a, String b) {
        return f(a, b);
    }     

    public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
        g(str, str2, str3, str4, j);
    }

    @TargetApi(24)
    public boolean shouldOverrideUrlLoading(WebView a, WebResourceRequest b) {
        return f(a, a.getUrl());
    }

    @TargetApi(26)
    public boolean onRenderProcessGone(WebView a, RenderProcessGoneDetail b) {
        return i(a, b);
    }

    @TargetApi(27)
    public void onSafeBrowsingHit(WebView view, WebResourceRequest wde, int type, SafeBrowsingResponse sbh) {
        h(view, wde, type, sbh);
    }

    public void onScaleChanged(WebView wb, float old, float neW) {
        j(wb, old, neW);
    }

    public void a(WebView a, int b, String c, String d) {
    }
// on httpreceive error
    public void b(WebView a,  WebResourceRequest b, WebResourceResponse c) {
    }
// on sslreceive error
    public void c(WebView a,SslErrorHandler b, SslError c) {
    }
// on page finished
    public void d(WebView a, String b) {
    }
// on page started
    public void e(WebView a, String b, Bitmap c) {
    }
//on page load
    public boolean f(WebView a, String b) {
        return false;
    }     

    public void g(String str, String str2, String str3, String str4, long j) {
     
    }

    public void h(WebView view, WebResourceRequest wde, int type, SafeBrowsingResponse sbh) {
    }

    public boolean i(WebView a, RenderProcessGoneDetail b) {
        U1.a("onRenderProcessGone | rendererPriorityAtExit | " + Integer.toString(b.rendererPriorityAtExit()));
        System.exit(0);
        return true;
    }

    public void j(WebView wb, float old, float neW) {

    }
}