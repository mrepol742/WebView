package com.android.DROID_MJ.W;

 
import android.graphics.Bitmap;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.annotation.TargetApi;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.PermissionRequest;
import android.os.Message;
  
public class W23 extends WebChromeClient {
 
    public W23() {
    }

    public Bitmap getDefaultVideoPoster() {
        return a();
    }

    public View getVideoLoadingProgressView() {
        return o();
    }

    public void onReceivedTitle(WebView a, String b) {
        //super.onReceivedTitle(a, b);
        c(a, b);
    }

    public void onReceivedIcon(WebView a, Bitmap b) {
        //super.onReceivedTitle(a, b);
        r(a, b);
    }

    public void onHideCustomView() {
        d();
    }

    public void onShowCustomView(View a, WebChromeClient.CustomViewCallback b) {
        e(a, b);
    }

    public boolean onShowFileChooser(WebView a, ValueCallback<Uri[]> b, WebChromeClient.FileChooserParams c) {
        return f(a, b, c);    
    }

    public void onProgressChanged(WebView a, int b) {
        g(a, b);
    }

    public boolean onJsAlert(WebView a, String b, String c, final JsResult d) { 
        return h(a, b, c, d);  
    }

    public boolean onJsPrompt(WebView a, String b, String c, String d, final JsPromptResult e) {
        return i(a, b, c, d, e);
    }

    public boolean onJsComfirm(WebView a, String b, String c, final JsResult e) {
        return j(a, b, c, e);
    }

    public boolean onJsBeforeUnload(WebView a, String b, String c, final JsResult e) {
        return k(a, b, c, e);
    }

    public void onConsoleMessage(String a, int b, String c) { 
        l(a, b, c);
    }

    public void onGeolocationPermissionsShowPrompt(String a, GeolocationPermissions.Callback b) {
        m(a, b);
    }

    public void onFormResubmission(WebView a, Message b, Message c) {
        p(a, b, c);
    }

    @TargetApi(21)
    public void onPermissionRequest(PermissionRequest pr) {
        q(pr);
    }
    public Bitmap a() {
        return null;
    }

    public void c(WebView a, String b) {
    }

    public void d() {
    }

    public void e(View a, WebChromeClient.CustomViewCallback b) {
    }

    public boolean f(WebView a, ValueCallback<Uri[]> b, WebChromeClient.FileChooserParams c) {
        return false;   
    }

    public void g(WebView a, int b) {
    }

    public boolean h(WebView a, String b, String c, final JsResult d) { 
        return false;
    }

    public boolean i(WebView a, String b, String c, String d, final JsPromptResult e) {
        return false;
    }

    public boolean j(WebView a, String b, String c, final JsResult e) {
        return false;
    }

    public boolean k(WebView a, String b, String c, final JsResult e) {
        return false;
    }

    public boolean l(String a, int b, String c) { 
        return false;
    }

    public void m(final String a, final GeolocationPermissions.Callback b) {
 
    }

    public View o() {
        return o();
    }

    public void p(WebView a, Message b, Message c) {
    
    }

    public void q(PermissionRequest pr) {
    }

    public void r(WebView a, Bitmap b) {
    }
}