package com.android.DROID_MJ.U;

import android.net.Uri;
import java.net.InetAddress;
import android.os.NetworkOnMainThreadException;
import java.net.UnknownHostException;
import com.android.DROID_MJ.O.O8;

public class U5 {
    public static String a(String text) {
        O8.a();
        return b(text);
    }

    private static String b(String a) {
        try { 
            Uri b = Uri.parse(a);
            InetAddress c = InetAddress.getByName(b.getHost()); 
            String d = c.getHostName();
            int e = c.hashCode();
            boolean f = c.isAnyLocalAddress();
            boolean g = c.isLinkLocalAddress();
            boolean h = c.isLoopbackAddress();
            boolean i = c.isMCGlobal();
            boolean j = c.isMCLinkLocal();
            boolean k = c.isMCNodeLocal();
            boolean l = c.isMCOrgLocal();
            boolean m = c.isMCSiteLocal();
            boolean n = c.isMulticastAddress();
            String o = c.getCanonicalHostName();
            String p = c.getHostAddress();
            String result = "Host Name: "+d+"\nHost Address: "+p
+"\nHash Code: "+Integer.toString(e)+"\nCanonical Hostname: "+o+"\nWildcard Address: "+f+"\nLocal Address: " +g+"\nLoopback Address: "+h +"\nGlobal Scope: "+i+"\nLink Scope: "+j+"\nNode Scope: "+k+"\nOrganization Scope: "+l+"\nSite Scope: "+m+"\nIP Multicast Address: "+n+"\n";
            return result;
        } catch (UnknownHostException ex) {
            U1.a(ex);
            return "Houston, we have a problem";
        } catch (NetworkOnMainThreadException ex5) {
            U1.a(ex5);
            return "Houston, we have a problem";
        }
    }


    public static String c(String url) {
        try {
            O8.a();
            InetAddress c = InetAddress.getByName(Uri.parse(url).getHost()); 
            return c.getHostAddress();

   
        } catch (UnknownHostException ex) {
            U1.a(ex);
            return "Houston, we have a problem";
        } catch (NetworkOnMainThreadException ex5) {
            U1.a(ex5);
            return "Houston, we have a problem";
        }
    }
}