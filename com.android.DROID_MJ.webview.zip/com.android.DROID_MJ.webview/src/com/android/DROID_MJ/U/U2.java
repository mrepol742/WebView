package com.android.DROID_MJ.U;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class U2 {  
// a cipher encryt methd
    public static String a(String a, String b) {
        try {
synchronized (a) {
synchronized (b) {
            KeyGenerator keygenerator = KeyGenerator.getInstance(a);
            SecretKey secretkey = keygenerator.generateKey();
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(Cipher.ENCRYPT_MODE, secretkey);
            byte[] encrypted = cipher.doFinal(b.getBytes());
            return new String(encrypted);
}
}
        } catch (Exception n) {
            return "$null";
        }
    }


    public static String b(String a, String b) {
        try {
synchronized (a) {
synchronized (b) {
            KeyGenerator keygenerator = KeyGenerator.getInstance(a);
            SecretKey secretkey = keygenerator.generateKey();
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(Cipher.DECRYPT_MODE, secretkey);
            byte[] decrypted = cipher.doFinal(b.getBytes());
            return new String(decrypted);
}
}
        } catch (Exception n) {
            return "$null";
        }
    }
}