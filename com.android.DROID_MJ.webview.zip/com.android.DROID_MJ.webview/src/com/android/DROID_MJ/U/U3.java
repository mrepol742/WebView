package com.android.DROID_MJ.U;

import android.widget.EditText;

public class U3 {
    public static boolean a(EditText a) {
        String b = a.getText().toString();
        String c = b.replaceAll(" ", "");
        if (c.length() != 0) {
            return true;
        }
        return false;
    }

    public static boolean b(String a, int b) {
        if (a.length() != b) {
            return true;
        }
        return false;
    }

    public static boolean c(String a, String b) {
        if (a.startsWith(b)) {
            return true;
        }
        return false;
    }

    public static boolean d(String a, String b) {
        if (a.endsWith(b)) {
            return true;
        }
        return false;
    }

    public static boolean e(String a, String b) {
        if (a.equals(b)) {
            return true;
        }
        return false;
    }
}