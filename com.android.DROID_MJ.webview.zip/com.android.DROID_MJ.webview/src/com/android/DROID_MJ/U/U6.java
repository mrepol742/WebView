package com.android.DROID_MJ.U;

import com.android.DROID_MJ.O.O8;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import javax.net.ssl.SSLHandshakeException;
import java.net.MalformedURLException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.P.P15;
import java.io.InputStream;

public class U6 {

    public static String a(String a, int b) {
return a;
}
    public static String a(  int b) {
       
        if (b == 0) {
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS9wYWdlbGlua3MvP3E9");
        } else if (b == 1) {
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS9tdHIvP3E9");
        } else if (b == 2) {
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS9ucGluZy8/cT0=");
        } else if (b == 3) {
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS93aG9pcy8/cT0=");
        } else if (b == 4) {
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS9yZXZlcnNlZG5zLw==");
        } else if (b == 5) {
//forward
            return U4.a("aHR0cHM6Ly9hcGkuaGFja2VydGFyZ2V0LmNvbS9ob3N0c2VhcmNoLz9xPQ==");
        }
        return "Houston, we have a problem";
    }
    public static void a( String a) {

try {
O8.a();
URL u = new URL(a);
          InputStream is =  u.openStream();
 is.close();
        } catch (MalformedURLException mue) {
             U1.a("MalformedURLException | Open Stream");
             
        } catch (SSLHandshakeException mu) {
             U1.a("SSL Handshake Aborted | Connection Time Out");
             
         } catch (IOException io) {
             U1.a("IOException | Open Stream");
        }
    


}

    public static String b( String a) {
StringBuilder cd = new StringBuilder();


O8.a();
        
        try {

            URL u = new URL(a);
            InputStream is = u.openStream();
            BufferedReader c =  new BufferedReader(new InputStreamReader(is));   
            String tf5 = new String();
            while ( (tf5 =c.readLine()) != null){
                cd.append(tf5);
                cd.append(System.lineSeparator());

            } 
is.close();

        } catch (MalformedURLException mue) {
             U1.a(mue);
             cd.append("Houston, we have a problem");
        } catch (SSLHandshakeException mu) {
             U1.a("SSL Handshake Aborted | Connection Time Out");
             cd.append("Houston, we have a problem");
        } catch (IOException io) {
             U1.a(io);
             cd.append("Houston, we have a problem");
        }
  
return cd.toString();
    }
    public static int c( String a) {
int cd = 0;

O8.a();
        
        try {

            URL u = new URL(a);
            InputStream is = u.openStream();
            BufferedReader c =  new BufferedReader(new InputStreamReader(is));   
            String tf5 = new String();
            while ( (tf5 =c.readLine()) != null){
               cd = Integer.parseInt(tf5.replaceAll(" ", ""));
            } 
          is.close();

        } catch (MalformedURLException mue) {
             U1.a(mue);
        } catch (SSLHandshakeException mu) {
             U1.a("SSL Handshake Aborted | Connection Time Out");
        } catch (IOException io) {
             U1.a(io);
        }
  

return cd;
 }
}