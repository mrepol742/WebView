package com.android.DROID_MJ.U;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.util.Date;
import android.os.Build;
import android.util.Log;
import java.io.FileNotFoundException;
import android.os.NetworkOnMainThreadException;
import java.net.UnknownHostException;
import android.content.pm.PackageManager.NameNotFoundException;
import java.security.NoSuchAlgorithmException;
import android.database.CursorIndexOutOfBoundsException;
import java.net.SocketException;
import android.os.Environment;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.MalformedURLException;
import java.security.cert.CertificateException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.content.Context;
import com.android.DROID_MJ.P.P15;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.id;
import com.android.DROID_MJ.I.I3;
import com.android.DROID_MJ.webview.WebView;
import javax.net.ssl.SSLHandshakeException;
 

public class U1 {
    private static final String st = " ============= ";
private static Executor er = Executors.newCachedThreadPool();
   
    public static void a(Exception a1) {
        b(Log.getStackTraceString(a1), "Exception");
    }

    public static void a(FileNotFoundException a1) {
        b(Log.getStackTraceString(a1), "FileNotFoundException");
    }

    public static void a(IOException a1) {
        b(Log.getStackTraceString(a1), "IOException");
    }

    public static void a(UnknownHostException a1) {
        b(Log.getStackTraceString(a1), "UnknownHostException");
    }

    public static void a(NetworkOnMainThreadException a1) {
        b(Log.getStackTraceString(a1), "NetworkOnMainThreadException");
    }

    public static void a(NameNotFoundException a1) {
        b(Log.getStackTraceString(a1), "NameNotFoundException");
    }

    public static void a(NoSuchAlgorithmException a1) {
        b(Log.getStackTraceString(a1), "NoSuchAlgorithmException");
    } 

    public static void a(CursorIndexOutOfBoundsException a1) {
        b(Log.getStackTraceString(a1), "CursorIndexOutOfBoundsException");
    }

    public static void a(NumberFormatException a1) {
        b(Log.getStackTraceString(a1), "NumberFormatException");
    }

    public static void a(SocketException a1) {
        b(Log.getStackTraceString(a1), "SocketException");
    }

    public static void a(NullPointerException a1) {
        b(Log.getStackTraceString(a1), "NullPointerException Log");
    }

    public static void a(MalformedURLException a1) {
        b(Log.getStackTraceString(a1), "MalformedURLException"); 
    }
    public static void a(CertificateException a1) {
        b(Log.getStackTraceString(a1), "CertificateException"); 
    }

    public static void a(SSLHandshakeException a1) {
        b(Log.getStackTraceString(a1), "SSLHandshakeException"); 
    }

    public static void a(String a) {
        if (a != null) {
            String b = a.replaceAll(" ", "");
            if (b.length() !=0) {
                b(a, "Log");
            }
        }
    }

    private static void b(final String a,final String df) {
if (!WebView.Application.a) {
return;
}
P15 p = new P15() {
    public void a() {
        try {
             File a2 = new File(I3.a() + "/WebView/.log/webview.log");
            Date date = new Date();
             if (!a2.exists()) {
                  a2.createNewFile();
                  FileOutputStream a3 = new FileOutputStream(a2);
                  OutputStreamWriter a4 = new OutputStreamWriter(a3);
                  a4.append(st+"Build "+DateFormat.getDateInstance().format(date)+st+"\n"+ "Fingerprint: " + Build.FINGERPRINT + "\nSDK Version: " + Integer.toString(Build.VERSION.SDK_INT) + "\nExternal Storage Directory: " + I3.a()+ "\nJava Virtual Version: "+System.getProperty("java.vm.version")+"\n\n\n"+st+DateFormat.getDateInstance().format(date)+st+"\n"+DateFormat.getTimeInstance().format(date) +" || "+a);
                  a4.close();
                  a3.close();
             } else {
	                SimpleDateFormat sdf = new SimpleDateFormat("MM dd, yyyy");
                  String dth = sdf.format(a2.lastModified());
                  String dth55 = sdf.format(date);
 
                  FileWriter fr = new FileWriter(a2, true);
                  BufferedWriter br = new BufferedWriter(fr);
                  if (dth.equals(dth55)) {
                      br.write("\n"+DateFormat.getTimeInstance().format(date)+" || "+df + " || " +a);
                  } else {
                      br.write("\n\n\n"+st+DateFormat.getDateInstance().format(date)+st+"\n"+  DateFormat.getTimeInstance().format(date) + " || "+df + " || " + a);
                  }
                  br.close();
                  fr.close();
             }
        } catch (Exception ex) {
             Log.d("WebView", a);
        }
}
};
er.execute(new Thread(p));
    }
}