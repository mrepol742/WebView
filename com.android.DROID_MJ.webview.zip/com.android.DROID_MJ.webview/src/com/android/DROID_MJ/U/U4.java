package com.android.DROID_MJ.U;

import android.util.Base64;

public class U4 {
    public static String a(String a) {
        byte[] b = Base64.decode(a.getBytes(), Base64.DEFAULT);
        return new String(b);
    }

    public static String b(String a) {
        byte[] b = Base64.encode(a.getBytes(), Base64.DEFAULT);
        return new String(b);
    }

    public static String c(String a) {
        byte[] b = Base64.decode(a.getBytes(), Base64.URL_SAFE);
        return new String(b);
    }

}