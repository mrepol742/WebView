package com.android.DROID_MJ.V;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;
import android.annotation.TargetApi;

public class V7 extends Button {

    public V7(Context context) {
        super(context);
    }
    public V7(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public V7(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
  
    @TargetApi(21)
    public V7(Context context, AttributeSet attrs, int defStyle, int b) {
        super(context, attrs, defStyle, b);
    }
}