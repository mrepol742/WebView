package com.android.DROID_MJ.V;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;
import android.annotation.TargetApi;

public class V5 extends TextView {

    public V5(Context context) {
        super(context);
    }
    public V5(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public V5(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }
  
    @TargetApi(21)
    public V5(Context context, AttributeSet attrs, int defStyle, int b) {
        super(context, attrs, defStyle, b);
    }
}

