package com.android.DROID_MJ.V;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.android.DROID_MJ.U.U1;

public class V1 {

    public static void a(Context a, int b, View c) {
        try {
            Animation d = AnimationUtils.loadAnimation(a.getApplicationContext(), b);
					    c.startAnimation(d);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }
    
}