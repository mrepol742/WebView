package com.android.DROID_MJ.V;

import android.view.MotionEvent;
import com.android.DROID_MJ.A.A21;;

public class V4 extends V3 {
    public boolean a(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return A21.getInstance().c76(e1, e2, velocityX,
velocityY);
    }
}

