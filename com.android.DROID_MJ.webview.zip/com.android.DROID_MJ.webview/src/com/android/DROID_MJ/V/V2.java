package com.android.DROID_MJ.V;

import android.content.Context;
import android.view.View;  
import android.view.inputmethod.InputMethodManager;

public class V2 {
    public static void a(Context a, View b) {
        InputMethodManager c = (InputMethodManager) a.getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        c.showSoftInput(b, InputMethodManager.SHOW_IMPLICIT);
    }

    public static void b(Context a, View b) {
        InputMethodManager c = (InputMethodManager) a.getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE); 
        c.hideSoftInputFromWindow(b.getWindowToken(), 0);
    }
}