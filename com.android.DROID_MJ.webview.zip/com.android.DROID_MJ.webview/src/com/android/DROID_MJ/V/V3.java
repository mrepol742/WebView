package com.android.DROID_MJ.V;
import android.view.MotionEvent;
import android.view.GestureDetector.SimpleOnGestureListener;

public class V3 extends SimpleOnGestureListener {
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return a(e1, e2, velocityX, velocityY);
    }

    public boolean a(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }
}