package com.android.DROID_MJ.G;
import android.content.Context;
import java.io.File;
import com.android.DROID_MJ.G.G1; 
import android.graphics.Typeface;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.graphics.Typeface;
import com.android.DROID_MJ.U.U1;
import android.content.res.Resources;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.I.I3;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.webview.WebView;
import com.android.DROID_MJ.U.U4;
import android.app.Activity;
public class G1 {

    public static Typeface a(Context a, int b) {
         if (PreferenceManager.getDefaultSharedPreferences(a.getApplicationContext()).getBoolean("cFNT", false) == false) {
              if (b == 100) {
                  // DPF
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
              } else {
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
              }
         } else {
              if (b == 100) {
                  if (new File(I3.a() +"/WebView/.cache/c.cache").exists()) {
                      return Typeface.createFromFile(new File(I3.a() +"/WebView/.cache/c.cache"));
                  } else {
              if (b == 100) {
                  // DPF
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
              } else {
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
              }
                  }
              } else {
                  if (new File(I3.a() +"/WebView/.cache/d.cache").exists()) {
                      return Typeface.createFromFile(new File(I3.a() +"/WebView/.cache/d.cache"));
                  } else {
              if (b == 100) {
                  // DPF
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
              } else {
                  return Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
              }
                  }
              }
         }
    }
}