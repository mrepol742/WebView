package com.android.DROID_MJ.N;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;

public class N2 {

    public static void a(Context a) {
        if (Build.VERSION.SDK_INT < 29) {
            WifiManager b = (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            b.setWifiEnabled(true);
        }
    }

    public static void b(Context a) {
        if (Build.VERSION.SDK_INT < 29) {
            WifiManager b = (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            b.setWifiEnabled(false);
        }
    }
}