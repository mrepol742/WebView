package com.android.DROID_MJ.N;

import android.net.ConnectivityManager;
import android.content.Context;
import android.net.NetworkInfo;
import com.android.DROID_MJ.U.U1;
import android.provider.Settings;
import android.os.Build;
import android.net.NetworkCapabilities;

public class N1 {
 
    public static boolean a(Context a) {
        ConnectivityManager cm = (ConnectivityManager) a.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT < 29) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null) { 
                try {
                    if (activeNetwork.isConnected() == true) {
                        return true;
                    } else {
                        return false;
                    }
                } catch (Exception rx) {
                   U1.a(rx);
                }
                return false;
            } else {
                return false;
            }
        } else {
            return d(cm);
        }
    }


    @SuppressWarnings("deprecation")
    public static boolean b(Context a) { 
        try {       
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
                return Settings.System.getInt(a.getApplicationContext().getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0) != 0;
            } else {
                return Settings.Global.getInt(a.getApplicationContext().getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
            }       
        } catch (Exception rx) {
            U1.a(rx);
        }
        return false;
    }

    public static boolean c(Context a) {
        ConnectivityManager cm = (ConnectivityManager) a.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null) { 
           try {
               if (activeNetwork.isConnectedOrConnecting() == true) {
                   return true;
               } else {
               }
           } catch (Exception rx) {
               U1.a(rx);
           }
           return false;
       } else {
           return false;
       }
    }

    private static boolean d(ConnectivityManager cm) {
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        if (capabilities != null) {
            try {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    return true;
                }
            } catch (Exception rx) {
               U1.a(rx);
            }
            return false;
        } else {
            return false;
        }
    }
}