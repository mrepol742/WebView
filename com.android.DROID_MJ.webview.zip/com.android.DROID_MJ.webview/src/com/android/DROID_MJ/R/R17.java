package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.A.A21;

public class R17 extends R14 {
 
    public void a(Context a, Intent b) {
        if (b.getAction().equals("android.intent.action.MY_PACKAGE_REPLACED")) {
            if (PreferenceManager.getDefaultSharedPreferences(a).getBoolean("asd71", false) == true) {
                C1.a(a, A21.class);
                
            }
        }
    }
}