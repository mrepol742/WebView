package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import android.content.BroadcastReceiver;

public class R14 extends BroadcastReceiver {

    public void onReceive(Context a, Intent b) {
        try {
            a(a.getApplicationContext(), b);
U1.a(b.getAction());
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void a(Context a, Intent b) {
    }
}