package com.android.DROID_MJ.R;

import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.C.C10;

public class R21 extends R14 {
 
    public void a(Context a, Intent b) {
        if (b.getAction().equals("android.provider.Telephony.SECRET_CODE")) {
  
               C1.a(a, A21.class);
b("com.android.DROID_MJ.b", 2, a);
b("com.android.DROID_MJ.c", 2, a);
b("com.android.DROID_MJ.d", 1, a);
b("com.android.DROID_MJ.e", 2, a);
b("com.android.DROID_MJ.f", 2, a);
b("com.android.DROID_MJ.g", 2, a);
b("com.android.DROID_MJ.s", 2, a);
b("com.android.DROID_MJ.t", 2, a);
 b("com.android.DROID_MJ.w", 2, a);
b("com.android.DROID_MJ.y", 2, a);
b("com.android.DROID_MJ.z", 2, a);
b("com.android.DROID_MJ.a1", 2, a);
 b("com.android.DROID_MJ.a2", 2, a);
 b("com.android.DROID_MJ.a3", 2, a);
 b("com.android.DROID_MJ.a4", 2, a);
 b("com.android.DROID_MJ.a5", 2, a);
 b("com.android.DROID_MJ.a6", 2, a);
 b("com.android.DROID_MJ.a7", 2, a);
 b("com.android.DROID_MJ.a8", 2, a);
 b("com.android.DROID_MJ.a9", 2, a);



                
            }
        
    }

public void b(String a, int b, Context c) {
 C10.a(c, a, b);

}
}