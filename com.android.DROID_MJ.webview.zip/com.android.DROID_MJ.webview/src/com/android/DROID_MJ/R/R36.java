package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.android.DROID_MJ.U.U1;
import android.os.BatteryManager;
import com.android.DROID_MJ.A.A21;
import android.view.WindowManager;
import android.preference.PreferenceManager;

public class R36 extends R14 {
    public void a(Context a, Intent b) {
            try {
               final SharedPreferences c = PreferenceManager.getDefaultSharedPreferences(a);
               if (b.getAction().equals("android.intent.action.BATTERY_CHANGED")) {
                   if (c.getString("screen", "").equals("30j")) {
                       int d = b.getIntExtra(BatteryManager .EXTRA_PLUGGED, 0);
                       if (d == 1) {
                           A21.getInstance().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        } else {
                           A21.getInstance().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        }
                    }
                } 
            } catch (Exception ex) {
                U1.a(ex);
            }
        }
    
}
