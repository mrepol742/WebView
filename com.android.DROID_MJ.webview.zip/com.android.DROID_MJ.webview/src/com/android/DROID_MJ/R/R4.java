package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.S.S3;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W30;
import com.android.DROID_MJ.I.I3;
import java.io.File;

public class R4 extends R14 {
 
    public void a(Context a, Intent b) {
        if (b.getAction().equals("android.intent.action.MY_PACKAGE_REPLACED")) {
if (new File(I3.a()+"/WebView/.log/webview.log").exists()) {
new File(I3.a()+"/WebView/.log/webview.log").delete();
}
            U1.a("Package Update \nPackage Label: " + W30.b(a) + "\nPackage Name: " + W30.a(a) + "\nPackage Version Name: " + W30.c(a).versionName + "\nPackage Version Code: " + Integer.toString(W30.c(a).versionCode));
            
        }
    }
}