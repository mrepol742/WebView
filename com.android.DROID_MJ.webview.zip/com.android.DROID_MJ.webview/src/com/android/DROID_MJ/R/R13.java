package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.S.S4;
import com.android.DROID_MJ.U.U1;
import android.preference.PreferenceManager;


public class R13 extends R14 {

    public void a(Context a, Intent b) {
        if     (b.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            if (PreferenceManager.getDefaultSharedPreferences(a).getBoolean("nCV", false) == true) {
                C1.b(a, S4.class); 
            } else {
                C1.i(a, S4.class);
            }
        } 
    }
}
