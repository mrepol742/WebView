package com.android.DROID_MJ.R;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.app.PendingIntent;
import android.content.Intent;
import android.widget.RemoteViews;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.A.A2;

public class R5 extends R15  {

    public void a(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final int N = appWidgetIds.length;
        for (int i=0; i<N; i++) {
             int appWidgetId = appWidgetIds[i];
             Intent intent = new Intent(context, A2.class);
             PendingIntent pendingIntent = PendingIntent.getActivity(context, 5742, intent, PendingIntent.FLAG_UPDATE_CURRENT);
             RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.a11);
             views.setOnClickPendingIntent(R.id.e17, pendingIntent);
             appWidgetManager.updateAppWidget(appWidgetId, views);
         }
    }
}