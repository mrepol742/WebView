package com.android.DROID_MJ.R;

import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.A.A24;
import com.android.DROID_MJ.C.C1;
import java.io.File;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.webview.R;
public class R24 extends R14 {
 
    public void a(Context a, Intent b) {
        if (b.getAction().equals("com.android.DROID_MJ.webview.intent.action.MASTER_DELETE_SCREENSHOT")) {
    String c = b.getStringExtra("a56hj");
    if (new File(c).exists()) {
        new File(c).delete();
W1.a(a, a.getResources().getString(R.string.f22),0);
     }
                
            }
        
    }
}

