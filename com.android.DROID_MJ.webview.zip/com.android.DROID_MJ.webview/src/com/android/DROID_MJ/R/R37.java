package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.U.U4;

public class R37 extends R14 {
    public void a(Context a, Intent b) {
            try {
              
               if (b.getAction().equals("android.intent.action.DOWNLOAD_NOTIFICATION_CLICKED")) {
                     C1.k(a, "android.intent.action.VIEW_DOWNLOADS");
                } 
            } catch (Exception ex) {
                U1.a(ex);
            }
        }
    
}
