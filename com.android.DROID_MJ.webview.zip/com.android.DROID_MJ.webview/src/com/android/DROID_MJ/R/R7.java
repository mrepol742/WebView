package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.C.C1;
import com.android.DROID_MJ.S.S2;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.W.W5;
import com.android.DROID_MJ.U.U4;


public class R7 extends R14 {

    public void a(Context a, Intent b) {
        if (b.getAction().equals("android.intent.action.DOWNLOAD_COMPLETE")) {          
            if (PreferenceManager.getDefaultSharedPreferences(a).getBoolean("launchF", false) == true) {
              C1.k(a, "android.intent.action.VIEW_DOWNLOADS");
            }


            W1.a(a, a.getResources().getString(R.string.n14), 0);

            C1.b(a, S2.class);

            
        }
    }
}