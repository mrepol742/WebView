package com.android.DROID_MJ.R;
import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class R20 extends DeviceAdminReceiver {

    public void onEnabled(Context context, Intent intent) {

    }

    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "";
    }

    public void onDisabled(Context context, Intent intent) {

    }
}