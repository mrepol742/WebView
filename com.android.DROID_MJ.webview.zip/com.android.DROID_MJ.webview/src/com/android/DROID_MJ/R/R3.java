package com.android.DROID_MJ.R;

import android.content.Context;
import android.content.Intent;
import com.android.DROID_MJ.W.W1;
import com.android.DROID_MJ.webview.R;
import com.android.DROID_MJ.U.U1;

public class R3 extends R14 {

    public void a(Context a, Intent b) {
        if     (b.getAction().equals("com.android.DROID_MJ.webview.intent.action.INSTALL_SHORTCUT")) {
            W1.a(a, a.getResources().getString(R.string.m8), 0);
            
        } 
    }
}