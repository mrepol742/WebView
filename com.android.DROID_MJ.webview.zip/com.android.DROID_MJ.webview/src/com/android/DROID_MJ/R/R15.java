package com.android.DROID_MJ.R;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import com.android.DROID_MJ.U.U1;
import android.appwidget.AppWidgetProvider;
 

public class R15 extends AppWidgetProvider {

    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        try {
            a(context, appWidgetManager, appWidgetIds);
        } catch (Exception ex) {
            U1.a(ex);
        }
    }

    public void a(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
    }
}