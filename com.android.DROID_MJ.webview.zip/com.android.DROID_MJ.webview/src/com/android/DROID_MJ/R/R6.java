package com.android.DROID_MJ.R;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import com.android.DROID_MJ.A.A21;
import com.android.DROID_MJ.W.W11;
import com.android.DROID_MJ.U.U1;
import com.android.DROID_MJ.webview.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import com.android.DROID_MJ.P.P15;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import com.android.DROID_MJ.A.A37;
import com.android.DROID_MJ.C.C5;
import com.java.DROID_MJ.U.U7;
import com.android.DROID_MJ.U.U6;
import com.android.DROID_MJ.U.U4;
import com.android.DROID_MJ.W.W5;
import com.notif_id;
import android.os.Build;
import android.net.Uri;
import android.graphics.BitmapFactory;
import com.android.DROID_MJ.S.S6;
import com.android.DROID_MJ.C.C1;

public class R6 extends R14 {

  public void a(Context a, Intent b) {

        if (b.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE") || b.getAction().equals("android.net.wifi.WIFI_STATE_CHANGED")) {
if (Build.VERSION.SDK_INT >= 28) {
      C1.b(a, S6.class);
}
            W11.a(a);
           /* if (sp.getBoolean("Arefresh", true)) {
                if (A21.bl2 == true) {
                    if (A21.h.getTitle().equals(a.getResources().getString(R.string.m1))) {
                        A21.h.reload();
                    }
                }                    
            }*/
            
        }
    }
}
