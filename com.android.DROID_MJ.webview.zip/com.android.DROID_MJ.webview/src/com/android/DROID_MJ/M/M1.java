package com.android.DROID_MJ.M;

import com.android.DROID_MJ.U.U1;
import android.content.Context;
import android.media.MediaPlayer;
import com.android.DROID_MJ.P.P15;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class M1 {
private static Executor er = Executors.newCachedThreadPool();
    public static void a(final Context a,final int b) {

P15 p = new P15() {
    public void a() {
        try {
            MediaPlayer a1 = MediaPlayer.create(a.getApplicationContext(), b);
            a1.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer a2) {
                     a2.release();
                }
            });
            a1.start();
         } catch (Exception ex) {
            U1.a(ex);
        }
}
};
er.execute(new Thread(p));
    }
}