package com.android.DROID_MJ.M;
import android.content.pm.PackageManager;
import android.os.Build;
import android.Manifest;
import android.app.Activity;

public class M2 {
    public static final String LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    public static final String STORAGE = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    public static final String CAMERA = Manifest.permission.CAMERA;
    public static final String MICROPHONE = Manifest.permission.RECORD_AUDIO;
    public static boolean a(Activity ay, String sg, int it) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ay.checkSelfPermission(sg) == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ay.requestPermissions(new String[]{sg}, it);
                return false;
            }
        } else { 
            return true;
        }
    }
}