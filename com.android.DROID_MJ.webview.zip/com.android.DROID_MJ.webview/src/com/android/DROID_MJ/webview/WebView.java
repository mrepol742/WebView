package com.android.DROID_MJ.webview;

public final class WebView {
    public static final class Intent {
        public static final String ACTION_VIEW = "com.android.DROID_MJ.webview.intent.action.VIEW";
        public static final String CATEGORY_DEFAULT = "com.android.DROID_MJ.webview.intent.category.MASTER_DEFAULT";
        public static final String TOOLS = "com.android.DROID_MJ.webview.intent.action.TOOLS";
        public static final String LAUNCH = "com.android.DROID_MJ.webview.intent.action.LAUNCH";
        public static final String ACTION_DELETE =
"com.android.DROID_MJ.webview.intent.action.MASTER_DELETE_SCREENSHOT";
        public static final String ACTION_INSTALL =
"com.android.DROID_MJ.webview.intent.action.INSTALL_SHORTCUT";
        public static final String MASTER_ACTION_INSTALL =
"com.android.DROID_MJ.webview.intent.action.MASTER_INSTALL_SHORTCUT";
    }

    public static final class Cache {
        public static final String a = "eWGoofLhiCxJ.ehcac";
        public static final String b = "mOfPVcLQLJq.ehcac";
        public static final String c = "YVjIdEspyCRmQ.ehcac";
        public static final String d = "rqnMDRUeyeeT.ehcac";
        public static final String e = "yxhyeviTSIeBy.ehcac";
        // cache folder
        public static final String f = "RxdKedGXGCSK";
        // default font primary
        public static final String g = "PLTnbFSCtBBgs.ehcac";
        // default font secondary
        public static final String h = "IFyLXeibhicSq.ehcac";
        // default font zip name raw
        public static final String i = "DiIsjUwkWidnY.ehcac";
    }

    public static final class Notitication {
        public static final int a = 1;
        public static final int c = 3;
    }

    public static final class Application {
        public static final boolean a = true;
        public static final int b = 520;
        public static final String c= "600KB";
    }
}