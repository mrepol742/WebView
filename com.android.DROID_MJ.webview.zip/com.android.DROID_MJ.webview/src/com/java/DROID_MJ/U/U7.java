package com.java.DROID_MJ.U;


public class U7 {

    public static final int NOTIFICATION = 10;
    public static final int FOREGROUND = 20;
    public static int a(int a) {
        return Integer.parseInt( a + "" + U5.a(5000));

    }
}