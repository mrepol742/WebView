package com.java.DROID_MJ.U;

import java.util.Random;

public class U2 {
    private static String[] a = new String[]{"A", "B", " C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
    private static String[] b = new String[]{"0", "1", "2", " 3", "4", "5", "6", "7", "8", "9" };
    private static Random d = new Random();

    public static String a() {
        int e = d.nextInt(2);
        if (e == 0) {
            return b();
        } else if (e == 1) {
            return c();
        } else if (e == 2) {
            return d();
        }
        return "";
    }

    private static String b() {
        int f = d.nextInt(a.length);
        return a[f].toLowerCase();
    }

    private static String c() {
        int f = d.nextInt(a.length);
        return a[f];
    }

    private static String d() {
        int f = d.nextInt(b.length);
        return b[f];
    }
}