package com.java.DROID_MJ.U;

import java.util.LinkedList;
import com.android.DROID_MJ.W.W28;

public class U4 {
public   int mmPosition = 0;
public   int mmMaxHistorySize = -1;
public   final LinkedList<W28> mmHistory = new LinkedList<W28>();

    public void clear() {
        mmPosition = 0;
        mmHistory.clear();
		}

   public void add(W28 item) {
       while (mmHistory.size() > mmPosition) {
           mmHistory.removeLast();
       }
       mmHistory.add(item);
			  mmPosition++;
       if (mmMaxHistorySize >= 0) {
           trimHistory();
			  }
		}

   public void setMaxHistorySize(int maxHistorySize) {
       mmMaxHistorySize = maxHistorySize;
       if (mmMaxHistorySize >= 0) {
				    trimHistory();
			  }
		}

   public void trimHistory() {
       while (mmHistory.size() > mmMaxHistorySize) {
           mmHistory.removeFirst();
           mmPosition--;
       }
       if (mmPosition < 0) {
           mmPosition = 0;
			  }
		}

   public W28 getPrevious() {
       if (mmPosition == 0) {
           return null;
			  }
			  mmPosition--;
       return mmHistory.get(mmPosition);
		}

   public W28 getNext() {
       if (mmPosition >= mmHistory.size()) {
           return null;
			  }
       W28 item = mmHistory.get(mmPosition);
       mmPosition++;
       return item;
		}
}
 