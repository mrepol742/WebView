package com.java.DROID_MJ.U;
import java.util.Random;

public class U5 {
    public static int a(int a) {
        Random d = new Random();
        return d.nextInt(a);
    }
}