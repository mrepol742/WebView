package com.java.DROID_MJ.U;
import java.util.Random;

public class U1 {
    public static String a(int targetStringLength) {
        int leftLimit = 65;
        int rightLimit = 122;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
            if (randomLimitedInt > 90 && randomLimitedInt < 98) {
            } else {
                buffer.append((char) randomLimitedInt);
            }
        }
        return buffer.toString();
     }
}