package com.java.DROID_MJ.U;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;
import java.io.RandomAccessFile;
import java.io.FileInputStream;
import java.util.zip.ZipInputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;
public class U6 {
    public static boolean a(String filePath, String i) {
        try {
            File file = new File(filePath);
            FileOutputStream fos = new FileOutputStream(i);
            ZipOutputStream zos = new ZipOutputStream(fos);
 
            zos.putNextEntry(new ZipEntry(file.getName()));
 
            byte[] bytes = b(file);
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();
            zos.close();
            return true;
        } catch (FileNotFoundException e5x) {
            com.android.DROID_MJ.U.U1.a(e5x);
        } catch (IOException ex) {
            com.android.DROID_MJ.U.U1.a(ex);
        }
           return false;
    }

    public static byte[] b(File file) throws IOException {
        // Open file
        RandomAccessFile f = new RandomAccessFile(file, "r");
        try {
            // Get and check length
            long longlength = f.length();
            int length = (int) longlength;
            if (length != longlength)
                throw new IOException("File size >= 2 GB");
                com.android.DROID_MJ.U.U1.a("U6 | File Size >= 2 GB");
            // Read file and return data
            byte[] data = new byte[length];
            f.readFully(data);
            return data;
        } finally {
            f.close();
        }
    }

    public static boolean c(String filePath, String i) {
        try {
            File file = new File(i);
            FileInputStream fos5 = new FileInputStream(filePath);
            ZipInputStream zos = new ZipInputStream(fos5);
            byte[] buffer = new byte[1024];
            ZipEntry ze = zos.getNextEntry();
            while (ze != null) {
                FileOutputStream fos = new FileOutputStream(file);
                int len = 0;
                while ((len = zos.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
                ze = zos.getNextEntry();
            }
            zos.closeEntry();
            zos.close();
            return true;
        } catch (FileNotFoundException e5x) {
            com.android.DROID_MJ.U.U1.a(e5x);
        } catch (IOException ex) {
            com.android.DROID_MJ.U.U1.a(ex);
        }
           return false;
    }
}