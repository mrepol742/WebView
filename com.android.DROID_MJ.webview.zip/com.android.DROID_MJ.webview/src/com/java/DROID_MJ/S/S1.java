package com.java.DROID_MJ.S;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class S1 {
    public static String a(String sha, String text) {
        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance(sha);
            //md.update(salt);
            byte[] bytes = md.digest(text.getBytes());
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
        }
        return generatedPassword;
    }
}