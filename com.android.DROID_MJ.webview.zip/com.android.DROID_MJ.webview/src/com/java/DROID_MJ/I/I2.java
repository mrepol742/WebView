package com.java.DROID_MJ.I;
import java.io.File;

public class I2 {
    public static boolean a(File a) {
        if (a != null && a.isDirectory()) {
            String[] children = a.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = a(new File(a, children[i]));
                if (!success) {
                    return false;
                }
            }
            return a.delete();
        } else if (a!= null &&a.isFile()) {
            return a.delete();
        } else {
            return false;
        }
    }

}