package com;

public class cache_id {
    public static final String a = "a.cache";
    public static final String b = "b.cache";
    public static final String c = "c.cache";
    public static final String d = "d.cache";
    public static final String e = "e.cache";
}