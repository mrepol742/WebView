package com;


public final class id {

public final static String a = "a";
public final static int b = 520;
public final static String c= "600KB";
}